/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cheightmap.h"

namespace basecode
{

// Extensions
bool CHeightMap::m_bvbo_supported = false;
bool CHeightMap::m_bmultitex_supported = false;

#ifdef DEF_GLEXT_FUNCTIONS_POINTERS
PFNGLMULTITEXCOORD2FARBPROC CHeightMap::glMultiTexCoord2fARB = NULL;
PFNGLACTIVETEXTUREARBPROC CHeightMap::glActiveTextureARB = NULL;
PFNGLCLIENTACTIVETEXTUREARBPROC CHeightMap::glClientActiveTextureARB = NULL;

PFNGLGENBUFFERSARBPROC CHeightMap::glGenBuffersARB = NULL;
PFNGLBINDBUFFERARBPROC CHeightMap::glBindBufferARB = NULL;
PFNGLBUFFERDATAARBPROC CHeightMap::glBufferDataARB = NULL;
PFNGLDELETEBUFFERSARBPROC CHeightMap::glDeleteBuffersARB = NULL;
PFNGLISBUFFERARBPROC CHeightMap::glIsBufferARB = NULL;
#endif

CHeightMap::CHeightMap()
		: m_width(0),
		m_depth(0),
		m_hfactor(1.0f),
		m_det_level(80.0f),
		m_pdata(NULL),
		m_texture(0),
		m_texture_detail(0),
		m_vbo_vert_id(0),
		m_vbo_tex_id(0),
		m_pvert(NULL),
		m_pcoord(NULL)
{

}

CHeightMap::~CHeightMap()
{
	Destroy();
}

void CHeightMap::Destroy()
{
	if(m_pdata != NULL)
	{
		delete [] m_pdata;
		m_pdata = NULL;
	}

	if(m_pvert != NULL)
	{
		delete [] m_pvert;
		m_pvert = NULL;
	}

	if(m_pcoord != NULL)
	{
		delete [] m_pcoord;
		m_pcoord = NULL;
	}

	if(glIsTexture(m_texture))
	{
		glDeleteTextures(1, &m_texture);
		m_texture = 0;
	}

	if(glIsTexture(m_texture_detail))
	{
		glDeleteTextures(1, &m_texture_detail);
		m_texture_detail = 0;
	}

	if(m_bvbo_supported)
	{
		if(glIsBufferARB(m_vbo_vert_id))
		{
			glDeleteBuffersARB(1, &m_vbo_vert_id);
			m_vbo_vert_id = 0;
		}

		if(glIsBufferARB(m_vbo_tex_id))
		{
			glDeleteBuffersARB(1, &m_vbo_tex_id);
			m_vbo_tex_id = 0;
		}
	}
}

void CHeightMap::Init(const string& filename)
		//throw(std::runtime_error, std::bad_alloc,
		//CFileNotFound, CBadFileFormat)
{
	Destroy();

	// One call is enough
	static bool already_called = false;
	if(!already_called)
	{
		PrepareGLExtensions();
		already_called = true;
	}

	LoadSettings(filename);
	// PrepareData()// Moved to LoadSettings()
}

void CHeightMap::LoadSettings(const string& filename)
		//throw(std::runtime_error, std::bad_alloc,
		//CFileNotFound, CBadFileFormat)
{
	CIni ini(filename);
	CImage img;
	string str;

	// MUST be loaded BEFORE generating VBO or vertex arrays
	m_hfactor = ini.Read("display", "height_factor", m_hfactor);

	// Data of heightmap
	if((str = ini.ReadString("paths", "heightmap", "")) == "")
		throw std::runtime_error(_("Unable to load path from INI for heightmap data."));

	img.Init(str);
	PrepareData(img);

	// Terain texture
	if((str = ini.ReadString("paths", "texture", "")) == "")
		throw std::runtime_error(_("Unable to load path from INI for terain texture."));

	img.Init(str);
	m_texture = img.CreateGLTexture(true, false);

	// Detail texture
	if(m_bmultitex_supported)
	{
		if((str = ini.ReadString("paths", "detail_texture", "")) == "")
			throw std::runtime_error(_("Unable to load path from INI for detail texture."));

		img.Init(str);
		m_texture_detail = img.CreateGLTexture(true, false);

		// Detail level
		m_det_level = ini.Read("display", "detail_level", m_det_level);
	}
}



void CHeightMap::PrepareData(CImage& img)
		//throw(std::bad_alloc)
{
	register int x = 0, z = 0, i = 0;

	m_width = img.GetWidth();
	m_depth = img.GetHeight();
	m_pdata = new GLubyte[m_width*m_depth];

	int num_pix = m_width * m_depth;
	int bypp = img.GetBytesPerPixel();
	GLubyte* p_pix = img.GetDataPtr();

	for(i = 0; i < num_pix; i++)
	{
		m_pdata[i] = (GLubyte)(p_pix[i*bypp]);// Red

		// Luminance
//		m_pdata[i] = (GLubyte)(0.299f*p_pix[i*bypp    ])// R
//			   + (GLubyte)(0.587f*p_pix[i*bypp + 1])// G
//			   + (GLubyte)(0.114f*p_pix[i*bypp + 2]);// B
	}

	m_pvert = new float[num_pix*6];// 3(x,y,z)*2(trianglestrip)
	m_pcoord = new float[num_pix*4];// 2(u,v) * 2(trianglestrip)

	// Triangle strip
	// 02--01:16-15:18--17
	// |  \  |  \  |  \  |
	// 04--03:14-13:20--19
	// |  \  |  \  |  \  |
	// 06--05:12-11:22--21
	// |  \  |  \  |  \  |
	// 08--07:10-09:24--23

	const int m_width_half = m_width >> 1;
	const int m_depth_half = m_depth >> 1;
	bool bswitch_sides = false;

	i = 0;

	for(x = 0; x < m_width; x++)
	{
		if(bswitch_sides)
		{
			for(z = m_depth-1; z >= 0; z--)
			{
				m_pvert[3*i    ] = x+1 - m_width_half;
				m_pvert[3*i + 1] = GetHeightGLFast(x+1, z);
				m_pvert[3*i + 2] = z - m_depth_half;

				m_pcoord[2*i    ] = (float)(x+1)/(float)m_width;
				m_pcoord[2*i + 1] = (float)z/(float)m_depth;

				i++;

				m_pvert[3*i    ] = x - m_width_half;
				m_pvert[3*i + 1] = GetHeightGLFast(x, z);
				m_pvert[3*i + 2] = z - m_depth_half;

				m_pcoord[2*i    ] = (float)x/(float)m_width;
				m_pcoord[2*i + 1] = (float)z/(float)m_depth;

				i++;
			}
		}
		else
		{
			for(z = 0; z < m_depth; z++)
			{
				m_pvert[3*i    ] = x+1 - m_width_half;
				m_pvert[3*i + 1] = GetHeightGLFast(x+1, z);
				m_pvert[3*i + 2] = z - m_depth_half;

				m_pcoord[2*i    ] = (float)(x+1)/(float)m_width;
				m_pcoord[2*i + 1] = (float)z/(float)m_depth;

				i++;

				m_pvert[3*i    ] = x - m_width_half;
				m_pvert[3*i + 1] = GetHeightGLFast(x, z);
				m_pvert[3*i + 2] = z - m_depth_half;

				m_pcoord[2*i    ] = (float)x/(float)m_width;
				m_pcoord[2*i + 1] = (float)z/(float)m_depth;

				i++;
			}
		}

		bswitch_sides = !bswitch_sides;
	}

	if(m_bvbo_supported)
	{
		// VBO for vertexes
		glGenBuffersARB(1, &m_vbo_vert_id);
		glBindBufferARB(GL_ARRAY_BUFFER_ARB, m_vbo_vert_id);
		glBufferDataARB(GL_ARRAY_BUFFER_ARB, num_pix*6*sizeof(float),
				m_pvert, GL_STATIC_DRAW_ARB);

		// VBO for tex. coords
		glGenBuffersARB(1, &m_vbo_tex_id);
		glBindBufferARB(GL_ARRAY_BUFFER_ARB, m_vbo_tex_id);
		glBufferDataARB(GL_ARRAY_BUFFER_ARB, num_pix*4*sizeof(float),
				m_pcoord, GL_STATIC_DRAW_ARB);

		// Free memory, data are in video card now
		if(m_pvert != NULL)
		{
			delete [] m_pvert;
			m_pvert = NULL;
		}

		if(m_pcoord != NULL)
		{
			delete [] m_pcoord;
			m_pcoord = NULL;
		}
	}
}

void CHeightMap::DrawFill() const
{
	if(m_pdata == NULL)
		return;

	glPushAttrib(GL_ENABLE_BIT);

	if(m_bmultitex_supported)
	{
		// Second texture unit
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT);
		glTexEnvi(GL_TEXTURE_ENV, GL_RGB_SCALE_EXT, 2);
		glBindTexture(GL_TEXTURE_2D, m_texture_detail);

		glMatrixMode(GL_TEXTURE);
			glLoadIdentity();
			glScalef(m_det_level, m_det_level, 1);
		glMatrixMode(GL_MODELVIEW);

		// First texture unit
		glActiveTextureARB(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, m_texture);
	}
	else
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, m_texture);
	}

	register int x = 0, z = 0;
	CVector<float> v1, v2;

	const int m_width_half = m_width >> 1;
	const int m_depth_half = m_depth >> 1;

	// Triangle strip
	// 02--01:16-15:18--17
	// |  \  |  \  |  \  |
	// 04--03:14-13:20--19
	// |  \  |  \  |  \  |
	// 06--05:12-11:22--21
	// |  \  |  \  |  \  |
	// 08--07:10-09:24--23

	bool bswitch_sides = false;

	glBegin(GL_TRIANGLE_STRIP);
	for(x = 0; x < m_width; x++)
	{
		if(bswitch_sides)
		{
			for(z = m_depth-1; z >= 0; z--)
			{
				v1.SetX(x+1 - m_width_half);
				v1.SetY(GetHeightGLFast(x+1, z));
				v1.SetZ(z - m_depth_half);

				v2.SetX(x - m_width_half);
				v2.SetY(GetHeightGLFast(x, z));
				v2.SetZ(z - m_depth_half);

				SetTexCoord((float)(x+1)/(float)m_width,
						(float)z/(float)m_depth);
				glVertex3fv(v1);

				SetTexCoord((float)x/(float)m_width,
						(float)z/(float)m_depth);
				glVertex3fv(v2);
			}
		}
		else
		{
			for(z = 0; z < m_depth; z++)
			{
				v1.SetX(x+1 - m_width_half);
				v1.SetY(GetHeightGLFast(x+1, z));
				v1.SetZ(z - m_depth_half);

				v2.SetX(x - m_width_half);
				v2.SetY(GetHeightGLFast(x, z));
				v2.SetZ(z - m_depth_half);

				SetTexCoord((float)(x+1)/(float)m_width,
						(float)z/(float)m_depth);
				glVertex3fv(v1);

				SetTexCoord((float)x/(float)m_width,
						(float)z/(float)m_depth);
				glVertex3fv(v2);
			}
		}

		bswitch_sides = !bswitch_sides;
	}
	glEnd();

	glPopAttrib();
}

void CHeightMap::DrawLines(bool one_direction) const
{
	if(m_pdata == NULL)
		return;

	glPushAttrib(GL_ENABLE_BIT);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, m_texture);

	register int x = 0, z = 0;

	for(x = 0; x < m_width; x++)
	{
		glBegin(GL_LINE_STRIP);
			for(z = 0; z < m_depth; z++)
			{
			glTexCoord2f((float)x/(float)m_width,
					(float)z/(float)m_depth);

			glVertex3f(	x-m_width/2,
					GetHeightGLFast(x, z),
					z-m_width/2);
			}
		glEnd();
	}

	if(!one_direction)
	{
		for(x = 0; x < m_width; x++)
		{
			glBegin(GL_LINE_STRIP);
			for(z = 0; z < m_depth; z++)
			{
				glTexCoord2f((float)z/(float)m_width,
						(float)x/(float)m_depth);

				glVertex3f(	z-m_width/2,
						GetHeightGLFast(z, x),
						x-m_width/2);
				}
			glEnd();
		}
	}

	glPopAttrib();
}

void CHeightMap::DrawPoints() const
{
	if(m_pdata == NULL)
		return;

	glPushAttrib(GL_ENABLE_BIT);
	glDisable(GL_TEXTURE_2D);

	register int x = 0, z = 0;

	glBegin(GL_POINTS);
	for(x = 0; x < m_width; x++)
	{
		for(z = 0; z < m_depth; z++)
		{
			glVertex3f(	x-m_width/2,
					GetHeightGLFast(x, z),
					z-m_width/2);
		}
	}
	glEnd();

	glPopAttrib();
}

float CHeightMap::GetHeight(int x, int z) const
{
	if(m_pdata == NULL)
		return 0.0f;

	if((x > 0 && x < m_width) && (z > 0 && z < m_depth))
		return GetHeightFast(x, z);
	else
		return 0.0f;
}

float CHeightMap::GetHeightGL(int x, int z) const
{
	if(m_pdata == NULL)
		return 0.0f;

	x = x + m_width / 2;
	z = z + m_depth / 2;

	if((x > 0 && x < m_width) && (z > 0 && z < m_depth))
		return GetHeightGLFast(x, z);
	else
		return 0.0f;
}

/* Some problems :(

float CHeightMap::GetHeightGLSmooth(float x, float z, float dirx, float dirz) const
{
	if(m_pdata == NULL)
		return 0.0f;

	x = x + m_width / 2;
	z = z + m_depth / 2;
	dirx *= 2.0f;
	dirz *= 2.0f;

	if(((x > 0 && x < m_width) && (z > 0 && z < m_depth))
			|| ((x+dirx > 0 && x+dirx < m_width)
			&& (z+dirz > 0 && z+dirz < m_depth)))
	{
		CVector<float> pos(x, GetHeightGLFast((int)x, (int)z), z);
		CVector<float> prew_pos((int)(x), GetHeightGLFast((int)(x), (int)(z)), (int)(z));
		CVector<float> next_pos((int)(x+dirx), GetHeightGLFast((int)(x+dirx), (int)(z+dirz)), (int)(z+dirz));
		CVector<float> dir_vector(prew_pos, next_pos);

		float t = (pos - prew_pos).Magnitude();
		cout << "pos\t" << pos << endl;
		cout << "prewpos\t" << prew_pos << endl;
		cout << "nextpos\t" << next_pos << endl;
		cout << "dir\t" << dir_vector << endl;
		cout << "magnit\t" << (pos - prew_pos).Magnitude() << endl;
		cout << "normal\t" << GetHeightGLFast((int)x, (int)z) << endl;
		cout << "smooth\t" << (pos + (dir_vector * t)).GetY() << endl << endl;
		return (pos + (dir_vector * t)).GetY();
	}
	else
		return 0.0f;
}
*/

void CHeightMap::SetTexCoord(float u, float v) const
{
	if(m_bmultitex_supported)
	{
		glMultiTexCoord2fARB(GL_TEXTURE0_ARB, u, v);
		glMultiTexCoord2fARB(GL_TEXTURE1_ARB, u, v);
	}
	else
	{
		glTexCoord2f(u, v);
	}
}

void CHeightMap::Draw() const
{
	// Is object initicalized?
	if(m_bvbo_supported)
	{
		if(!glIsBufferARB(m_vbo_vert_id))
			return;
	}
	else
	{
		if(m_pvert == NULL)
			return;
	}

	glPushAttrib(GL_ENABLE_BIT);

	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);

	if(m_bmultitex_supported)// With multitexturing
	{
		// Second texture unit
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT);
		glTexEnvi(GL_TEXTURE_ENV, GL_RGB_SCALE_EXT, 2);
		glBindTexture(GL_TEXTURE_2D, m_texture_detail);

		glMatrixMode(GL_TEXTURE);
			glLoadIdentity();
			glScalef(m_det_level, m_det_level, 1);
		glMatrixMode(GL_MODELVIEW);

		// First texture unit
		glActiveTextureARB(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, m_texture);
	}
	else// Without multitexturing
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, m_texture);
	}

	if(m_bvbo_supported)// VBO
	{
		glBindBufferARB(GL_ARRAY_BUFFER_ARB, m_vbo_vert_id);
		glVertexPointer(3, GL_FLOAT, 0, (char *)NULL);

		if(m_bmultitex_supported)// With multitexturing
		{
			glClientActiveTextureARB(GL_TEXTURE0_ARB);
			glBindBufferARB(GL_ARRAY_BUFFER_ARB, m_vbo_tex_id);
			glTexCoordPointer(2, GL_FLOAT, 0, (char *)NULL);

			glClientActiveTextureARB(GL_TEXTURE1_ARB);
			glBindBufferARB(GL_ARRAY_BUFFER_ARB, m_vbo_tex_id);
			glTexCoordPointer(2, GL_FLOAT, 0, (char *)NULL);
		}
		else// Without multitexturing
		{
			glBindBufferARB(GL_ARRAY_BUFFER_ARB, m_vbo_tex_id);
			glTexCoordPointer(2, GL_FLOAT, 0, (char *)NULL);
		}
	}
	else// Vertex arrays
	{
		glVertexPointer(3, GL_FLOAT, 0, m_pvert);

		if(m_bmultitex_supported)// With multitexturing
		{
			glClientActiveTextureARB(GL_TEXTURE0_ARB);
			glTexCoordPointer(2, GL_FLOAT, 0, m_pcoord);

			glClientActiveTextureARB(GL_TEXTURE1_ARB);
			glTexCoordPointer(2, GL_FLOAT, 0, m_pcoord);
		}
		else// Without multitexturing
		{
			glTexCoordPointer(2, GL_FLOAT, 0, m_pcoord);
		}
	}

	glDrawArrays(GL_TRIANGLE_STRIP, 0, m_width*m_depth*2);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);

	glPopAttrib();
}

void CHeightMap::PrepareGLExtensions()
{
	// Multitexturing
	if(gluCheckExtension((const GLubyte*)"GL_ARB_multitexture",
			glGetString(GL_EXTENSIONS)))
	{
		m_bmultitex_supported = true;

#ifdef DEF_GLEXT_FUNCTIONS_POINTERS
		glActiveTextureARB = (PFNGLACTIVETEXTUREARBPROC)
				SDL_GL_GetProcAddress("glActiveTextureARB");
		glMultiTexCoord2fARB = (PFNGLMULTITEXCOORD2FARBPROC)
				SDL_GL_GetProcAddress("glMultiTexCoord2fARB");
		glClientActiveTextureARB = (PFNGLCLIENTACTIVETEXTUREARBPROC)
				SDL_GL_GetProcAddress("glClientActiveTextureARB");

		if(glActiveTextureARB == NULL
				|| glMultiTexCoord2fARB == NULL
				|| glClientActiveTextureARB == NULL)
		{
			cerr << _("GL_ARB_multitexture extension is not supported by your video card") << endl;
			m_bmultitex_supported = false;
		}
#endif
	}
	else
	{
		cerr << _("GL_ARB_multitexture extension is not supported by your video card") << endl;
		m_bmultitex_supported = false;
	}

	// VBO
	if(gluCheckExtension((const GLubyte*)"GL_ARB_vertex_buffer_object",
			glGetString(GL_EXTENSIONS)))
	{
		m_bvbo_supported = true;

#ifdef DEF_GLEXT_FUNCTIONS_POINTERS
		glGenBuffersARB = (PFNGLGENBUFFERSARBPROC)
				SDL_GL_GetProcAddress("glGenBuffersARB");
		glBindBufferARB = (PFNGLBINDBUFFERARBPROC)
				SDL_GL_GetProcAddress("glBindBufferARB");
		glBufferDataARB = (PFNGLBUFFERDATAARBPROC)
				SDL_GL_GetProcAddress("glBufferDataARB");
		glDeleteBuffersARB = (PFNGLDELETEBUFFERSARBPROC)
				SDL_GL_GetProcAddress("glDeleteBuffersARB");
		glIsBufferARB = (PFNGLISBUFFERARBPROC)
				SDL_GL_GetProcAddress("glIsBufferARB");

		if(glGenBuffersARB == NULL || glBindBufferARB == NULL
				|| glBufferDataARB == NULL
				|| glDeleteBuffersARB == NULL
				|| glIsBufferARB == NULL)
		{
			cerr << _("GL_ARB_vertex_buffer_object extension is not supported by your video card") << endl;
			m_bvbo_supported = false;
		}
#endif
	}
	else
	{
		cerr << _("GL_ARB_vertex_buffer_object extension is not supported by your video card") << endl;
		m_bvbo_supported = false;
	}
}

}
