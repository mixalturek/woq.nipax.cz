/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CSTATICOBJECT_H__
#define __CSTATICOBJECT_H__

#include <SDL_opengl.h>

#include "basecode.h"
#include "cvector.h"
#include "csceneobject.h"

namespace basecode
{

class CStaticObject : public CSceneObject
{
public:
	CStaticObject();
	CStaticObject(GLuint texture);
	virtual ~CStaticObject();

	virtual void Init() { }
	virtual void Destroy();
	virtual void Draw();
	virtual void Update(float fps) { }
	void Init(GLuint texture, float width, float height,
			CVector<float>& pos);

	// Call ALWAYS before and after Draw(),
	// once is enough for group of objects
	static void Begin();
	static void End();

	void SetPos(const CVector<float>& pos) { m_pos = pos; }
	void AddPos(const CVector<float>& dpos) { m_pos += dpos; }
	float GetXPos() const { return m_pos.GetX(); }
	float GetYPos() const { return m_pos.GetY(); }
	float GetZPos() const { return m_pos.GetZ(); }

	CVector<float> GetPos() const { return m_pos; }
	void SetXPos(float x) { m_pos.SetX(x); }
	void SetYPos(float y) { m_pos.SetY(y); }
	void SetZPos(float z) { m_pos.SetZ(z); }

	void SetWidth(float width) { m_halfwidth = width/2; }
	void SetHeight(float height) { m_halfheight = height/2; }

	float GetWidth() const { return m_halfwidth*2; }
	float GetHeight() const { return m_halfheight*2; }

	void SetTexture(GLuint texture) { m_texture = texture; }

	// When the area (playground etc.) has borders
	void ChangePosToQuadArea(int x_half, int z_half);

	// For sorting (distance from camera)
	bool operator<(const CStaticObject& obj) const;
	static void SetCamPos(const CVector<float>& cam_pos)
			{ m_cam_pos = cam_pos; }

protected:
	void DrawBillboarded();

private:
	GLuint m_texture;
	float m_halfwidth;
	float m_halfheight;

	static CVector<float> m_cam_pos;
	static CVector<float> m_cam_right;
	static CVector<float> m_cam_up;

protected:
	CVector<float> m_pos;
};

}

#endif
