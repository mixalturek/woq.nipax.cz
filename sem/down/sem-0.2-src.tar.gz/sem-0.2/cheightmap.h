/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CHEIGHTMAP_H__
#define __CHEIGHTMAP_H__

#include <SDL_opengl.h>

#include "basecode.h"
#include "cimage.h"
#include "cini.h"
#include "cvector.h"

// GLubyte is from 0 to 255 and 255/2 = 127.5
#define MAX_HEIGHT_HALF 128

namespace basecode
{

class CHeightMap
{
public:
	CHeightMap();
	~CHeightMap();

	void Init(const string& filename);
			//throw(std::runtime_error, std::bad_alloc,
			//CFileNotFound, CBadFileFormat);
	void Destroy();

	int GetWidth() const { return m_width; }
	int GetDepth() const { return m_depth; }
	float GetHeightFactor() const { return m_hfactor; }
	float GetDetailLevel() const { return m_det_level; }

	void SetHeightFactor(float height_factor) { m_hfactor = height_factor; }
	void SetDetailLevel(float det_level) { m_det_level = det_level; }

	void Draw() const;// VBO or vertex arrays with GL_TRIANGLE_STRIP
	void DrawFill() const;// glBegin(GL_TRIANGLE_STRIP)
	void DrawLines(bool one_direction = false) const;// glBegin(GL_LINES)
	void DrawPoints() const;// glBegin(GL_POINTS)

	float GetHeight(int x, int z) const;
	float GetHeightGL(int x, int z) const;// In OpenGL coordinates
//	float GetHeightGLSmooth(float x, float z, float dirx, float dirz) const;

private:
	void LoadSettings(const string& filename);
			//throw(std::runtime_error, std::bad_alloc,
			//CFileNotFound, CBadFileFormat);

	void PrepareData(CImage& img);//throw(std::bad_alloc);
	void PrepareGLExtensions();
	void SetTexCoord(float u, float v) const;

	// Same as GetHeight() but without testing bounds of allocated memory
	// Faster, but only private use - not safe
	float GetHeightFast(int x, int z) const
			{ return (m_pdata[z*m_width + x] * m_hfactor); }
	float GetHeightGLFast(int x, int z) const
			{ return ((m_pdata[z*m_width + x] - MAX_HEIGHT_HALF)
			* m_hfactor); }

private:
	int m_width;// Dimensions of heightmap
	int m_depth;
	float m_hfactor;// The height is timed by this (hills X big mountains)
	float m_det_level;// How "detailed" the texture (m_texture_detail) is

	GLubyte* m_pdata;// Data for generating heightmap and GetHeight()
	GLuint m_texture;// Terain texture
	GLuint m_texture_detail;// Second texture for multitexturing

	GLuint m_vbo_vert_id;// Vertex ID for VBO
	GLuint m_vbo_tex_id;// Tex. coords ID for VBO
	GLfloat* m_pvert;// Data of vertexes for VBO or vertex arrays
	GLfloat* m_pcoord;// Tex. coords data for VBO or vertex arrays

	static bool m_bmultitex_supported;// GL_ARB_multitexture supported?
	static bool m_bvbo_supported;// GL_ARB_vertex_buffer_object supported?

#ifdef DEF_GLEXT_FUNCTIONS_POINTERS
	// Multitexturing
	static PFNGLMULTITEXCOORD2FARBPROC glMultiTexCoord2fARB;
	static PFNGLACTIVETEXTUREARBPROC glActiveTextureARB;

	// VBO
	static PFNGLGENBUFFERSARBPROC glGenBuffersARB;
	static PFNGLBINDBUFFERARBPROC glBindBufferARB;
	static PFNGLBUFFERDATAARBPROC glBufferDataARB;
	static PFNGLDELETEBUFFERSARBPROC glDeleteBuffersARB;
	static PFNGLISBUFFERARBPROC glIsBufferARB;
	static PFNGLCLIENTACTIVETEXTUREARBPROC glClientActiveTextureARB;
#endif
};

}

#endif
