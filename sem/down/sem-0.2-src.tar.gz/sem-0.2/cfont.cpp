/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cfont.h"

namespace basecode
{

CFont::CFont()
{
	m_texture = 0;
	m_base_dlist = 0;
}

CFont::CFont(GLuint texture)
{
	Init(texture);
}

CFont::~CFont()
{
	Destroy();
}

void CFont::Destroy()
{
//	if(m_base_dlist != 0)
	if(glIsList(m_base_dlist))
	{
		glDeleteLists(m_base_dlist, NUM_CHARS);
		m_base_dlist = 0;
	}

	// The calling code looks after texture...
}

void CFont::Init(GLuint texture)
{
	m_texture = texture;

	if(m_base_dlist != 0)
		return;// Display lists have been already created...

	m_base_dlist = glGenLists(NUM_CHARS);

	int loop;
	float cx, cy;

	for(loop = 0; loop < NUM_CHARS; loop++)
	{
		glNewList(m_base_dlist + loop, GL_COMPILE);

		if(loop < 33)// Nonprintable characters (optimalization)
		{
			if(loop == '\t')// Space 4 characters for TAB
			{
				glTranslated(REAL_CHAR_WIDTH*TAB_CHARS,0.0,0.0);
			}
			else
			{
				glTranslated(REAL_CHAR_WIDTH, 0.0, 0.0);
			}
		}
		else// Printable characters
		{
			cx = (float)(loop % 16) / 16.0f;
			cy = (float)(loop / 16) / 16.0f;

			glBegin(GL_QUADS);
				glTexCoord2f(cx, 1.0f - cy - 0.0625f);
				glVertex2i(0, 0);
				glTexCoord2f(cx + 0.0625f, 1.0f - cy - 0.0625f);
				glVertex2i(CHAR_WIDTH, 0);
				glTexCoord2f(cx + 0.0625f, 1.0f - cy);
				glVertex2i(CHAR_WIDTH, CHAR_HEIGHT);
				glTexCoord2f(cx, 1.0f - cy);
				glVertex2i(0, CHAR_HEIGHT);
			glEnd();

			glTranslated(REAL_CHAR_WIDTH, 0.0, 0.0);
		}

		glEndList();
	}
}

void CFont::Begin()
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0, SCREEN_WIDTH, 0, SCREEN_HEIGHT);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT
			| GL_POLYGON_BIT | GL_LIST_BIT);

	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);

	glPolygonMode(GL_FRONT, GL_FILL);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glBindTexture(GL_TEXTURE_2D, m_texture);
	glListBase(m_base_dlist);
}

void CFont::End()
{
	glPopAttrib();

	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}

void CFont::Draw(int x, int y, const string & str,
		float scale_x, float scale_y)
{
	glLoadIdentity();
	glTranslated(x, y, 0.0);
	glScalef(scale_x, scale_y, 1.0f);
	glCallLists(str.length(), GL_UNSIGNED_BYTE, str.c_str());
}

/*
void CFont::PrintfLines(int x, int y, const string & text, int align)
{
	if(text == NULL)
		return;

	char* tmp_text;

	if((tmp_text = (char*)malloc(strlen(text) + 1)) == NULL)
	{
		cerr << _("CFont: Unable to allocate memory (")
			<< strlen(text) + 1 << _(" B) for temporary string") << endl;
		return;
	}

	strcpy(tmp_text, text);

	char* line;
	int line_length;
	int num_lines = 0;

	line = strtok(tmp_text, "\n");

	while(line != NULL)
	{
		num_lines++;
		line_length = strlen(line);

		glLoadIdentity();

		if(align == ALIGN_LEFT)
			glTranslated(x, y - (num_lines * CHAR_HEIGHT), 0.0);
		else if(align == ALIGN_CENTER)
			glTranslated(x - ((line_length >> 1) * REAL_CHAR_WIDTH),
					y - (num_lines * CHAR_HEIGHT), 0.0);
		else if(align == ALIGN_RIGHT)
			glTranslated(x - (line_length * REAL_CHAR_WIDTH),
					y - (num_lines * CHAR_HEIGHT), 0.0);

		glCallLists(line_length, GL_UNSIGNED_BYTE, line);

		line = strtok(NULL, "\n");
	}
}
*/
void CFont::SetTexture(GLuint texture)
{
	m_texture = texture;
	glBindTexture(GL_TEXTURE_2D, m_texture);
}

}
