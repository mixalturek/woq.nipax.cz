/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CFIRSTAPP_H__
#define __CFIRSTAPP_H__

#include <ctime>
#include <algorithm>
#include <functional>

#include "basecode.h"
#include "capplicationex.h"
#include "cheightmap.h"
#include "cgrid.h"
#include "ccheat.h"
#include "cimage.h"
#include "cstaticobject.h"
#include "cdynamicobject.h"
#include "cplayer.h"
#include "csimplemenu.h"

//#define USE_CHEATS

#define USE_TEXTURES
#define NUM_TEXTURES 5

#define NUM_STATIC_OBJECTS 100
#define NUM_OBJ_TEXS 5

// Menus
#define MENU_NO -1
#define MENU_MAIN 0
#define MENU_HMAP 1

// First two codes has been already used (CApplicationEx)
// Main menu
#define EVT_MAIN_MENU_HMAP 2
#define EVT_MAIN_MENU_HIDE 3
#define EVT_MAIN_MENU_EXIT 4

// Hmap menu
// Which hmap was selected is m_menu.GetSel()
#define EVT_HMAP_MENU_SEL 5
#define EVT_HMAP_MENU_GOTO_MAIN_MENU 6

using namespace std;

namespace basecode
{

class CFirstApp : public CApplicationEx
{
public:
	CFirstApp();
	virtual ~CFirstApp();
	virtual void Init(const string& win_title);
			//throw(std::runtime_error, std::bad_alloc,
			//CFileNotFound, CBadFileFormat);
	virtual void Destroy();

protected:
	virtual void InitGL();
			//throw(std::runtime_error, std::bad_alloc,
			//CFileNotFound, CBadFileFormat);
	virtual void Draw();
	virtual void Update();
	virtual bool ProcessEvent(SDL_Event& event);

private:
	void InitMainMenu();
	void InitHmapMenu();

private:
	CHeightMap m_hmap;
	CPlayer m_cam;
#ifdef USE_TEXTURES
	GLuint m_textures[NUM_TEXTURES];
#endif
	int m_polygon_mode;// 0 - fill, 1 - lines, 2 - points
	CStaticObject m_obj[NUM_STATIC_OBJECTS];
#ifdef USE_CHEATS
	CCheat m_cheat;
#endif
	CSimpleMenu m_menu;
	int m_which_menu;// Which menu is displayed
};

}

#endif
