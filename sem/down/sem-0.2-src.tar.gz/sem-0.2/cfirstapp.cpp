/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cfirstapp.h"

namespace basecode
{

CFirstApp::CFirstApp() : CApplicationEx(),
		m_hmap(),
		m_cam(),
		m_polygon_mode(0),
#ifdef USE_CHEATS
		m_cheat("cheat", EVT_CHEAT_CODE)
#endif
		m_menu(),
		m_which_menu(MENU_NO)
{
	srand((unsigned int)time((time_t*)NULL));

#ifdef USE_TEXTURES
	for(int i = 0; i < NUM_TEXTURES; i++)
		m_textures[i] = 0;
#endif
}

CFirstApp::~CFirstApp()
{
	Destroy();
}

void CFirstApp::Destroy()
{
	m_hmap.Destroy();
	m_menu.Destroy();

#ifdef USE_TEXTURES
	for(int i = 0; i < NUM_TEXTURES; i++)
	{
		if(glIsTexture(m_textures[i]))
		{
			glDeleteTextures(1, &m_textures[i]);
			m_textures[i] = 0;
		}
	}
#endif

	for(int i = 0; i < NUM_STATIC_OBJECTS; i++)
		m_obj[i].Destroy();

	CApplicationEx::Destroy();
}

void CFirstApp::Init(const string & win_title)
		//throw(std::runtime_error, std::bad_alloc,
		//CFileNotFound, CBadFileFormat)
{
	CApplicationEx::Init(win_title);
	SDL_ShowCursor(SDL_DISABLE);
}

void CFirstApp::InitGL()
		//throw(std::runtime_error, std::bad_alloc,
		//CFileNotFound, CBadFileFormat)
{
	CApplicationEx::InitGL();

	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClearDepth(1.0);
	glDepthFunc(GL_LEQUAL);
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glEnable(GL_TEXTURE_2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
			GL_LINEAR_MIPMAP_LINEAR);

	m_hmap.Init("./cfg/hmap/default.ini");
	m_cam.LoadSettings("./cfg/hmap/default.ini");

	int i;
	string str;
	stringstream sstream(str);
	CImage img;

	for(i = 0; i < NUM_OBJ_TEXS; i++)
	{
		sstream << "./data/objects/player" << i << ".png";
		img.Init(sstream.str());
		sstream.str("");// Delete content

		m_textures[i] = img.CreateGLTexture();
	}

	CVector<float> vector;

	for(int i = 0; i < NUM_STATIC_OBJECTS; i++)
	{
		vector.Set(	(float)((rand() % (m_hmap.GetWidth()-2))
					- ((m_hmap.GetWidth()-1) / 2)),
				0.0f,
				(float)((rand() % (m_hmap.GetDepth()-2))
					- ((m_hmap.GetDepth()-1) / 2))
				);

		vector.SetY(m_hmap.GetHeightGL((int)vector.GetX(),
				(int)vector.GetZ()));

		m_obj[i].Init(m_textures[i % NUM_OBJ_TEXS], 10, 10, vector);
	}
}

void CFirstApp::Draw()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	m_cam.LookAt();

	glColor3ub(0, 200, 0);
	CGrid::DrawCuboid(m_hmap.GetWidth(), 256.0f, m_hmap.GetDepth());

	glColor3ub(255, 255, 255);
	m_hmap.Draw();

	CStaticObject::Begin();
	for(int i = 0; i < NUM_STATIC_OBJECTS; i++)
		m_obj[i].Draw();
	CStaticObject::End();

	if(m_which_menu != MENU_NO)
	{
		m_menu.Draw(350, 350);
	}

	glColor3ub(255, 255, 255);
	GetFont().Begin();
		GetFont().Draw(710, 10, "(c) Woq");
		if(m_which_menu == MENU_NO)
			GetFont().Draw(300, 10, "press |F10| for menu");
	GetFont().End();

	CApplicationEx::Draw();
}

void CFirstApp::Update()
{
	if(m_which_menu != MENU_NO)
		return;

	SDL_PumpEvents();

	Uint8* keys;
	keys = SDL_GetKeyState(NULL);

	if(keys[SDLK_UP] == SDL_PRESSED || keys[SDLK_w] == SDL_PRESSED)
		m_cam.GoFront(GetFPS());
	if(keys[SDLK_DOWN] == SDL_PRESSED || keys[SDLK_s] == SDL_PRESSED)
		m_cam.GoBack(GetFPS());
	if(keys[SDLK_LEFT] == SDL_PRESSED || keys[SDLK_a] == SDL_PRESSED)
		m_cam.GoLeft(GetFPS());
	if(keys[SDLK_RIGHT] == SDL_PRESSED || keys[SDLK_d] == SDL_PRESSED)
		m_cam.GoRight(GetFPS());

	m_cam.ChangePosToQuadArea((m_hmap.GetWidth() >> 1)-1,
			(m_hmap.GetDepth() >> 1)-1);

	m_cam.SetYPos(m_hmap.GetHeightGL((int)m_cam.GetXPos(),
			(int)m_cam.GetZPos()));

	CStaticObject::SetCamPos(m_cam.GetPos());
	sort(m_obj, m_obj+NUM_STATIC_OBJECTS);
}

bool CFirstApp::ProcessEvent(SDL_Event& event)
{
	switch(event.type)
	{
	case SDL_MOUSEMOTION:
		if(m_which_menu != MENU_NO)
			break;

		// SDL_WarpMouse() generates SDL_MOUSEMOTION event :-(
		if(event.motion.x != GetWinWidth() >> 1
				|| event.motion.y != GetWinHeight() >> 1)
		{
			// First several messages MUST be ignored
			static int krize = 0;
			if(krize < 5)
			{
				krize++;
				break;
			}

			m_cam.Rotate(event.motion.xrel,
					event.motion.yrel, GetFPS());

			// Center mouse in window
			SDL_WarpMouse(GetWinWidth()>>1, GetWinHeight()>>1);
		}
		break;

	case SDL_KEYDOWN:
#ifdef USE_CHEATS
		m_cheat.KeyPress(event.key.keysym.sym);// Cheats
#endif
		switch(event.key.keysym.sym)
		{
		case SDLK_F10:
			if(m_which_menu == MENU_NO)
			{
				InitMainMenu();
			}
			else
			{
				m_which_menu = MENU_NO;
				m_menu.Destroy();
			}
			break;

		case SDLK_RETURN:
			if(m_which_menu != MENU_NO)
				m_menu.Choose();
			break;

		case SDLK_UP:
			if(m_which_menu != MENU_NO)
				m_menu.SelectPrevious();
			break;

		case SDLK_DOWN:
			if(m_which_menu != MENU_NO)
				m_menu.SelectNext();
			break;

		case SDLK_KP_PLUS:
			m_hmap.SetDetailLevel(m_hmap.GetDetailLevel()+10.0f);
			break;

		case SDLK_KP_MINUS:
			m_hmap.SetDetailLevel(m_hmap.GetDetailLevel()-10.0f);
			break;

		case SDLK_KP_ENTER:
			if(++m_polygon_mode > 2)
				m_polygon_mode = 0;

			switch(m_polygon_mode)
			{
			case 0:
				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
				break;
			case 1:
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
				break;
			default:
				glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
				break;
			}
			break;

		case SDLK_ESCAPE:
			if(m_which_menu != MENU_NO)
				m_menu.SelectLast();
			else
				return false;// End program
			break;

		default:// Other key
			return CApplicationEx::ProcessEvent(event);
			break;
		}
		break;

	case SDL_USEREVENT:
		switch(event.user.code)
		{
		// Main menu
		case EVT_MAIN_MENU_HMAP:
			InitHmapMenu();
			break;

		case EVT_MAIN_MENU_HIDE:
			m_which_menu = MENU_NO;
			m_menu.Destroy();
			break;

		case EVT_MAIN_MENU_EXIT:
			return false;
			break;

		// Hmap menu
		case EVT_HMAP_MENU_SEL:
			{
				m_hmap.Destroy();

				string str;
				stringstream sstream(str);
				sstream << "./cfg/hmap/" << m_menu.GetSel()
						<< ".ini";
				m_hmap.Init(sstream.str());

				// Actualize positions of objects
				for(int i = 0; i < NUM_STATIC_OBJECTS; i++)
				{
					m_obj[i].ChangePosToQuadArea(
						(m_hmap.GetWidth() >> 1)-1,
						(m_hmap.GetDepth() >> 1)-1);

					m_obj[i].SetYPos(m_hmap.GetHeightGL(
						(int)m_obj[i].GetXPos(),
						(int)m_obj[i].GetZPos())
						+ m_obj[i].GetHeight()/2);
				}

				m_which_menu = MENU_NO;
				m_menu.Destroy();
			}
			break;

		case EVT_HMAP_MENU_GOTO_MAIN_MENU:
			if(m_which_menu == MENU_HMAP)
				InitMainMenu();
			break;

		// Other
#ifdef USE_CHEATS
		case EVT_CHEAT_CODE:
			cerr << "cheat" << endl;// Only test
			break;
#endif

		default:
			return CApplicationEx::ProcessEvent(event);
			break;
		}
		break;

	default:// Other events
		return CApplicationEx::ProcessEvent(event);
		break;
	}

	return true;
}

void CFirstApp::InitMainMenu()
{
	m_which_menu = MENU_MAIN;
	m_menu.Destroy();
	m_menu.Init(&GetFont(), 5);
	m_menu.AddItem(EVT_MAIN_MENU_HMAP, _("Terain >>>"));
	m_menu.AddItem(EVT_MAIN_MENU_HIDE, _("Hide menu"));
	m_menu.AddItem(EVT_MAIN_MENU_EXIT, _("Exit"));
}

void CFirstApp::InitHmapMenu()
{
	CIni ini("./cfg/hmap/general.ini");
	int num_hmaps = -1;
	num_hmaps = ini.Read("general", "num", num_hmaps);

	if(num_hmaps == -1)// Some error in file
	{
//		InitMainMenu();// It's still active
		return;
	}

	m_which_menu = MENU_HMAP;
//	m_menu.Destroy();// It is called in Init()
	m_menu.Init(&GetFont(), num_hmaps+5);

	string str;
	stringstream sstream(str);

	for(int i = 0; i < num_hmaps; i++)
	{
		sstream << "hmap" << i;
		m_menu.AddItem(EVT_HMAP_MENU_SEL,
			ini.ReadString(sstream.str(), "name", sstream.str()));

		sstream.str("");// Delete content
	}

	m_menu.AddItem(EVT_HMAP_MENU_GOTO_MAIN_MENU, _("<<< GO BACK"));
}

}
