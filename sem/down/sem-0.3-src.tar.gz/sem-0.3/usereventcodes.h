/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __USEREVENTCODES_H__
#define __USEREVENTCODES_H__


// FPS
#define EVT_ACTUALIZE_FPS_STRING 0

// Cheats
#define EVT_CHEAT_CODE 1

// Main menu
#define EVT_MAIN_MENU_TERRAIN 2
#define EVT_MAIN_MENU_POLYGON_MODE 3
#define EVT_MAIN_MENU_HIDE 4
#define EVT_MAIN_MENU_EXIT 5

// Terrain menu
// Which terrain was selected is m_menu.GetSel()
#define EVT_TERRAIN_MENU_SEL 6
#define EVT_TERRAIN_MENU_GOTO_MAIN_MENU 7

#define EVT_POLYG_MENU_FILL 8
#define EVT_POLYG_MENU_LINES 9
#define EVT_POLYG_MENU_POINTS 10
#define EVT_POLYG_MENU_GOTO_MAIN_MENU 11

// Shoot
#define EVT_SHOOT 12

#endif
