/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cterrain.h"

namespace basecode
{

CTerrain::CTerrain(const string& filename) :
		m_width(0),
		m_depth(0),
		m_hfactor(1.0f),
		m_det_level(80.0f),
		m_pdata(NULL),
		m_texture(0),
		m_texture_detail(0),
		m_pvert(NULL),
		m_pcoord(NULL)
{
	CGLExt::Init();

	CIni ini(filename);
	string str;

	m_hfactor = ini.Read("display", "height_factor", m_hfactor);

	// Data of terrain
	if((str = ini.ReadString("paths", "terrain", "")) == "")
		throw std::runtime_error(
			_("Unable to load image path for terrain data"));
	GenerateTerrain(str);

	// Terain texture
	if((str = ini.ReadString("paths", "texture", "")) == "")
		throw std::runtime_error(
			_("Unable to load path for terrain texture"));
	m_texture = CreateTexture(str);

	// Detail texture
	if(CGLExt::IsGL_ARB_multitexture())
	{
		if((str = ini.ReadString("paths", "detail_texture", ""))
				== "")
			throw std::runtime_error(
			_("Unable to load path for detailed texture."));

		m_texture_detail = CreateTexture(str);
		m_det_level = ini.Read("display", "detail_level",
				 m_det_level);
	}
}

CTerrain::~CTerrain()
{
	if(m_pdata != NULL)
		delete [] m_pdata;

	if(m_pvert != NULL)
		delete [] m_pvert;

	if(m_pcoord != NULL)
		delete [] m_pcoord;

	DeleteTexture(m_texture);
	DeleteTexture(m_texture_detail);
}

void CTerrain::GenerateTerrain(const string& filename)
{
	CImage img(filename);
	img.ConvertToRGBA();
	img.SwapRows();

	m_width = img.GetWidth();
	m_depth = img.GetHeight();

	int num_pix = m_width*m_depth;
	GLubyte* p_pix = img.GetDataPtr();

	// At Explode() would be access to invalid memory when there isn't +1
	// This is the fastest solution
	m_pdata = new GLubyte[num_pix+1];

	for(register int i = 0; i < num_pix; i++)
		m_pdata[i] = (GLubyte)(p_pix[i*img.GetBPP()]);// Red

	m_pvert = new float[num_pix*6];// 3(x,y,z)*2(trianglestrip)
	m_pcoord = new float[num_pix*4];// 2(u,v) * 2(trianglestrip)

	RegenerateVertices();
	RegenerateTexCoords();
}

void CTerrain::RegenerateVertices()
{
	// Triangle strip
	// 02--01:16-15:18--17
	// |  \  |  \  |  \  |
	// 04--03:14-13:20--19
	// |  \  |  \  |  \  |
	// 06--05:12-11:22--21
	// |  \  |  \  |  \  |
	// 08--07:10-09:24--23

	register int i = 0, x, z;
	const int width_half = m_width >> 1;
	const int depth_half = m_depth >> 1;
	bool bswitch_sides = false;

	for(x = 0; x < m_width; x++)
	{
		if(bswitch_sides)
		{
			for(z = m_depth-1; z >= 0; z--)
			{
				m_pvert[3*i    ] = x+1 - width_half;
				m_pvert[3*i + 1] = GetHeightGLFast(x+1, z);
				m_pvert[3*i + 2] = z - depth_half;
				i++;

				m_pvert[3*i    ] = x - width_half;
				m_pvert[3*i + 1] = GetHeightGLFast(x, z);
				m_pvert[3*i + 2] = z - depth_half;
				i++;
			}
		}
		else
		{
			for(z = 0; z < m_depth; z++)
			{
				m_pvert[3*i    ] = x+1 - width_half;
				m_pvert[3*i + 1] = GetHeightGLFast(x+1, z);
				m_pvert[3*i + 2] = z - depth_half;
				i++;

				m_pvert[3*i    ] = x - width_half;
				m_pvert[3*i + 1] = GetHeightGLFast(x, z);
				m_pvert[3*i + 2] = z - depth_half;
				i++;
			}
		}

		bswitch_sides = !bswitch_sides;
	}
}

void CTerrain::RegenerateTexCoords()
{
	// Triangle strip
	// 02--01:16-15:18--17
	// |  \  |  \  |  \  |
	// 04--03:14-13:20--19
	// |  \  |  \  |  \  |
	// 06--05:12-11:22--21
	// |  \  |  \  |  \  |
	// 08--07:10-09:24--23

	register int i = 0, x, z;
	bool bswitch_sides = false;

	for(x = 0; x < m_width; x++)
	{
		if(bswitch_sides)
		{
			for(z = m_depth-1; z >= 0; z--)
			{
				m_pcoord[2*i] = (float)(x+1)/(float)m_width;
				m_pcoord[2*i + 1] = (float)z/(float)m_depth;
				i++;

				m_pcoord[2*i    ] = (float)x/(float)m_width;
				m_pcoord[2*i + 1] = (float)z/(float)m_depth;
				i++;
			}
		}
		else
		{
			for(z = 0; z < m_depth; z++)
			{
				m_pcoord[2*i] = (float)(x+1)/(float)m_width;
				m_pcoord[2*i + 1] = (float)z/(float)m_depth;
				i++;

				m_pcoord[2*i    ] = (float)x/(float)m_width;
				m_pcoord[2*i + 1] = (float)z/(float)m_depth;
				i++;
			}
		}

		bswitch_sides = !bswitch_sides;
	}
}

void CTerrain::Explode(int x, int z, int radius)
{
	if(m_pdata == NULL)
		return;

	x = x + m_width / 2;
	z = z + m_depth / 2;
	radius /= 2;

	int mem_pos = 0;
	int x_border_minus = (x-radius < 0) ? 0 : x-radius;
	int z_border_minus = (z-radius < 0) ? 0 : z-radius;
	int x_border_plus = (x+radius > m_width) ? m_width : x+radius;
	int z_border_plus = (z+radius > m_depth) ? m_depth : z+radius;

//	cout << x << "\t" << z << endl;

	for(int tmpx = x_border_minus; tmpx <= x_border_plus; tmpx++)
	{
		// Memory is allocated bigger than it is used, so <= is OK
		for(int tmpz = z_border_minus; tmpz < z_border_plus; tmpz++)
		{
			mem_pos = tmpz*m_width + tmpx;

//			cout << mem_pos << endl;

			if(m_pdata[mem_pos] >= radius)
				m_pdata[mem_pos] -= radius;
			else
				m_pdata[mem_pos] = 0;
		}
	}

	RegenerateVertices();
}

float CTerrain::GetHeight(int x, int z) const
{
	if(m_pdata == NULL)
		return 0.0f;

	if((x > 0 && x < m_width) && (z > 0 && z < m_depth))
		return GetHeightFast(x, z);
	else
		return 0.0f;
}

float CTerrain::GetHeightGL(int x, int z) const
{
	if(m_pdata == NULL)
		return 0.0f;

	x = x + m_width / 2;
	z = z + m_depth / 2;

	if((x > 0 && x < m_width) && (z > 0 && z < m_depth))
		return GetHeightGLFast(x, z);
	else
		return 0.0f;
}

void CTerrain::Draw() const
{
	if(m_pvert == NULL)
		return;

	glPushAttrib(GL_ENABLE_BIT);

	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);

	if(CGLExt::IsGL_ARB_multitexture())// With multitexturing
	{
		// Second texture unit
		CGLExt::glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,
				GL_COMBINE_EXT);
		glTexEnvi(GL_TEXTURE_ENV, GL_RGB_SCALE_EXT, 2);
		glBindTexture(GL_TEXTURE_2D, m_texture_detail);

		glMatrixMode(GL_TEXTURE);
			glLoadIdentity();
			glScalef(m_det_level, m_det_level, 1);
		glMatrixMode(GL_MODELVIEW);

		// First texture unit
		CGLExt::glActiveTextureARB(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, m_texture);

		CGLExt::glClientActiveTextureARB(GL_TEXTURE0_ARB);
		glTexCoordPointer(2, GL_FLOAT, 0, m_pcoord);
		CGLExt::glClientActiveTextureARB(GL_TEXTURE1_ARB);
		glTexCoordPointer(2, GL_FLOAT, 0, m_pcoord);
	}
	else// Without multitexturing
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, m_texture);

		glTexCoordPointer(2, GL_FLOAT, 0, m_pcoord);
	}

	glVertexPointer(3, GL_FLOAT, 0, m_pvert);

	glDrawArrays(GL_TRIANGLE_STRIP, 0, m_width*m_depth*2);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);

	glPopAttrib();
}

void CTerrain::SetTexCoord(float u, float v) const
{
	if(CGLExt::IsGL_ARB_multitexture())
	{
		CGLExt::glMultiTexCoord2fARB(GL_TEXTURE0_ARB, u, v);
		CGLExt::glMultiTexCoord2fARB(GL_TEXTURE1_ARB, u, v);
	}
	else
	{
		glTexCoord2f(u, v);
	}
}

void CTerrain::DrawFill() const
{
	if(m_pdata == NULL)
		return;

	glPushAttrib(GL_ENABLE_BIT);

	if(CGLExt::IsGL_ARB_multitexture())
	{
		// Second texture unit
		CGLExt::glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,
			GL_COMBINE_EXT);
		glTexEnvi(GL_TEXTURE_ENV, GL_RGB_SCALE_EXT, 2);
		glBindTexture(GL_TEXTURE_2D, m_texture_detail);

		glMatrixMode(GL_TEXTURE);
			glLoadIdentity();
			glScalef(m_det_level, m_det_level, 1);
		glMatrixMode(GL_MODELVIEW);

		// First texture unit
		CGLExt::glActiveTextureARB(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, m_texture);
	}
	else
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, m_texture);
	}

	register int x = 0, z = 0;
	CVector<float> v1, v2;

	const int width_half = m_width >> 1;
	const int depth_half = m_depth >> 1;

	// Triangle strip
	// 02--01:16-15:18--17
	// |  \  |  \  |  \  |
	// 04--03:14-13:20--19
	// |  \  |  \  |  \  |
	// 06--05:12-11:22--21
	// |  \  |  \  |  \  |
	// 08--07:10-09:24--23

	bool bswitch_sides = false;

	glBegin(GL_TRIANGLE_STRIP);
	for(x = 0; x < m_width; x++)
	{
		if(bswitch_sides)
		{
			for(z = m_depth-1; z >= 0; z--)
			{
				v1.SetX(x+1 - width_half);
				v1.SetY(GetHeightGLFast(x+1, z));
				v1.SetZ(z - depth_half);

				v2.SetX(x - width_half);
				v2.SetY(GetHeightGLFast(x, z));
				v2.SetZ(z - depth_half);

				SetTexCoord((float)(x+1)/(float)m_width,
						(float)z/(float)m_depth);
				glVertex3fv(v1);

				SetTexCoord((float)x/(float)m_width,
						(float)z/(float)m_depth);
				glVertex3fv(v2);
			}
		}
		else
		{
			for(z = 0; z < m_depth; z++)
			{
				v1.SetX(x+1 - width_half);
				v1.SetY(GetHeightGLFast(x+1, z));
				v1.SetZ(z - depth_half);

				v2.SetX(x - width_half);
				v2.SetY(GetHeightGLFast(x, z));
				v2.SetZ(z - depth_half);

				SetTexCoord((float)(x+1)/(float)m_width,
						(float)z/(float)m_depth);
				glVertex3fv(v1);

				SetTexCoord((float)x/(float)m_width,
						(float)z/(float)m_depth);
				glVertex3fv(v2);
			}
		}

		bswitch_sides = !bswitch_sides;
	}
	glEnd();

	glPopAttrib();
}

void CTerrain::DrawLines(bool one_direction) const
{
	if(m_pdata == NULL)
		return;

	glPushAttrib(GL_ENABLE_BIT);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, m_texture);

	register int x = 0, z = 0;

	for(x = 0; x < m_width; x++)
	{
		glBegin(GL_LINE_STRIP);
			for(z = 0; z < m_depth; z++)
			{
			glTexCoord2f((float)x/(float)m_width,
					(float)z/(float)m_depth);

			glVertex3f(	x-m_width/2,
					GetHeightGLFast(x, z),
					z-m_width/2);
			}
		glEnd();
	}

	if(!one_direction)
	{
		for(x = 0; x < m_width; x++)
		{
			glBegin(GL_LINE_STRIP);
			for(z = 0; z < m_depth; z++)
			{
				glTexCoord2f((float)z/(float)m_width,
						(float)x/(float)m_depth);

				glVertex3f(	z-m_width/2,
						GetHeightGLFast(z, x),
						x-m_width/2);
				}
			glEnd();
		}
	}

	glPopAttrib();
}

void CTerrain::DrawPoints() const
{
	if(m_pdata == NULL)
		return;

	glPushAttrib(GL_ENABLE_BIT);
	glDisable(GL_TEXTURE_2D);

	register int x = 0, z = 0;

	glBegin(GL_POINTS);
	for(x = 0; x < m_width; x++)
	{
		for(z = 0; z < m_depth; z++)
		{
			glVertex3f(	x-m_width/2,
					GetHeightGLFast(x, z),
					z-m_width/2);
		}
	}
	glEnd();

	glPopAttrib();
}

}
