/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "capplicationex.h"

namespace basecode
{

CApplicationEx::CApplicationEx() : CApplication(),
		m_font(),
		m_font_texture(0),
		m_fps_string("\0"),
		m_fps_timer_id(NULL),
		m_bshow_fps(true)
{

}

CApplicationEx::~CApplicationEx()
{
	Destroy();
}

void CApplicationEx::Destroy()
{
	FPSTimerStop();

	if(glIsTexture(m_font_texture))
	{
		glDeleteTextures(1, &m_font_texture);
		m_font_texture = 0;
	}

	m_font.Destroy();

	CApplication::Destroy();
}

void CApplicationEx::LoadSettings(const string& filename)
{
	CApplication::LoadSettings(filename);

	CIni ini;

	try
	{
		ini.Init(filename);
	}
	catch(CFileNotFound& ex)
	{
		cerr << _("Unable to load settings from ") << ex.what()
				<< _(", using predefined values.") << endl;
		return;
	}

	m_bshow_fps = ini.Read("application_ex", "show_fps", m_bshow_fps);
}

void CApplicationEx::Init(const string& win_title)
//		throw(std::runtime_error, std::bad_alloc,
//		CFileNotFound, CBadFileFormat)
{
	CApplication::Init(win_title);
	FPSTimerStart();
}

void CApplicationEx::InitGL()
//		throw(std::bad_alloc, CFileNotFound, CBadFileFormat)
{
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
		GL_LINEAR_MIPMAP_LINEAR);

	CImage img(PATH_FONT);
	m_font_texture = img.CreateGLTexture(true, false);
	m_font.Init(m_font_texture);
}

void CApplicationEx::Draw()
{
	if(m_bshow_fps)
	{
		glColor3ub(255,255,255);
		m_font.Begin();
			m_font.Draw(10, 10, m_fps_string);
		m_font.End();
	}
}

bool CApplicationEx::ProcessEvent(SDL_Event& event)
{
	switch(event.type)
	{
		case SDL_USEREVENT:
			switch(event.user.code)
			{
				case EVT_ACTUALIZE_FPS_STRING:
				{
					stringstream sbuf(m_fps_string);
					sbuf << GetFPS();
					m_fps_string = sbuf.str();
				}
				break;

				default:
					break;
			}
			break;

		case SDL_ACTIVEEVENT:// Minimalization of window
			if (event.active.state & SDL_APPACTIVE)
			{
				if (!event.active.gain)
				{
					// Timers must stop !!!
					// Warning: If there is any event(s) in
					// the queue, program won't stop
					FPSTimerStop();
					SDL_WaitEvent(NULL);
					FPSTimerStart();
				}
			}
			break;

		default:// Other events
			return CApplication::ProcessEvent(event);
			break;
	}

	return true;
}

void CApplicationEx::FPSTimerStart()
{
	if(m_bshow_fps && SDL_InitSubSystem(SDL_INIT_TIMER) != -1)
	{
		if((m_fps_timer_id = SDL_AddTimer(FPS_INTERVAL,
				FPSTimerCallback, NULL)) == NULL)
		{
			cerr << _("FPS timer couldn't be added.") << endl;
			m_bshow_fps = false;
		}
	}
}

void CApplicationEx::FPSTimerStop()
{
	if(m_bshow_fps && m_fps_timer_id != NULL)
	{
		if(!SDL_RemoveTimer(m_fps_timer_id))
		{
			cerr << _("FPS timer couldn't be removed.") << endl;
		}

		m_fps_timer_id = NULL;
	}
}

Uint32 CApplicationEx::FPSTimerCallback(Uint32 interval, void* param)
{
	SDL_Event event;
	event.type = SDL_USEREVENT;
	event.user.code = EVT_ACTUALIZE_FPS_STRING;
	event.user.data1 = NULL;
	event.user.data2 = NULL;

	if(SDL_PushEvent(&event) == -1)
		cerr << _("Unable to push FPS string actualize event.")
				<< endl;

	return interval;
}

}
