/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CDYNAMICOBJECT_H__
#define __CDYNAMICOBJECT_H__

#include "basecode.h"
#include "cstaticobject.h"

namespace basecode
{

class CDynamicObject : CStaticObject
{
public:
	CDynamicObject();
	virtual ~CDynamicObject();

	virtual void Init(GLuint texture, float width, float height,
			CVector<float>& pos, CVector<float>& vel,
			CVector<float>& acc);
	virtual void Update(float fps);

	void Start() { stopped = true; }
	void Stop() { stopped = false; }
	bool IsStopped() const { return stopped; }

	CVector<float> GetVel() const { return m_vel; }
	CVector<float> GetAcc() const { return m_acc; }
	void SetVel(CVector<float>& vel) { m_vel = vel; }
	void SetAcc(CVector<float>& acc) { m_acc = acc; }
	void AddVel(CVector<float>& dvel) { m_vel += dvel; }
	void AddAcc(CVector<float>& dacc) { m_acc += dacc; }

protected:
	bool stopped;
	CVector<float> m_vel;
	CVector<float> m_acc;
};

}

#endif
