/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cimage.h"

namespace basecode
{

CImage::CImage() :
	m_pdata(NULL),
	m_width(0),
	m_height(0),
	m_bytes_per_pixel(0)
{

}

CImage::CImage(const string & filename)
		//throw(CFileNotFound, CBadFileFormat, std::bad_alloc)
		: m_pdata(NULL)// Don't free unalocated memory
{
	Init(filename);
}

CImage::~CImage()
{
	Destroy();
}

void CImage::Destroy()
{
	if(m_pdata != NULL)
		delete [] m_pdata;

	m_pdata = NULL;

	m_width = 0;
	m_height = 0;
	m_bytes_per_pixel = 0;
}

void CImage::Init(const string & filename)
		//throw(CFileNotFound, CBadFileFormat, std::bad_alloc)
{
	Destroy();// Cleaning
	SDL_Surface* image = NULL;

	try
	{
		// Don't forget to link SDL_image library file!
		if((image = IMG_Load(filename.c_str())) == NULL)
			throw CFileNotFound(filename);

		SDL_LockSurface(image);

		m_width = image->w;
		m_height = image->h;

		if(image->format == NULL)
			throw CBadFileFormat(filename);

		Uint32 x, y, pix, change = 0, pal_index;

		Uint8* pixels = (Uint8*)image->pixels;

		if(image->format->palette == NULL)// Without pallete
		{
			m_bytes_per_pixel = image->format->BytesPerPixel;
			m_pdata = new Uint8[GetSize()];

			// BGR or BGRA image, swap B and R
			if(image->format->Bshift == 0)
			{
				if(m_bytes_per_pixel >= 3)
					change = 3;
			}

			for(y = 0; y < m_height; y++)
			{
				for(x = 0; x < m_width; x++)
				{
					// Swapped values (BGR)
					for(pix = 0; pix < change; pix++)
					{
						m_pdata[(x + (y*m_height)) * m_bytes_per_pixel
							+ (change-1 - pix)]
							= pixels[(x + ((m_height-1 - y)*m_height))
							* m_bytes_per_pixel + pix];
					}

					// Not swapped values (alfa)
					for(pix = change; pix < m_bytes_per_pixel; pix++)
					{
						m_pdata[(x + (y*m_height)) * m_bytes_per_pixel + pix]
							= pixels[(x + ((m_height-1 - y) * m_height))
							* m_bytes_per_pixel + pix];
					}
				}
			}
		}
		else// With pallete
		{
			m_bytes_per_pixel = 3;// Assumed RGB

			if(image->format->palette->colors == NULL)
				throw CBadFileFormat(filename);

			m_pdata = new Uint8[GetSize()];

			for(y = 0; y < m_height; y++)
			{
				for(x = 0; x < m_width; x++)
				{
					pal_index = pixels[x + ((m_height-1 - y) * m_height)];

					m_pdata[(x + (y*m_height)) * m_bytes_per_pixel]
						= image->format->palette->colors[pal_index].r;
					m_pdata[(x + (y*m_height)) * m_bytes_per_pixel + 1]
						= image->format->palette->colors[pal_index].g;
					m_pdata[(x + (y*m_height)) * m_bytes_per_pixel + 2]
						= image->format->palette->colors[pal_index].b;
				}
			}
		}
	}
	catch(...)
	{
		// Cleaning
		if(image != NULL)
		{
			SDL_UnlockSurface(image);
			SDL_FreeSurface(image);
		}

		Destroy();
		throw;
	}
}

GLuint CImage::CreateGLTexture(bool mipmaps, bool border) const
{
	if(m_pdata == NULL)
		return 0;

	unsigned int format;

	switch(m_bytes_per_pixel)
	{
		case 3:
			format = GL_RGB;
			break;
		case 4:
			format = GL_RGBA;
			break;
		default:
			return 0;
			break;
	}


	GLuint ret;// Texture ID

	glGenTextures(1, &ret);
	glBindTexture(GL_TEXTURE_2D, ret);

	if(mipmaps)
	{
		gluBuild2DMipmaps(GL_TEXTURE_2D, m_bytes_per_pixel, m_width,
			m_height, format, GL_UNSIGNED_BYTE, m_pdata);
	}
	else
	{
		glTexImage2D(GL_TEXTURE_2D, 0, m_bytes_per_pixel, m_width,
				m_height, (border == true) ? 1 : 0, format,
				GL_UNSIGNED_BYTE, m_pdata);
	}

	return ret;
}

}
