/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "csimplemenu.h"

namespace basecode
{

CSimpleMenu::CSimpleMenu() :
	m_font(NULL)
{

}

CSimpleMenu::~CSimpleMenu()
{

}

void CSimpleMenu::Init(CFont* font, int num_items)
{
	CMenu::Init(num_items);
	m_font = font;
}

void CSimpleMenu::Draw(int x, int y, int num_items)
{
	if(m_event_codes.size() == 0)// Empty
		return;

	int i;// For loops
	int min, max;

	min = m_selected - num_items/2;
	if(min < 0)
		min = 0;

	max = min + num_items;
	if(max > (int)m_event_codes.size())
		max = m_event_codes.size();

	if(max-min < num_items)
	{
		min = max - num_items;
		if(min < 0)
			min = 0;
	}

	if(m_font != NULL)
	{
		m_font->Begin();
			glColor3ub(0, 0, 255);
			for(i = min; i < m_selected; i++, y -= 50)
			{
//				glColor3ub(255, 255, 255);// Down left shadown
//				m_font->Draw(x+2, y-1, m_event_strings[i]);//, 2, 2);
				glColor3ub(0, 0, 255);
				m_font->Draw(x, y, m_event_strings[i], 2, 2);
			}

//			glColor3ub(255, 255, 255);
//			m_font->Draw(x+2, y-1, m_event_strings[i]);//, 2, 2);
			glColor3ub(255, 0, 0);
			m_font->Draw(x, y, m_event_strings[i], 2, 2);

			for(i++, y -= 50; i < max; i++, y -= 50)
			{
//				glColor3ub(255, 255, 255);
//				m_font->Draw(x+2, y-1, m_event_strings[i]);//, 2, 2);
				glColor3ub(0, 0, 255);
				m_font->Draw(x, y, m_event_strings[i], 2, 2);
			}
		m_font->End();
	}
}

}
