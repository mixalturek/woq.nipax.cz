/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CFONT_H__
#define __CFONT_H__

#include <string>
#include <iostream>
#include <SDL_opengl.h>
#include "basecode.h"

using namespace std;

#define SCREEN_WIDTH 800// Size of viewport
#define SCREEN_HEIGHT 600
#define CHAR_WIDTH 22// Size of characters
#define CHAR_HEIGHT 24
#define REAL_CHAR_WIDTH 10.0// Width of characters when translating

#define NUM_CHARS 256// Number of characters

#define TAB_CHARS 4.0// Width of TAB

#define ALIGN_LEFT 0// Multiline text
#define ALIGN_CENTER 1
#define ALIGN_RIGHT 2

/*
README:
- Vypis textu je VZDY nutne umistit mezi funkce Begin()/End() - neco jako
glBegin()/glEnd()
- Souradnice [x;y] u Printf*() jsou od [0;0] - levy dolni roh do [800;600] -
pravy horni roh viewportu,
  znaci levy dolni roh prvniho znaku retezce
- Netistitelne znaky (s ascii <= 32) se nevykresluji, pouze posun na nasledujici
pozici
- Tabulator '\t' preskakuje 4 znaky (sirka ctyr mezer)
- Vyceradkovy vypis:
	- Zalomezi pouze pomoci '\n', za okrajem okna se radek nezalamuje
	- Prazdne radky (\n\n) se nevypisuji (strtok() je ignoruje :-(, ale kdyz se
mezi ne vlozi mezera je vse OK)
	- U ALIGN_LEFT je [x;y] levy horni roh prvniho znaku na prvnim radku
	- U ALIGN_CENTER je [x;y] horni roh prostredniho znaku na prvnim radku
	- U ALIGN_RIGHT je [x;y] pravy horni roh posledniho znaku na prvnim radku
		x______________________________x______________________________x
		|ALIGN_LEFT              ALIGN_CENTER              ALIGN_RIGHT|
		|................      ................       ................|
		|...                          ...                          ...|
		|...........              ...........              ...........|
		|_____________________________________________________________|

- Retezce v programu a znaky na texture musi byt v odpovidajici znakove sade
(pozice v ASCII a pozice na texture stejna)
  napr. u stredoeveropskych jazyku vcetne cestiny jsou nejpouzivanejsi
ISO-8859-2 (Linux, ne-Windows systemy)
  a CP1250, nekdy take jako windows-1250 (MS Windows), pokud se nektere znaky s
hacky a carkami nevypisuji spravne
  (pravdepodobne � a � (s, z)), zkuste zmenit jejich polohu na texture
*/

namespace basecode
{

class CFont
{
public:
	CFont();
	CFont(GLuint texture);
	~CFont();

	void Init(GLuint texture);
	void Destroy();

	void Begin();
	void End();

	void Draw(int x, int y, const string & str,
			float scale_x = 1.0, float scale_y = 1.0);
//	void PrintfLines(int x, int y, const string & str, int align = ALIGN_LEFT);

	void SetTexture(GLuint texture);

private:
	GLuint m_texture;
	GLuint m_base_dlist;
};

}

#endif
