/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cteam.h"

namespace basecode
{

GLuint CTeam::m_default_texture = 0;

CTeam::CTeam() :
	m_players(NULL),
	m_num_players(DEFAULT_NUM_PLAYERS),
	m_selected(0),
	m_name(""),
	m_textures(NULL)
{

}

CTeam::~CTeam()
{
	Destroy();
}

void CTeam::Destroy()
{
	if(m_players != NULL)
	{
		delete [] m_players;
		m_players = NULL;
	}

	if(m_textures != NULL)
	{
		for(int i = 0; i < m_num_players; i++)
		{
			if(glIsTexture(m_textures[i]))
			{
				glDeleteTextures(1, &m_textures[i]);
				// m_textures[i] = 0;
			}
		}

		delete [] m_textures;
		m_textures = NULL;
	}

	m_num_players = 0;
	m_selected = 0;
	m_name.clear();
}

void CTeam::Init(const string& filename)
		//throw(std::bad_alloc, CFileNotFound, CBadFileFormat)
{
	CImage img;

	if(m_default_texture == 0)
	{
		img.Init(DEFAULT_PLAYER_TEXTURE);
		m_default_texture = img.CreateGLTexture();
	}

	Destroy();

	CIni ini(filename);
	m_name = ini.ReadString("team", "name", "team");
	m_num_players = ini.Read("team", "num_players", m_num_players);

	if(m_num_players <= 0)
		m_num_players = DEFAULT_NUM_PLAYERS;

	m_players = new CPlayer[m_num_players];
	m_textures = new GLuint[m_num_players];

	string str;
	stringstream sstream(str);

	for(int i = 0; i < m_num_players; i++)
	{
		sstream << BEGIN_NAME << i;
		m_players[i].Init(ini.ReadString(sstream.str(),
				"name", sstream.str()));
		try
		{
			img.Init(ini.ReadString(sstream.str(), "texture",
					DEFAULT_PLAYER_TEXTURE));
			m_textures[i] = img.CreateGLTexture();
			m_players[i].SetTexture(m_textures[i]);
		}
		catch(...)
		{
			m_players[i].SetTexture(m_default_texture);
		}

		sstream.str("");// Delete content
	}
}

void CTeam::SelectNext()
{
	if(++m_selected >= m_num_players)
		m_selected = 0;
}

void CTeam::SelectPrevious()
{
	if(--m_selected < 0)
		m_selected = m_num_players-1;
}

const CPlayer& CTeam::GetSelected() const
		throw(logic_error)
{
	if(m_players == NULL)
		throw logic_error(_("CTeam: Object haven't been initialized yet."));

	return m_players[m_selected];
}

}
