/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CNODEFUNCTION_HPP__
#define __CNODEFUNCTION_HPP__

#include <list>
#include "general.hpp"
#include "cnode.hpp"
#include "cnodevalue.hpp"

namespace borsch
{

class CNodeFunction : public CNode
{
public:
	CNodeFunction(const string& name, list<string>* parameters,
		CNode* block, const string& file = GENERATED, int line = 0);
	virtual ~CNodeFunction(void);

	virtual CNodeValue Execute(void);
	virtual void Dump(ostream& os, int indent = 0) const;

	const string& GetName(void) const { return m_name; }
	// The returned value may be NULL
	const list<string>* GetParameterNames(void) const { return m_parameters; }

private:
	CNodeFunction(const CNodeFunction& object);
	CNodeFunction& operator=(const CNodeFunction& object);

private:
	string m_name;
	list<string>* m_parameters;	// May be NULL
	CNode* m_block;			// May be NULL
};

}// namespace

#endif
