/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cnodevalue.hpp"


#define	THROW_ONA_EXC(str) \
	DBG_THROW(COperatorNotAllowedException((str), GetFile(), GetLine()))


namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Constructors

CNodeValue::CNodeValue(const string& file, int line)
	:
	CNode(file, line),
	m_type(LEX_VOID),
	m_s(NULL)
{

}

CNodeValue::CNodeValue(bool b, const string& file, int line)
	:
	CNode(file, line),
	m_type(LEX_BOOL),
	m_b(b)
{

}

CNodeValue::CNodeValue(int i, const string& file, int line)
	:
	CNode(file, line),
	m_type(LEX_INT),
	m_i(i)
{

}

CNodeValue::CNodeValue(float f, const string& file, int line)
	:
	CNode(file, line),
	m_type(LEX_FLOAT),
	m_f(f)
{

}

CNodeValue::CNodeValue(const string& s, const string& file, int line)
	:
	CNode(file, line),
	m_type(LEX_STRING),
	m_s(new string(s))
{

}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CNodeValue::~CNodeValue(void)
{
	if(m_type == LEX_STRING && m_s != NULL)
	{
		delete m_s;
		m_s = NULL;
	}
}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CNodeValue::Dump(ostream& os, int indent) const
{
	DumpIndent(os, indent);

	switch(m_type)
	{
	case LEX_VOID:
		os << "<Value type=\"void\">NULL</Value>" << endl;
		break;

	case LEX_BOOL:
		os << "<Value type=\"bool\">"
			<< ((m_b) ? "true" : "false") << "</Value>" << endl;
		break;

	case LEX_INT:
		os << "<Value type=\"int\">"
			<< m_i << "</Value>" << endl;
		break;

	case LEX_FLOAT:
		os << "<Value type=\"float\">"
			<< m_f << "</Value>" << endl;
		break;

	case LEX_STRING:
		os << "<Value type=\"string\">"
			<< *m_s << "</Value>" << endl;
		break;

	default:
		assert(false);
		os << "<Value type=\"unknown\">unknown</Value>" << endl;
		break;
	}
}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CNodeValue& node)
{
	node.Dump(os);
	return os;
}


/////////////////////////////////////////////////////////////////////////////
//// ToBool()

bool CNodeValue::ToBool(void) const
{
	switch(m_type)
	{
	case LEX_VOID:
		THROW_ONA_EXC(_("The operand that is converting to bool is NULL"));
	case LEX_BOOL:
		return m_b;
	case LEX_INT:
		return m_i;
	case LEX_FLOAT:
		return m_f;
	case LEX_STRING:
		THROW_ONA_EXC(_("Cannot convert string to bool"));
	default:
		assert(false);
		return false;
	}
}


/////////////////////////////////////////////////////////////////////////////
//// Copy constructor

CNodeValue::CNodeValue(const CNodeValue& object)
	: CNode(object.GetFile(), object.GetLine())
{
	m_type = object.m_type;

	switch(m_type)
	{
	case LEX_VOID:
		m_s = NULL;
		break;
	case LEX_BOOL:
		m_b = object.m_b;
		break;
	case LEX_INT:
		m_i = object.m_i;
		break;
	case LEX_FLOAT:
		m_f = object.m_f;
		break;
	case LEX_STRING:
		m_s = new string(*object.m_s);
		break;
	default:
		assert(false);
		break;
	}
}


/////////////////////////////////////////////////////////////////////////////
//// operator=

CNodeValue& CNodeValue::operator=(const CNodeValue& object)
{
	if(this->IsValid() && (*this == object).ToBool())
		return *this;

	if(m_type == LEX_STRING && m_s != NULL)
	{
		delete m_s;
		m_s = NULL;
	}

	m_type = object.m_type;

	switch(object.m_type)
	{
	case LEX_VOID:
		m_s = NULL;
		break;
	case LEX_BOOL:
		m_b = object.m_b;
		break;
	case LEX_INT:
		m_i = object.m_i;
		break;
	case LEX_FLOAT:
		m_f = object.m_f;
		break;
	case LEX_STRING:
		m_s = new string(*object.m_s);
		break;
	default:
		assert(false);
		m_s = NULL;
		break;
	}

	return *this;
}


/////////////////////////////////////////////////////////////////////////////
////

CNodeValue& CNodeValue::operator+=(const CNodeValue& object)
{
	return *this = *this + object;
}

/////////////////////////////////////////////////////////////////////////////
////


CNodeValue& CNodeValue::operator-=(const CNodeValue& object)
{
	return *this = *this - object;
}

/////////////////////////////////////////////////////////////////////////////
////


CNodeValue& CNodeValue::operator*=(const CNodeValue& object)
{
	return *this = *this * object;
}

/////////////////////////////////////////////////////////////////////////////
////


CNodeValue& CNodeValue::operator/=(const CNodeValue& object)
{
	return *this = *this / object;
}

/////////////////////////////////////////////////////////////////////////////
////


CNodeValue& CNodeValue::operator%=(const CNodeValue& object)
{
	return *this = *this % object;
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator==(const CNodeValue& object)
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator== is NULL"));

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b == object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b == object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f == object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare bool and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i == object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i == object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_i == object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare int and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_FLOAT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_f == object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_f == object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f == object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare float and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_STRING:
		switch(object.m_type)
		{
		case LEX_BOOL:
			THROW_ONA_EXC(_("Cannot compare string and bool"));
		case LEX_INT:
			THROW_ONA_EXC(_("Cannot compare string and int"));
		case LEX_FLOAT:
			THROW_ONA_EXC(_("Cannot compare string and float"));
		case LEX_STRING:
			return CNodeValue(*m_s == *object.m_s, GetFile(), GetLine());
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	default:
		assert(false);
		return CNodeValue(false, GetFile(), GetLine());
	}
}


/////////////////////////////////////////////////////////////////////////////
//// operator!=

const CNodeValue CNodeValue::operator!=(const CNodeValue& object)
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator!= is NULL"));

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b != object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b != object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f != object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare bool and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i != object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i != object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_i != object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare int and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_FLOAT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_f != object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_f != object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f != object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare float and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_STRING:
		switch(object.m_type)
		{
		case LEX_BOOL:
			THROW_ONA_EXC(_("Cannot compare string and bool"));
		case LEX_INT:
			THROW_ONA_EXC(_("Cannot compare string and int"));
		case LEX_FLOAT:
			THROW_ONA_EXC(_("Cannot compare string and float"));
		case LEX_STRING:
			return CNodeValue(*m_s != *object.m_s, GetFile(), GetLine());
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	default:
		assert(false);
		return CNodeValue(false, GetFile(), GetLine());
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator<(const CNodeValue& object)
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator< is NULL"));

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b < object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b < object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f < object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare bool and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i < object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i < object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_i < object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare int and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_FLOAT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_f < object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_f < object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f < object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare float and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_STRING:
		switch(object.m_type)
		{
		case LEX_BOOL:
			THROW_ONA_EXC(_("Cannot compare string and bool"));
		case LEX_INT:
			THROW_ONA_EXC(_("Cannot compare string and int"));
		case LEX_FLOAT:
			THROW_ONA_EXC(_("Cannot compare string and float"));
		case LEX_STRING:
			return CNodeValue(*m_s < *object.m_s, GetFile(), GetLine());
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	default:
		assert(false);
		return CNodeValue(false, GetFile(), GetLine());
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator>(const CNodeValue& object)
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator> is NULL"));

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b > object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b > object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f > object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare bool and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i > object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i > object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_i > object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare int and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_FLOAT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_f > object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_f > object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f > object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare float and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_STRING:
		switch(object.m_type)
		{
		case LEX_BOOL:
			THROW_ONA_EXC(_("Cannot compare string and bool"));
		case LEX_INT:
			THROW_ONA_EXC(_("Cannot compare string and int"));
		case LEX_FLOAT:
			THROW_ONA_EXC(_("Cannot compare string and float"));
		case LEX_STRING:
			return CNodeValue(*m_s > *object.m_s, GetFile(), GetLine());
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	default:
		assert(false);
		return CNodeValue(false, GetFile(), GetLine());
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator>=(const CNodeValue& object)
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator>= is NULL"));

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b >= object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b >= object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f >= object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare bool and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i >= object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i >= object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_i >= object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare int and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_FLOAT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_f >= object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_f >= object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f >= object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare float and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_STRING:
		switch(object.m_type)
		{
		case LEX_BOOL:
			THROW_ONA_EXC(_("Cannot compare string and bool"));
		case LEX_INT:
			THROW_ONA_EXC(_("Cannot compare string and int"));
		case LEX_FLOAT:
			THROW_ONA_EXC(_("Cannot compare string and float"));
		case LEX_STRING:
			return CNodeValue(*m_s >= *object.m_s, GetFile(), GetLine());
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	default:
		assert(false);
		return CNodeValue(false, GetFile(), GetLine());
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator<=(const CNodeValue& object)
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator<= is NULL"));

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b <= object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b <= object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f <= object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare bool and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i <= object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i <= object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_i <= object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare int and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_FLOAT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_f <= object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_f <= object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f <= object.m_f, GetFile(), GetLine());
		case LEX_STRING:
			THROW_ONA_EXC(_("Cannot compare float and string"));
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	case LEX_STRING:
		switch(object.m_type)
		{
		case LEX_BOOL:
			THROW_ONA_EXC(_("Cannot compare string and bool"));
		case LEX_INT:
			THROW_ONA_EXC(_("Cannot compare string and int"));
		case LEX_FLOAT:
			THROW_ONA_EXC(_("Cannot compare string and float"));
		case LEX_STRING:
			return CNodeValue(*m_s <= *object.m_s, GetFile(), GetLine());
		default:
			assert(false);
			return CNodeValue(false, GetFile(), GetLine());
		}
	default:
		assert(false);
		return CNodeValue(false, GetFile(), GetLine());
	}
}

/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator!()
{
	switch(m_type)
	{
	case LEX_VOID:
		THROW_ONA_EXC(_("The operand of operator! is NULL"));
	case LEX_BOOL:
		return CNodeValue(!m_b, GetFile(), GetLine());
	case LEX_INT:
		return CNodeValue(!m_i, GetFile(), GetLine());
	case LEX_FLOAT:
		return CNodeValue(!m_f, GetFile(), GetLine());
	case LEX_STRING:
		THROW_ONA_EXC(_("Cannot use operator! with string type"));
	default:
		assert(false);
		return CNodeValue(false, GetFile(), GetLine());
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue& CNodeValue::operator++()// Prefix
{
	switch(m_type)
	{
	case LEX_VOID:
		THROW_ONA_EXC(_("The operand of operator++ is NULL"));
	case LEX_BOOL:
		++m_b;
		return *this;
	case LEX_INT:
		++m_i;
		return *this;
	case LEX_FLOAT:
		++m_f;
		return *this;
	case LEX_STRING:
		THROW_ONA_EXC(_("Cannot use operator++ with string type"));
	default:
		assert(false);
		return *this;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator++(int)// Postfix
{
	switch(m_type)
	{
	case LEX_VOID:
		THROW_ONA_EXC(_("The operand of operator++ is NULL"));
	case LEX_BOOL:
		return CNodeValue(m_b++, GetFile(), GetLine());
	case LEX_INT:
		return CNodeValue(m_i++, GetFile(), GetLine());
	case LEX_FLOAT:
		return CNodeValue(m_f++, GetFile(), GetLine());
	case LEX_STRING:
		THROW_ONA_EXC(_("Cannot use operator++ with string type"));
	default:
		assert(false);
		return *this;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue& CNodeValue::operator--()// Prefix
{
	switch(m_type)
	{
	case LEX_VOID:
		THROW_ONA_EXC(_("The operand of operator-- is NULL"));
	case LEX_BOOL:
		THROW_ONA_EXC(_("Cannot use operator-- with bool type"));
	case LEX_INT:
		--m_i;
		return *this;
	case LEX_FLOAT:
		--m_f;
		return *this;
	case LEX_STRING:
		THROW_ONA_EXC(_("Cannot use operator-- with string type"));
	default:
		assert(false);
		return *this;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator--(int)// Postfix
{
	switch(m_type)
	{
	case LEX_VOID:
		THROW_ONA_EXC(_("The operand of operator-- is NULL"));
	case LEX_BOOL:
		THROW_ONA_EXC(_("Cannot use operator-- with bool type"));
	case LEX_INT:
		return CNodeValue(m_i--, GetFile(), GetLine());
	case LEX_FLOAT:
		return CNodeValue(m_f--, GetFile(), GetLine());
	case LEX_STRING:
		THROW_ONA_EXC(_("Cannot use operator-- with string type"));
	default:
		assert(false);
		return *this;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator-() const
{
	switch(m_type)
	{
	case LEX_VOID:
		THROW_ONA_EXC(_("The operand of operator- is NULL"));
	case LEX_BOOL:
		return CNodeValue(-m_b, GetFile(), GetLine());
	case LEX_INT:
		return CNodeValue(-m_i, GetFile(), GetLine());
	case LEX_FLOAT:
		return CNodeValue(-m_f, GetFile(), GetLine());
	case LEX_STRING:
		THROW_ONA_EXC(_("Cannot use operator-- with string type"));
	default:
		assert(false);
		return *this;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator+(const CNodeValue& object) const
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator+ is NULL"));

	// Second is string, but first not
	if(object.m_type == LEX_STRING && m_type != LEX_STRING)
		THROW_ONA_EXC(_("Cannot use operator+ with string type on the right when there is not string on the left"));

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b + object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b + object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_b + object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i + object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i + object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_i + object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	case LEX_FLOAT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_f + object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_f + object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f + object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	case LEX_STRING:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(*m_s + ((object.m_b) ? "true" : "false"), GetFile(), GetLine());
		case LEX_INT:
		{
			stringstream ss;
			ss << object.m_i;
			return CNodeValue(*m_s + ss.str(), GetFile(), GetLine());
		}
		case LEX_FLOAT:
		{
			stringstream ss;
			ss << object.m_f;
			return CNodeValue(*m_s + ss.str(), GetFile(), GetLine());
		}
		case LEX_STRING:
			return CNodeValue(*m_s + *object.m_s, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	default:
		assert(false);
		return *this;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator-(const CNodeValue& object) const
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator- is NULL"));

	if(m_type == LEX_STRING || object.m_type == LEX_STRING)
		THROW_ONA_EXC(_("Cannot use operator- with string type"));

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b - object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b - object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_b - object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i - object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i - object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_i - object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	case LEX_FLOAT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_f - object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_f - object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f - object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	default:
		assert(false);
		return *this;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator*(const CNodeValue& object) const
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator* is NULL"));

	if(m_type == LEX_STRING || object.m_type == LEX_STRING)
		THROW_ONA_EXC(_("Cannot use operator* with string type"));

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b * object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b * object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_b * object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i * object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i * object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_i * object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	case LEX_FLOAT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_f * object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_f * object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f * object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	default:
		assert(false);
		return *this;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator/(const CNodeValue& object) const
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator/ is NULL"));

	if(m_type == LEX_STRING || object.m_type == LEX_STRING)
		THROW_ONA_EXC(_("Cannot use operator/ with string type"));

	switch(object.m_type)
	{
	case LEX_BOOL:
		if(object.m_b == false)
			THROW_ONA_EXC(_("Division by zero"));
	case LEX_INT:
		if(object.m_i == 0)
			THROW_ONA_EXC(_("Division by zero"));
	case LEX_FLOAT:
		if(object.m_f == 0.0f)
			THROW_ONA_EXC(_("Division by zero"));
	default:
		assert(false);
		return *this;
	}

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b / object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b / object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_b / object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i / object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i / object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_i / object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	case LEX_FLOAT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_f / object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_f / object.m_i, GetFile(), GetLine());
		case LEX_FLOAT:
			return CNodeValue(m_f / object.m_f, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	default:
		assert(false);
		return *this;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator%(const CNodeValue& object) const
{
	if(m_type == LEX_VOID || object.m_type == LEX_VOID)
		THROW_ONA_EXC(_("The operand of operator% is NULL"));

	if(m_type == LEX_STRING || object.m_type == LEX_STRING)
		THROW_ONA_EXC(_("Cannot use operator% with string type"));

	if(m_type == LEX_FLOAT || object.m_type == LEX_FLOAT)
		THROW_ONA_EXC(_("Cannot use operator% with float type"));

	switch(object.m_type)
	{
	case LEX_BOOL:
		if(object.m_b == false)
			THROW_ONA_EXC(_("Division by zero"));
	case LEX_INT:
		if(object.m_i == 0)
			THROW_ONA_EXC(_("Division by zero"));
	default:
		break;
	}

	switch(m_type)
	{
	case LEX_BOOL:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_b % object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_b % object.m_i, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	case LEX_INT:
		switch(object.m_type)
		{
		case LEX_BOOL:
			return CNodeValue(m_i % object.m_b, GetFile(), GetLine());
		case LEX_INT:
			return CNodeValue(m_i % object.m_i, GetFile(), GetLine());
		default:
			assert(false);
			return *this;
		}
	default:
		assert(false);
		return *this;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator&&(const CNodeValue& object) const
{
	return CNodeValue(this->ToBool() && object.ToBool());
}


/////////////////////////////////////////////////////////////////////////////
////

const CNodeValue CNodeValue::operator||(const CNodeValue& object) const
{
	return CNodeValue(this->ToBool() || object.ToBool());
}

}// namespace
