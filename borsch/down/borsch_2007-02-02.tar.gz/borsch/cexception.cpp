/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cexception.hpp"

namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Constructor

CUnexpectedTokenException::CUnexpectedTokenException(LEXTOKEN found,
	const string& file, int line)
	:
	runtime_error(file),
	m_found(found),
	m_line(line)
{

}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CUnexpectedTokenException& ex)
{
	stringstream ss;
	ss << _("Unexpected token ") << GetTokenName(ex.GetFound());
	PRINT_ERROR(os, ex.GetFile(), ex.GetLine(), ss.str());

	return os;
}


/////////////////////////////////////////////////////////////////////////////
//// Constructor

CNotAssignableException::CNotAssignableException(
	const string& file, int line)
	:
	runtime_error(file),
	m_line(line)
{

}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CNotAssignableException& ex)
{
	PRINT_ERROR(os, ex.GetFile(), ex.GetLine(), _("The operand is not assignable to"));

	return os;
}


/////////////////////////////////////////////////////////////////////////////
//// Constructor

COperatorNotAllowedException::COperatorNotAllowedException(
	const string& what, const string& file, int line)
	:
	runtime_error(what),
	m_file(file),
	m_line(line)
{

}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const COperatorNotAllowedException& ex)
{
	PRINT_ERROR(os, ex.GetFile(), ex.GetLine(), ex.what());

	return os;
}


/////////////////////////////////////////////////////////////////////////////
//// Constructor

CBadFunctionCallException::CBadFunctionCallException(
	const string& what, const string& file, int line)
	:
	runtime_error(what),
	m_file(file),
	m_line(line)
{

}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CBadFunctionCallException& ex)
{
	PRINT_ERROR(os, ex.GetFile(), ex.GetLine(), ex.what());

	return os;
}


/////////////////////////////////////////////////////////////////////////////
//// Constructor

CVariableNotInitializedException::CVariableNotInitializedException(
	const string& what, const string& file, int line)
	:
	runtime_error(what),
	m_file(file),
	m_line(line)
{

}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CVariableNotInitializedException& ex)
{
	PRINT_ERROR(os, ex.GetFile(), ex.GetLine(), ex.what());

	return os;
}

}// namespace
