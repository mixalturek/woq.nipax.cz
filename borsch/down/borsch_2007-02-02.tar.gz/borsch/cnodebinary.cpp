/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cnodebinary.hpp"

#include "cnodevariable.hpp"
#include "ccontext.hpp"


namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Constructor

CNodeBinary::CNodeBinary(CNode* left, CNode* right, LEXTOKEN op,
	const string& file, int line)
	:
	CNode(file, line),
	m_left(left),
	m_right(right),
	m_op(op)
{
	assert(left != NULL);
	assert(right != NULL);
}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CNodeBinary::~CNodeBinary(void)
{
	delete m_left;
	m_left = NULL;

	delete m_right;
	m_right = NULL;
}


/////////////////////////////////////////////////////////////////////////////
//// Execute()

CNodeValue CNodeBinary::Execute(void)
{
	switch(m_op)
	{
	case LEX_OP_EQUAL:
		return m_left->Execute() == m_right->Execute();

	case LEX_OP_NOT_EQ:
		return m_left->Execute() != m_right->Execute();

	case LEX_OP_LESS:
		return m_left->Execute() < m_right->Execute();

	case LEX_OP_LESS_EQ:
		return m_left->Execute() <= m_right->Execute();

	case LEX_OP_GREATER:
		return m_left->Execute() > m_right->Execute();

	case LEX_OP_GREATER_EQ:
		return m_left->Execute() >= m_right->Execute();

	case LEX_OP_PLUS:
		return m_left->Execute() + m_right->Execute();

	case LEX_OP_MINUS:
		return m_left->Execute() - m_right->Execute();

	case LEX_OP_MULT:
		return m_left->Execute() * m_right->Execute();

	case LEX_OP_DIV:
		return m_left->Execute() / m_right->Execute();

	case LEX_OP_MOD:
		return m_left->Execute() % m_right->Execute();

	case LEX_OP_AND:
		return m_left->Execute() && m_right->Execute();

	case LEX_OP_OR:
		return m_left->Execute() || m_right->Execute();

/*	// Not implemented by CParser
	case LEX_OP_COMMA:
		m_left->Execute();
		return m_right->Execute();
*/

	case LEX_OP_ASSIGN:
	{
		CNodeVariable* var = dynamic_cast<CNodeVariable*>(m_left);
		assert(var != NULL);
		return CContext::Instance().GetLocalVariable(var->GetName(), true) = m_right->Execute();
	}

	case LEX_OP_PLUS_AS:
	{
		CNodeVariable* var = dynamic_cast<CNodeVariable*>(m_left);
		assert(var != NULL);
		return CContext::Instance().GetLocalVariable(var->GetName(), true) += m_right->Execute();
	}

	case LEX_OP_MINUS_AS:
	{
		CNodeVariable* var = dynamic_cast<CNodeVariable*>(m_left);
		assert(var != NULL);
		return CContext::Instance().GetLocalVariable(var->GetName(), true) -= m_right->Execute();
	}

	case LEX_OP_MULT_AS:
	{
		CNodeVariable* var = dynamic_cast<CNodeVariable*>(m_left);
		assert(var != NULL);
		return CContext::Instance().GetLocalVariable(var->GetName(), true) *= m_right->Execute();
	}

	case LEX_OP_DIV_AS:
	{
		CNodeVariable* var = dynamic_cast<CNodeVariable*>(m_left);
		assert(var != NULL);
		return CContext::Instance().GetLocalVariable(var->GetName(), true) /= m_right->Execute();
	}

	case LEX_OP_MOD_AS:
	{
		CNodeVariable* var = dynamic_cast<CNodeVariable*>(m_left);
		assert(var != NULL);
		return CContext::Instance().GetLocalVariable(var->GetName(), true) %= m_right->Execute();
	}

	default:
		assert(false);
		return CNodeValue(GetFile(), GetLine());
	}
}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CNodeBinary::Dump(ostream& os, int indent) const
{
	this->DumpIndent(os, indent);
	os << "<BinaryOperator type=\"" << GetTokenName(m_op) << "\">" << endl;

	DumpIndent(os, indent + 1); os << "<LeftTree>" << endl;
	m_left->Dump(os, indent + 2);
	DumpIndent(os, indent + 1); os << "</LeftTree>" << endl;

	DumpIndent(os, indent + 1); os << "<RightTree>" << endl;
	m_right->Dump(os, indent + 2);
	DumpIndent(os, indent + 1); os << "</RightTree>" << endl;

	DumpIndent(os, indent); os << "</BinaryOperator>" << endl;
}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CNodeBinary& node)
{
	node.Dump(os);
	return os;
}


}// namespace
