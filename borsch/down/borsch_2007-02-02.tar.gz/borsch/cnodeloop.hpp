/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CNODELOOP_HPP__
#define __CNODELOOP_HPP__

#include "general.hpp"
#include "cnode.hpp"
#include "cnodevalue.hpp"

namespace borsch
{

class CNodeLoop : public CNode
{
public:
	CNodeLoop(CNode* init, CNode* condition, CNode* inc, CNode* body,
		const string& file = GENERATED, int line = 0);
	virtual ~CNodeLoop(void);

	virtual CNodeValue Execute(void);
	virtual void Dump(ostream& os, int indent = 0) const;

private:
	CNodeLoop(const CNodeLoop& object);
	CNodeLoop& operator=(const CNodeLoop& object);

private:
	CNode* m_init;		// May be NULL
	CNode* m_condition;	// If NULL, then CNodeValue(true) is created
	CNode* m_inc;		// May be NULL
	CNode* m_body;
};

ostream& operator<<(ostream& os, const CNodeLoop& node);

}// namespace

#endif
