/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cnodeloop.hpp"

#include "cnodejump.hpp"


namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Default constructor

CNodeLoop::CNodeLoop(CNode* init, CNode* condition, CNode* inc, CNode* body,
	const string& file, int line)
	:
	CNode(file, line),
	m_init(init),
	m_condition((condition != NULL) ? condition : new CNodeValue(true)),
	m_inc(inc),
	m_body(body)
{
	// The parameters init and inc may be NULL!
	assert(body != NULL);
}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CNodeLoop::~CNodeLoop(void)
{
	if(m_init != NULL)
	{
		delete m_init;
		m_init = NULL;
	}

	delete m_condition;
	m_condition = NULL;

	if(m_inc != NULL)
	{
		delete m_inc;
		m_inc = NULL;
	}

	delete m_body;
	m_body = NULL;
}


/////////////////////////////////////////////////////////////////////////////
//// Execute()

CNodeValue CNodeLoop::Execute(void)
{
	if(m_init != NULL)
		m_init->Execute();

	try
	{
		while(m_condition->Execute().ToBool())
		{
			try
			{
				m_body->Execute();
			}
			catch(CContinueException& ex)
			{
				// Need only the exception jump
			}

			if(m_inc != NULL)
				m_inc->Execute();
		}
	}
	catch(CBreakException& ex)
	{
		// Need only the exception jump
	}

	return CNodeValue();
}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CNodeLoop::Dump(ostream& os, int indent) const
{
	DumpIndent(os, indent);
	os << "<Loop>" << endl;

	DumpIndent(os, indent + 1);
	os << "<Init>" << endl;
	if(m_init != NULL)
		m_init->Dump(os, indent + 2);
	DumpIndent(os, indent + 1);
	os << "</Init>" << endl;

	DumpIndent(os, indent + 1);
	os << "<Condition>" << endl;
	m_condition->Dump(os, indent + 2);
	DumpIndent(os, indent + 1);
	os << "</Condition>" << endl;

	DumpIndent(os, indent + 1);
	os << "<Inc>" << endl;
	if(m_inc != NULL)
		m_inc->Dump(os, indent + 2);
	DumpIndent(os, indent + 1);
	os << "</Inc>" << endl;

	DumpIndent(os, indent + 1);
	os << "<Body>" << endl;
	m_body->Dump(os, indent + 2);
	DumpIndent(os, indent + 1);
	os << "</Body>" << endl;

	DumpIndent(os, indent);
	os << "</Loop>" << endl;
}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CNodeLoop& node)
{
	node.Dump(os);
	return os;
}

}// namespace
