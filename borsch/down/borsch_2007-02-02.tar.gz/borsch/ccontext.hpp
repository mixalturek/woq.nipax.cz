/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CCONTEXT_HPP__
#define __CCONTEXT_HPP__

#include <list>
#include <map>
#include <stack>
#include <algorithm>
#include "general.hpp"
#include "cnodevalue.hpp"
#include "cnodefunction.hpp"

namespace borsch
{

//class CNodeValue;
//class CNodeFunction;

class CContext
{
public:
	// Return the singleton object
	static inline CContext& Instance(void)
	{
		static CContext instance;
		return instance;
	}

	// Add new function to the list
	void AddFunction(CNodeFunction* function) { m_functions.push_back(function); }

	// If the function is not defined, return NULL
	CNodeFunction* GetFunction(const string& name);

	// Return local variable. If there is no variable of this name and
	// create parameter is true, new variable will be created, but it
	// will have invalid value.
	CNodeValue& GetLocalVariable(const string& name, bool create = false);

	// Return global variable. If there is no variable of this name and
	// create parameter is true, new variable will be created, but it
	// will have invalid value.
	CNodeValue& GetGlobalVariable(const string& name, bool create = false);

	// Create new and delete actual "function call stack entries"
	void PushLocal(void) { m_local_variables.push(map<string, CNodeValue>()); };
	void PopLocal(void) { m_local_variables.pop(); }

	void Dump(ostream& os, int indent) const;

private:
	CContext(void);
	~CContext(void);

	CContext(const CContext& object);
	CContext& operator=(const CContext& object);

private:
	list<CNodeFunction*> m_functions;
	map<string, CNodeValue> m_global_variables;
	stack< map<string, CNodeValue> > m_local_variables;
};

ostream& operator<<(ostream& os, const CContext& node);

}// namespace

#endif
