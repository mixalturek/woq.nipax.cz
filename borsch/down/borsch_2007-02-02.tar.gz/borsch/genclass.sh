#!/bin/bash
#
# Copyright (C) 2006 Michal Turek
# http://woq.nipax.cz/
# License: GNU GPL v2
#
# This script generates .hpp and .cpp files for C++ class


if [ $# -lt 1 ]; then
        echo "Usage:"
        echo "$0 <class name>"
        exit 1
fi

CLASSNAME=$1
NAMESPACE="borsch"
CPP="`echo $CLASSNAME | tr [A-Z] [a-z]`.cpp"
HPP="`echo $CLASSNAME | tr [A-Z] [a-z]`.hpp"



echo '/***************************************************************************' >> $HPP
echo ' *   Borsch interpreter                                                    *' >> $HPP
echo ' *   Copyright (C) 2006 Michal Turek                                       *' >> $HPP
echo ' *   http://woq.nipax.cz/                                                  *' >> $HPP
echo ' *                                                                         *' >> $HPP
echo ' *   This program is free software; you can redistribute it and/or modify  *' >> $HPP
echo ' *   it under the terms of the GNU Library General Public License as       *' >> $HPP
echo ' *   published by the Free Software Foundation; version 2 of the License   *' >> $HPP
echo ' *                                                                         *' >> $HPP
echo ' *   This program is distributed in the hope that it will be useful,       *' >> $HPP
echo ' *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *' >> $HPP
echo ' *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *' >> $HPP
echo ' *   GNU General Public License for more details.                          *' >> $HPP
echo ' *                                                                         *' >> $HPP
echo ' *   You should have received a copy of the GNU Library General Public     *' >> $HPP
echo ' *   License along with this program; if not, write to the                 *' >> $HPP
echo ' *   Free Software Foundation, Inc.,                                       *' >> $HPP
echo ' *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *' >> $HPP
echo ' ***************************************************************************/' >> $HPP
echo >> $HPP

echo "#ifndef __`echo $CLASSNAME | tr [a-z] [A-Z]`_HPP__" >> $HPP
echo "#define __`echo $CLASSNAME | tr [a-z] [A-Z]`_HPP__" >> $HPP
echo >> $HPP

echo 'namespace borsch' >> $HPP
echo '{' >> $HPP
echo >> $HPP

echo "class $CLASSNAME" >> $HPP
echo '{' >> $HPP
echo 'public:' >> $HPP
echo "	$CLASSNAME(void);" >> $HPP
echo "	~$CLASSNAME(void);" >> $HPP
echo >> $HPP
echo 'private:' >> $HPP
echo "	$CLASSNAME(const $CLASSNAME& object);" >> $HPP
echo "	$CLASSNAME& operator=(const $CLASSNAME& object);" >> $HPP
echo '};' >> $HPP
echo >> $HPP

echo '}// namespace' >> $HPP
echo >> $HPP

echo '#endif' >> $HPP




echo '/***************************************************************************' >> $CPP
echo ' *   Borsch interpreter                                                    *' >> $CPP
echo ' *   Copyright (C) 2006 Michal Turek                                       *' >> $CPP
echo ' *   http://woq.nipax.cz/                                                  *' >> $CPP
echo ' *                                                                         *' >> $CPP
echo ' *   This program is free software; you can redistribute it and/or modify  *' >> $CPP
echo ' *   it under the terms of the GNU Library General Public License as       *' >> $CPP
echo ' *   published by the Free Software Foundation; version 2 of the License   *' >> $CPP
echo ' *                                                                         *' >> $CPP
echo ' *   This program is distributed in the hope that it will be useful,       *' >> $CPP
echo ' *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *' >> $CPP
echo ' *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *' >> $CPP
echo ' *   GNU General Public License for more details.                          *' >> $CPP
echo ' *                                                                         *' >> $CPP
echo ' *   You should have received a copy of the GNU Library General Public     *' >> $CPP
echo ' *   License along with this program; if not, write to the                 *' >> $CPP
echo ' *   Free Software Foundation, Inc.,                                       *' >> $CPP
echo ' *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *' >> $CPP
echo ' ***************************************************************************/' >> $CPP
echo >> $CPP

echo "#include \"$HPP\"" >> $CPP
echo >> $CPP

echo 'namespace borsch' >> $CPP
echo '{' >> $CPP
echo >> $CPP

echo '/////////////////////////////////////////////////////////////////////////////' >> $CPP
echo '//// Default constructor' >> $CPP
echo >> $CPP
echo "$CLASSNAME::$CLASSNAME(void)" >> $CPP
echo '{' >> $CPP
echo >> $CPP
echo '}' >> $CPP
echo >> $CPP
echo >> $CPP

echo '/////////////////////////////////////////////////////////////////////////////' >> $CPP
echo '//// Destructor' >> $CPP
echo >> $CPP
echo "$CLASSNAME::~$CLASSNAME(void)" >> $CPP
echo '{' >> $CPP
echo >> $CPP
echo '}' >> $CPP
echo >> $CPP
echo >> $CPP

echo '/*' >> $CPP
echo '/////////////////////////////////////////////////////////////////////////////' >> $CPP
echo '//// Copy constructor' >> $CPP
echo >> $CPP
echo "$CLASSNAME::$CLASSNAME(const $CLASSNAME& object)" >> $CPP
echo '{' >> $CPP
echo >> $CPP
echo '}' >> $CPP
echo >> $CPP
echo >> $CPP

# http://www.cs.caltech.edu/courses/cs11/material/cpp/donnie/cpp-ops.html
echo '/////////////////////////////////////////////////////////////////////////////' >> $CPP
echo '//// operator=' >> $CPP
echo >> $CPP
echo "$CLASSNAME& $CLASSNAME::operator=(const $CLASSNAME& object)" >> $CPP
echo '{' >> $CPP
echo '	if(*this == object)' >> $CPP
echo '		return *this;' >> $CPP
echo >> $CPP
echo '	return *this;' >> $CPP
echo '}' >> $CPP
echo '*/' >> $CPP
echo >> $CPP

echo '}// namespace' >> $CPP
