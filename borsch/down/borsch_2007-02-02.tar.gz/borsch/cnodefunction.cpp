/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cnodefunction.hpp"

#include "ccontext.hpp"
#include "cnodeblock.hpp"
#include "cnodejump.hpp"


namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Default constructor

CNodeFunction::CNodeFunction(const string& name, list<string>* parameters,
	CNode* block, const string& file, int line)
	:
	CNode(file, line),
	m_name(name),
	m_parameters(parameters),
	m_block(block)
{

}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CNodeFunction::~CNodeFunction(void)
{
	if(m_parameters != NULL)
	{
		delete m_parameters;
		m_parameters = NULL;
	}

	if(m_block != NULL)
	{
		delete m_block;
		m_block = NULL;
	}
}


/////////////////////////////////////////////////////////////////////////////
//// Execute()

CNodeValue CNodeFunction::Execute(void)
{
	// Faster, buildin functions has always NULL
	// Defined at CParser::GenerateBuildinFunctions()
	if(m_block == NULL)
	{
		CContext& context = CContext::Instance();

		if(m_name == "echo")
		{
			CNodeValue& var = context.GetLocalVariable("param");

			switch(var.GetType())
			{
			case LEX_BOOL:
				cout << var.GetBool();
				break;
			case LEX_INT:
				cout << var.GetInt();
				break;
			case LEX_FLOAT:
				cout << var.GetFloat();
				break;
			case LEX_STRING:
				cout << *var.GetString();
				break;
			default:
				assert(false);
				return CNodeValue(GetFile(), GetLine());
			}

			return var;
		}

		if(m_name == "exit")
			DBG_THROW(CExitException(context.GetLocalVariable("param"), GetFile(), GetLine()));

		if(m_name == "get_global")
		{
			CNodeValue tmp = context.GetLocalVariable("name");

			if(!tmp.IsString())
			{
				DBG_THROW(CBadFunctionCallException(
					_("Buildin function get_global() expects string value as the parameter"),
					GetFile(), GetLine()));
			}

			return context.GetGlobalVariable(*tmp.GetString());
		}

		if(m_name == "set_global")
		{
			CNodeValue tmp = context.GetLocalVariable("name");

			if(!tmp.IsString())
			{
				DBG_THROW(CBadFunctionCallException(
					_("Buildin function get_global() expects string value as the first parameter"),
					GetFile(), GetLine()));
			}

			return context.GetGlobalVariable(*context.GetLocalVariable("name").GetString(), true)
				= context.GetLocalVariable("value");
		}
	}

	try
	{
		if(m_block != NULL)
			m_block->Execute();
	}
	catch(CReturnException& ex)
	{
		return ex.GetValue();
	}

	return CNodeValue(GetFile(), GetLine());
}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CNodeFunction::Dump(ostream& os, int indent) const
{
	DumpIndent(os, indent);
	os << "<Function name=\"" << m_name << "\">" << endl;

	if(m_parameters != NULL)
	{
		list<string>::const_iterator it;

		for(it = m_parameters->begin(); it != m_parameters->end(); it++)
		{
			DumpIndent(os, indent + 1);
			os << "<Parameter>" << *it << "</Parameter>" << endl;
		}
	}

	if(m_block != NULL)
		m_block->Dump(os, indent + 1);

	DumpIndent(os, indent);
	os << "</Function>" << endl;
}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CNodeFunction& node)
{
	node.Dump(os);
	return os;
}

}// namespace
