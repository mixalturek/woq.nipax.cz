/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CLEXAN_HPP__
#define __CLEXAN_HPP__

#include <fstream>
#include <map>
#include <cctype>
#include <cmath>
#include "general.hpp"
#include "lextoken.hpp"

namespace borsch
{

class CLexan
{
public:
	CLexan(const string& filename);
	~CLexan(void);

	LEXTOKEN Next(void);

	const string& GetFilename(void) const	{ return m_included ? m_included->GetFilename() : m_filename; }
	int GetLine(void) const			{ return m_included ? m_included->GetLine() : m_line; }

	bool GetBool(void) const		{ return m_included ? m_included->GetInt() != 0 : m_int != 0; }
	int GetInt(void) const		{ return m_included ? m_included->GetInt() : m_int; }
	float GetFloat(void) const		{ return m_included ? m_included->GetFloat() : m_float; }
	const string& GetString(void) const	{ return m_included ? m_included->GetString() : m_string; }

private:
	LEXTOKEN Keyword(const string& str);

private:
	string		m_filename;
	ifstream	m_file;
	int		m_line;

	int		m_int;
	float		m_float;
	string		m_string;

	CLexan*		m_included;

private:
	enum STATE
	{
		ST_DEFAULT,		// 		0

		ST_CPP_COMMENT,		// //		3
		ST_C_COMMENT,		// /*		4
		ST_C_COMMENT_END,	// */		5

		ST_ID,			// function	6
		ST_VARIABLE,		// $variable

		ST_STRING,		// "		7
		ST_STRING_ESC,		// \		9
		ST_STRING_ESC_HEX,	// \x		10
		ST_STRING_ESC_HEX_1,	// \xA		11
		ST_STRING_ESC_OCT,	// \12		12
		ST_STRING_ESC_OCT_1,	// \123		13

		ST_INT,			// 5		14
		ST_INT_ZERO,		// 0		15
		ST_INT_OCT,		// 02		16
		ST_INT_HEX,		// 0xffe	18
		ST_FLOAT,		// 0.58		19
		ST_EXP_SIGN,		// 15e-		21
		ST_EXP,			// 15e4		22

		ST_OP_ASSIGN,		// =
		ST_OP_NOT,		// !
		ST_OP_LESS,		// <
		ST_OP_GREATER,		// >
		ST_OP_PLUS,		// +		23
		ST_OP_MINUS,		// -
		ST_OP_MULT,		// *
		ST_OP_DIV,		// /		1
		ST_OP_MOD,		// %
		ST_OP_POINT,		// . (concatenation)
		ST_OP_AND,		// &&
		ST_OP_OR		// ||
	};

private:
	CLexan(void);
	CLexan(const CLexan& object);
	CLexan& operator=(const CLexan& object);
};

}// namespace

#endif
