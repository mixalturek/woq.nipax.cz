/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CPARSER_HPP__
#define __CPARSER_HPP__

#include "general.hpp"
#include "lextoken.hpp"
#include "clexan.hpp"
#include "cnode.hpp"
#include "cnodeblock.hpp"


namespace borsch
{

class CParser
{
public:
	CParser(CLexan& lexan);
	~CParser(void);

	bool Parse(void);
	int Execute(void);
	void Dump(ostream& os) const;

private:
	CParser(const CParser& object);
	CParser& operator=(const CParser& object);

	// Start symbol
	void S(void);

	list<string>* Params(void);
	list<string>* Params_c(void);
	CNode* Cmd(void);
	CNode* Cmd_c(void);
	CNodeBlock* Block(void);
	CNode* Ee(void);

	// Expressions
	CNode* E(void);
	CNode* A(void);
	CNode* B(void);
	CNode* C(void);
	CNode* D(void);
	CNode* F(void);
	CNode* G(void);
	CNodeBlock* L(void);
	CNode* E_c(CNode* node);
	CNode* A_c(CNode* node);
	CNode* B_c(CNode* node);
	CNode* C_c(CNode* node);
	CNode* D_c(CNode* node);
	CNode* F_c(CNode* node);
	CNode* G_c(CNode* node);
	CNodeBlock* L_c(void);

	void GenerateBuildinFunctions(void);

private:
	CLexan& m_lexan;
	LEXTOKEN m_next_token;
	CNodeBlock m_global_block;
};

ostream& operator<<(ostream& os, const CParser& node);

}// namespace

#endif
