/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cnode.hpp"

namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Constructor

CNode::CNode(const string& file, int line)
	:
	m_file(file),
	m_line(line)
{

}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CNode::~CNode(void)
{

}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CNode::Dump(ostream& os, int indent) const
{
//	DumpIndent(indent);
	os << m_file << ":" << m_line;
}


/////////////////////////////////////////////////////////////////////////////
//// DumpIndent()

void CNode::DumpIndent(ostream& os, int indent)
{
	for(int i = 0; i < indent; i++)
		os << "    ";
}



/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CNode& node)
{
	node.Dump(os);
	return os;
}

}// namespace
