/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cnodeunary.hpp"

#include "cnodeemptycommand.hpp"
#include "cnodevariable.hpp"
#include "cnodejump.hpp"
#include "ccontext.hpp"


namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Constructor

CNodeUnary::CNodeUnary(CNode* next, LEXTOKEN op, const string& file, int line)
	:
	CNode(file, line),
	m_next((next != NULL) ? next : new CNodeEmptyCommand(file, line)),
	m_op(op)
{
//	assert(next != NULL);
}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CNodeUnary::~CNodeUnary(void)
{
//	if(m_next != NULL)
//	{
		delete m_next;
		m_next = NULL;
//	}
}


/////////////////////////////////////////////////////////////////////////////
//// Execute()

CNodeValue CNodeUnary::Execute(void)
{
	switch(m_op)
	{
	case LEX_OP_NOT:
		return !m_next->Execute();

	case LEX_OP_MINUS:
		return -m_next->Execute();

	// Useless, not implemented by CParser
//	case LEX_OP_PLUS:
//		return m_next->Eval();// Only return the value

	case LEX_OP_PLUS_PLUS:
	{
		CNodeVariable* var = dynamic_cast<CNodeVariable*>(m_next);
		assert(var != NULL);
		return ++CContext::Instance().GetLocalVariable(var->GetName(), true);
	}

	case LEX_OP_PLUS_PLUS_POST:
	{
		CNodeVariable* var = dynamic_cast<CNodeVariable*>(m_next);
		assert(var != NULL);
		return CContext::Instance().GetLocalVariable(var->GetName(), true)++;
	}

	case LEX_OP_MINUS_MINUS:
	{
		CNodeVariable* var = dynamic_cast<CNodeVariable*>(m_next);
		assert(var != NULL);
		return --CContext::Instance().GetLocalVariable(var->GetName(), true);
	}

	case LEX_OP_MINUS_MINUS_POST:
	{
		CNodeVariable* var = dynamic_cast<CNodeVariable*>(m_next);
		assert(var != NULL);
		return CContext::Instance().GetLocalVariable(var->GetName(), true)--;
	}

	case LEX_RETURN:
		throw CReturnException(m_next->Execute(), m_next->GetFile(), m_next->GetLine());

	default:
		assert(false);
		return CNodeValue(GetFile(), GetLine());
	}
}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CNodeUnary::Dump(ostream& os, int indent) const
{
	DumpIndent(os, indent);
	os << "<UnaryOperator type=\"" << GetTokenName(m_op) << "\">" << endl;

//	if(m_next != NULL)
		m_next->Dump(os, indent+1);

	DumpIndent(os, indent);
	os << "</UnaryOperator>" << endl;
}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CNodeUnary& node)
{
	node.Dump(os);
	return os;
}

}// namespace
