/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CEXCEPTION_HPP__
#define __CEXCEPTION_HPP__

#include <stdexcept>
#include <sstream>
#include "general.hpp"
#include "lextoken.hpp"

namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
////

class CUnexpectedTokenException : public runtime_error
{
public:
	CUnexpectedTokenException(LEXTOKEN found, const string& file, int line);
	virtual ~CUnexpectedTokenException(void) throw() { }

	LEXTOKEN GetFound(void) const { return m_found; }
	const string GetFile(void) const { return runtime_error::what(); }
	int GetLine(void) const { return m_line; }

private:
	// Use operator<< instead
	virtual const char* what(void) const throw() { assert(false); return NULL; }

private:
	LEXTOKEN m_found;
//	const string m_file;// string in base class
	int m_line;
};

ostream& operator<<(ostream& os, const CUnexpectedTokenException& ex);


/////////////////////////////////////////////////////////////////////////////
////

class CNotAssignableException : public runtime_error
{
public:
	CNotAssignableException(const string& file, int line);
	virtual ~CNotAssignableException(void) throw() { }

	const string GetFile(void) const { return runtime_error::what(); }
	int GetLine(void) const { return m_line; }

private:
	// Use operator<< instead
	virtual const char* what(void) const throw() { assert(false); return NULL; }

private:
	LEXTOKEN m_found;
//	const string m_file;// string in base class
	int m_line;
};

ostream& operator<<(ostream& os, const CNotAssignableException& ex);


/////////////////////////////////////////////////////////////////////////////
////

// Used at CNodeValue::operatorXXX()
class COperatorNotAllowedException : public runtime_error
{
public:
	COperatorNotAllowedException(const string& what, const string& file, int line);
	virtual ~COperatorNotAllowedException(void) throw() { }

	const string GetFile(void) const { return m_file; }
	int GetLine(void) const { return m_line; }

private:
	const string m_file;
	int m_line;
};

ostream& operator<<(ostream& os, const COperatorNotAllowedException& ex);


/////////////////////////////////////////////////////////////////////////////
////

class CBadFunctionCallException : public runtime_error
{
public:
	CBadFunctionCallException(const string& what, const string& file, int line);
	virtual ~CBadFunctionCallException(void) throw() { }

	const string GetFile(void) const { return m_file; }
	int GetLine(void) const { return m_line; }

private:
	const string m_file;
	int m_line;
};

ostream& operator<<(ostream& os, const CBadFunctionCallException& ex);


/////////////////////////////////////////////////////////////////////////////
////

class CVariableNotInitializedException : public runtime_error
{
public:
	CVariableNotInitializedException(const string& what, const string& file, int line);
	virtual ~CVariableNotInitializedException(void) throw() { }

	const string GetFile(void) const { return m_file; }
	int GetLine(void) const { return m_line; }

private:
	const string m_file;
	int m_line;
};

ostream& operator<<(ostream& os, const CVariableNotInitializedException& ex);

}// namespace

#endif
