/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cnodeifelse.hpp"

namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Default constructor

CNodeIfElse::CNodeIfElse(CNode* condition, CNode* if_section, CNode* else_section,
	const string& file, int line)
	:
	CNode(file, line),
	m_condition(condition),
	m_if_section(if_section),
	m_else_section(else_section)
{
	assert(condition != NULL);
	assert(if_section != NULL);
}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CNodeIfElse::~CNodeIfElse(void)
{
	delete m_condition;
	m_condition = NULL;

	delete m_if_section;
	m_if_section = NULL;

	if(m_else_section != NULL)
	{
		delete m_else_section;
		m_else_section = NULL;
	}
}


/////////////////////////////////////////////////////////////////////////////
//// Execute()

CNodeValue CNodeIfElse::Execute(void)
{
	if(m_condition->Execute().ToBool())
		m_if_section->Execute();
	else if(m_else_section != NULL)
		m_else_section->Execute();

	return CNodeValue();
}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CNodeIfElse::Dump(ostream& os, int indent) const
{

	DumpIndent(os, indent);
	os << "<If>" << endl;

	DumpIndent(os, indent + 1);
	os << "<Condition>" << endl;
	m_condition->Dump(os, indent + 2);
	DumpIndent(os, indent + 1);
	os << "</Condition>" << endl;

	m_if_section->Dump(os, indent + 1);
	DumpIndent(os, indent);
	os << "</If>" << endl;

	if(m_else_section != NULL)
	{
		DumpIndent(os, indent);
		os << "<Else>" << endl;
		m_else_section->Dump(os, indent + 1);
		DumpIndent(os, indent);
		os << "</Else>" << endl;
	}
}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CNodeIfElse& node)
{
	node.Dump(os);
	return os;
}

}// namespace
