/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CNODEEMPTYCOMMAND_HPP__
#define __CNODEEMPTYCOMMAND_HPP__

#include "general.hpp"
#include "cnode.hpp"
#include "cnodevalue.hpp"

namespace borsch
{

class CNodeEmptyCommand : public CNode
{
public:
	CNodeEmptyCommand(const string& file = GENERATED, int line = 0);
	virtual ~CNodeEmptyCommand(void);

	virtual CNodeValue Execute(void);
	virtual void Dump(ostream& os, int indent = 0) const;

private:
	CNodeEmptyCommand(const CNodeEmptyCommand& object);
	CNodeEmptyCommand& operator=(const CNodeEmptyCommand& object);
};

ostream& operator<<(ostream& os, const CNodeEmptyCommand& node);

}// namespace

#endif
