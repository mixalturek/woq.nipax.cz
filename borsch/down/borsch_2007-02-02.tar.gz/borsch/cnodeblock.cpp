/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cnodeblock.hpp"

namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Constructor

CNodeBlock::CNodeBlock(const string& file, int line)
	:
	CNode(file, line),
	m_commands()
{

}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CNodeBlock::~CNodeBlock(void)
{
	list<CNode*>::iterator it;

	for(it = m_commands.begin(); it != m_commands.end(); it++)
	{
		delete (*it);
		*it = NULL;
	}

	m_commands.clear();
}


/////////////////////////////////////////////////////////////////////////////
//// Execute()

CNodeValue CNodeBlock::Execute(void)
{
	list<CNode*>::iterator it;

	for(it = m_commands.begin(); it != m_commands.end(); it++)
		(*it)->Execute();

	return CNodeValue();
}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CNodeBlock::Dump(ostream& os, int indent) const
{
//	DumpIndent(os, indent);
//	os << "<Block>" << endl;

	list<CNode*>::const_iterator it;

	for(it = m_commands.begin(); it != m_commands.end(); it++)
		(*it)->Dump(os, indent);

//	DumpIndent(os, indent);
//	os << "</Block>" << endl;
}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CNodeBlock& node)
{
	node.Dump(os);
	return os;
}

}// namespace
