/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __LEXTOKEN_HPP__
#define __LEXTOKEN_HPP__

namespace borsch
{

enum LEXTOKEN
{
	LEX_NULL = 0,		// Nothing, end of file
	LEX_ERROR,		// Error

	LEX_FUNC_NAME,		// function, etc.		+ string
	LEX_VARIABLE,		// $variable			+ string

	LEX_VOID,		// (not used by lexan)
	LEX_BOOL,		// true, false			+ bool
	LEX_INT,		// 58				+ int
	LEX_FLOAT,		// 0.58				+ float
	LEX_STRING,		// "string\n"			+ string

	LEX_OP_ASSIGN,		// =
	LEX_OP_EQUAL,		// ==
	LEX_OP_NOT_EQ,		// !=
	LEX_OP_LESS,		// <
	LEX_OP_LESS_EQ,		// <=
	LEX_OP_GREATER,		// >
	LEX_OP_GREATER_EQ,	// >=
	LEX_OP_PLUS,		// +
	LEX_OP_PLUS_AS,		// +=
	LEX_OP_PLUS_PLUS,	// ++
	LEX_OP_PLUS_PLUS_POST,	// ++ (not used by lexan)
	LEX_OP_MINUS,		// -
	LEX_OP_MINUS_AS,	// -=
	LEX_OP_MINUS_MINUS,	// --
	LEX_OP_MINUS_MINUS_POST,// -- (not used by lexan)
	LEX_OP_MULT,		// *
	LEX_OP_MULT_AS,		// *=
	LEX_OP_DIV,		// /
	LEX_OP_DIV_AS,		// /=
	LEX_OP_MOD,		// %
	LEX_OP_MOD_AS,		// %=
	LEX_OP_POINT,		// . (concatenation)	NOT IMPLEMENTED IN PARSER
	LEX_OP_POINT_AS,	// .=			NOT IMPLEMENTED IN PARSER
	LEX_OP_NOT,		// !
	LEX_OP_AND,		// &&
	LEX_OP_OR,		// ||

	LEX_OP_COMMA,		// ,
	LEX_SEMICOLON,		// ;
	LEX_LPA,		// (
	LEX_RPA,		// )
	LEX_LVA,		// {
	LEX_RVA,		// }

	LEX_IF,			// if
	LEX_ELSE,		// else
	LEX_FOR,		// for
	LEX_WHILE,		// while
	LEX_FUNCTION,		// function
	LEX_RETURN,		// return
	LEX_BREAK,		// break
	LEX_CONTINUE		// continue
};


/////////////////////////////////////////////////////////////////////////////
//// GetTokenName()

inline string GetTokenName(LEXTOKEN token)
{
	static string table[] =
	{
		"LEX_NULL",
		"LEX_ERROR",

		"LEX_FUNC_NAME",
		"LEX_VARIABLE",

		"LEX_VOID",
		"LEX_BOOL",
		"LEX_INT",
		"LEX_FLOAT",
		"LEX_STRING",

		"LEX_OP_ASSIGN",
		"LEX_OP_EQUAL",
		"LEX_OP_NOT_EQ",
		"LEX_OP_LESS",
		"LEX_OP_LESS_EQ",
		"LEX_OP_GREATER",
		"LEX_OP_GREATER_EQ",
		"LEX_OP_PLUS",
		"LEX_OP_PLUS_AS",
		"LEX_OP_PLUS_PLUS",
		"LEX_OP_PLUS_PLUS_POST",
		"LEX_OP_MINUS",
		"LEX_OP_MINUS_AS",
		"LEX_OP_MINUS_MINUS",
		"LEX_OP_MINUS_MINUS_POST",
		"LEX_OP_MULT",
		"LEX_OP_MULT_AS",
		"LEX_OP_DIV",
		"LEX_OP_DIV_AS",
		"LEX_OP_MOD",
		"LEX_OP_MOD_AS",
		"LEX_OP_POINT",
		"LEX_OP_POINT_AS",
		"LEX_OP_NOT",
		"LEX_OP_AND",
		"LEX_OP_OR",

		"LEX_OP_COMMA",
		"LEX_SEMICOLON",
		"LEX_LPA",
		"LEX_RPA",
		"LEX_LVA",
		"LEX_RVA",

		"LEX_IF",
		"LEX_ELSE",
		"LEX_FOR",
		"LEX_WHILE",
		"LEX_FUNCTION",
		"LEX_RETURN",
		"LEX_BREAK",
		"LEX_CONTINUE"
	};

	return table[token];
}

}// namespace

#endif
