/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cnodefunccall.hpp"

#include "ccontext.hpp"
#include "cnodefunction.hpp"


namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Default constructor

CNodeFuncCall::CNodeFuncCall(const string& name, CNodeBlock* parameters,
	const string& file, int line)
	:
	CNode(file, line),
	m_name(name),
	m_parameters(parameters)
{

}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CNodeFuncCall::~CNodeFuncCall(void)
{
	if(m_parameters != NULL)
	{
		delete m_parameters;
		m_parameters = NULL;
	}
}


/////////////////////////////////////////////////////////////////////////////
//// Execute()

CNodeValue CNodeFuncCall::Execute(void)
{
	// TODO: Prvniho syna pojmenovat Borsch, prvni dceru Schi a prvniho
	// psa Morozhenoe - to bude familie.

	CContext& context = CContext::Instance();
	CNodeFunction* function = context.GetFunction(m_name);

	if(function == NULL)
	{
		DBG_THROW(CBadFunctionCallException(
			_("Function ") + m_name + _("() has not been declared"),
			GetFile(), GetLine()));
	}

	// May be NULL
	const list<string>* param_names = function->GetParameterNames();

	if(param_names == NULL)
	{
		if(m_parameters == NULL)
		{
			// OK, no parameters specified, no parameters passed

			context.PushLocal();
			CNodeValue ret = function->Execute();
			context.PopLocal();

			return ret;
		}
		else
		{
			DBG_THROW(CBadFunctionCallException(
				_("Function ") + m_name + _("() does not expect parameters, but some were passed"),
				GetFile(), GetLine()));
		}
	}
	else
	{
		if(m_parameters == NULL)
		{
			DBG_THROW(CBadFunctionCallException(
				_("Function ") + m_name + _("() expects parameters, but nothing has been passed"),
				GetFile(), GetLine()));
		}
		else
		{
			if((int)param_names->size() == m_parameters->GetNumOfCommands())
			{
				// OK, right number of parameters was passed

				list<CNodeValue> values;
				list<CNode*>::iterator it_commands;

				// Evaluate parameters in the old function context
				for(it_commands = m_parameters->m_commands.begin() ; it_commands != m_parameters->m_commands.end(); it_commands++)
					values.push_back((*it_commands)->Execute());

				context.PushLocal();
					list<string>::const_iterator it_names;
					list<CNodeValue>::iterator it_values = values.begin();

					// Set parameters in the new function context
					for(it_names = param_names->begin(); it_names != param_names->end(); it_names++, it_values++)
						context.GetLocalVariable(*it_names, true) = *it_values;

					CNodeValue ret = function->Execute();
				context.PopLocal();

				return ret;
			}
			else
			{
				DBG_THROW(CBadFunctionCallException(
					_("Wrong number of parameters has been passed to the function ") + m_name + _("()"),
					GetFile(), GetLine()));
			}
		}
	}

	// Never should be called
	assert(false);
	return CNodeValue();
}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CNodeFuncCall::Dump(ostream& os, int indent) const
{
	DumpIndent(os, indent);
	os << "<FunctionCall name=\"" << m_name << "\">" << endl;

	DumpIndent(os, indent + 1);
	os << "<Parameters>" << endl;

	if(m_parameters != NULL)
		m_parameters->Dump(os, indent + 2);

	DumpIndent(os, indent + 1);
	os << "<Parameters>" << endl;

	DumpIndent(os, indent);
	os << "</FunctionCall>" << endl;
}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CNodeFuncCall& node)
{
	node.Dump(os);
	return os;
}

}// namespace
