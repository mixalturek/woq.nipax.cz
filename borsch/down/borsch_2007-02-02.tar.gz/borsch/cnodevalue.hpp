/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CNODEVALUE_HPP__
#define __CNODEVALUE_HPP__

#include <sstream>
#include "general.hpp"
#include "lextoken.hpp"
#include "cnode.hpp"
#include "cexception.hpp"

namespace borsch
{

/*
// !!! Always handle the COperatorNotAllowedException when using this class !!!

try
{
	CNodeValue a(false);
	CNodeValue b("some string");

	if(a < b)
		cout << "This will never be called because of exception." << endl;
}
catch(COperatorNotAllowedException& ex)
{
	// Handle the exception
}
*/

class CNodeValue : public CNode
{
public:
	explicit CNodeValue(const string& file = GENERATED, int line = 0);
	explicit CNodeValue(bool b, const string& file = GENERATED, int line = 0);
	explicit CNodeValue(int i, const string& file = GENERATED, int line = 0);
	explicit CNodeValue(float f, const string& file = GENERATED, int line = 0);
	explicit CNodeValue(const string& s, const string& file = GENERATED, int line = 0);
	CNodeValue(const CNodeValue& object);
	virtual ~CNodeValue(void);


	virtual CNodeValue Execute(void) { return *this; };
	virtual void Dump(ostream& os, int indent = 0) const;


	CNodeValue& operator=(const CNodeValue& object);
	CNodeValue& operator+=(const CNodeValue& object);
	CNodeValue& operator-=(const CNodeValue& object);
	CNodeValue& operator*=(const CNodeValue& object);
	CNodeValue& operator/=(const CNodeValue& object);
	CNodeValue& operator%=(const CNodeValue& object);

	const CNodeValue operator!();
	const CNodeValue operator==(const CNodeValue& object);
	const CNodeValue operator!=(const CNodeValue& object);
	const CNodeValue operator<=(const CNodeValue& object);
	const CNodeValue operator>=(const CNodeValue& object);
	const CNodeValue operator<(const CNodeValue& object);
	const CNodeValue operator>(const CNodeValue& object);

	const CNodeValue& operator++();// Prefix
	const CNodeValue  operator++(int);// Postfix
	const CNodeValue& operator--();// Prefix
	const CNodeValue  operator--(int);// Postfix

	const CNodeValue operator-() const;
	const CNodeValue operator+(const CNodeValue& object) const;
	const CNodeValue operator-(const CNodeValue& object) const;
	const CNodeValue operator*(const CNodeValue& object) const;
	const CNodeValue operator/(const CNodeValue& object) const;
	const CNodeValue operator%(const CNodeValue& object) const;

	const CNodeValue operator&&(const CNodeValue& object) const;
	const CNodeValue operator||(const CNodeValue& object) const;


	LEXTOKEN GetType(void) const { return m_type; }

	bool IsValid(void) const { return m_type != LEX_VOID; }
	bool IsNull(void) const { return m_type == LEX_VOID;}
	bool IsBool(void) const { return m_type == LEX_BOOL;}
	bool IsInt(void) const { return m_type == LEX_INT;}
	bool IsFloat(void) const { return m_type == LEX_FLOAT;}
	bool IsString(void) const { return m_type == LEX_STRING;}

	bool GetBool(void) const { assert(m_type == LEX_BOOL); return m_b; }
	int GetInt(void) const { assert(m_type == LEX_INT); return m_i; }
	float GetFloat(void) const { assert(m_type == LEX_FLOAT); return m_f; }

	// Returns pointer to the internal buffer that can be deleted by assign,
	// so copy the value if you want to store it
	const string* GetString(void) const { assert(m_type == LEX_STRING); return m_s; }

	// Use in conditions
	bool ToBool(void) const;

private:
	LEXTOKEN m_type;

	union
	{
		bool m_b;
		int m_i;
		float m_f;
		string* m_s;
	};
};

ostream& operator<<(ostream& os, const CNodeValue& node);

}// namespace

#endif
