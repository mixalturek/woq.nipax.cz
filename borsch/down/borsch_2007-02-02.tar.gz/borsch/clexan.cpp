/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "clexan.hpp"

namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Char2String()

inline string c2s(const char ch)
{
        char tmp[2] = { ch, '\0' };
        return string(tmp);
}


/////////////////////////////////////////////////////////////////////////////
//// Constructor

CLexan::CLexan(const string& filename) :
	m_filename(filename),
	m_file(filename.c_str(), ios::in),
	m_line(1),
	m_int(0),
	m_float(0.0f),
	m_string(""),
	m_included(NULL)
{
	if(!m_file.is_open())
		DBG_THROW(runtime_error(_("Unable to open file ") + filename));
}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CLexan::~CLexan(void)
{
	if(m_included != NULL)
	{
		delete m_included;
		m_included = NULL;
	}

	if(m_file.is_open())
		m_file.close();
}


/////////////////////////////////////////////////////////////////////////////
//// Keyword()

LEXTOKEN CLexan::Keyword(const string& str)
{
	if(str == "if")
		return LEX_IF;
	if(str == "else")
		return LEX_ELSE;
	if(str == "for")
		return LEX_FOR;
	if(str == "while")
		return LEX_WHILE;
	if(str == "function")
		return LEX_FUNCTION;
	if(str == "return")
		return LEX_RETURN;
	if(str == "break")
		return LEX_BREAK;
	if(str == "continue")
		return LEX_CONTINUE;
	if(str == "true")
	{
		m_int = 1;
		return LEX_BOOL;
	}
	if(str == "false")
	{
		m_int = 0;
		return LEX_BOOL;
	}
	if(str == "include")
	{
		// Valid syntax is include("filename.txt");
		if(Next() == LEX_LPA && Next() == LEX_STRING)
		{
			// The path is absolute or relative to the program executable
			string filename = GetString();

			if(Next() == LEX_RPA && Next() == LEX_SEMICOLON)
			{
				try
				{
					m_included = new CLexan(filename);

					LEXTOKEN tmp = m_included->Next();

					// No command in the file
					if(tmp == LEX_NULL)
					{
						delete m_included;
						m_included = NULL;

						return Next();
					}

					return tmp;
				}
				catch(runtime_error& ex)
				{
					PRINT_ERROR(cerr, m_filename, m_line, string(_("Unable to include file ")) + filename);
					return LEX_ERROR;
				}
			}
			else
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Invalid syntax of the include statement"));
				return LEX_ERROR;
			}
		}
		else
		{
			PRINT_ERROR(cerr, m_filename, m_line, _("Invalid syntax of the include statement"));
			return LEX_ERROR;
		}
	}

	return LEX_FUNC_NAME;
}


/////////////////////////////////////////////////////////////////////////////
//// Next()

LEXTOKEN CLexan::Next(void)
{
	if(m_included != NULL)
	{
		LEXTOKEN tmp = m_included->Next();

		if(tmp == LEX_NULL)// EOF
		{
			delete m_included;
			m_included = NULL;
		}
		else
		{
			return tmp;
		}
	}

	int c;
	STATE state = ST_DEFAULT;

	float float_dms = 0.1;	// Multiplier of float number (after point)
	int exp = 0;		// Exponent
	int exp_sign = 1;	// 1 or -1


	while(true)
	{
		c = m_file.get();

		switch(state)
		{
		case ST_DEFAULT:		//		0
			if(isspace(c))
			{
				if(c == '\n')
					m_line++;

				break;
			}
			if(isalpha(c) || c == '_')
			{
				state = ST_ID;
				m_string = c;
				break;
			}
			if(c == '$')
			{
				state = ST_VARIABLE;
				m_string.clear();
				break;
			}

			if(c == '0')
			{
				state = ST_INT_ZERO;
				m_int = 0;
				break;
			}
			if(c >= '1' && c <= '9')// != 0, this is not octal!
			{
				state = ST_INT;
				m_int = c - '0';
				break;
			}

			if(c == ',')
				return LEX_OP_COMMA;
			if(c == ';')
				return LEX_SEMICOLON;
			if(c == '(')
				return LEX_LPA;
			if(c == ')')
				return LEX_RPA;
			if(c == '{')
				return LEX_LVA;
			if(c == '}')
				return LEX_RVA;

			if(c == '=')
			{
				state = ST_OP_ASSIGN;
				break;
			}
			if(c == '+')
			{
				state = ST_OP_PLUS;
				break;
			}
			if(c == '-')
			{
				state = ST_OP_MINUS;
				break;
			}
			if(c == '*')
			{
				state = ST_OP_MULT;
				break;
			}
			if(c == '/')
			{
				state = ST_OP_DIV;
				break;
			}
			if(c == '%')
			{
				state = ST_OP_MOD;
				break;
			}
			if(c == '.')
			{
				state = ST_OP_POINT;
				break;
			}
			if(c == '<')
			{
				state = ST_OP_LESS;
				break;
			}
			if(c == '>')
			{
				state = ST_OP_GREATER;
				break;
			}
			if(c == '!')
			{
				state = ST_OP_NOT;
				break;
			}
			if(c == '&')
			{
				state = ST_OP_AND;
				break;
			}
			if(c == '|')
			{
				state = ST_OP_OR;
				break;
			}

			if(c == '"')
			{
				state = ST_STRING;
				m_string.clear();
				break;
			}

			if(c == EOF)
			{
				return LEX_NULL;
			}

			PRINT_ERROR(cerr, m_filename, m_line, string(_("Unexpected character: ")) + c2s(c));
			return LEX_ERROR;


		case ST_CPP_COMMENT:		// //		3
			if(c == '\n')
			{
				state = ST_DEFAULT;
				m_line++;
				break;
			}
			if(c == EOF)
			{
				return LEX_NULL;
			}

			// Stay in this state
			break;

		case ST_C_COMMENT:		// /*		4
			if(c == '*')
			{
				state = ST_C_COMMENT_END;
				break;
			}
			if(c == '\n')
			{
				m_line++;
				break;
			}
			if(c == EOF)
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Unexpected end of file, unterminated /* C-style */ comment"));
				return LEX_ERROR;
			}

			// Stay in this state
			break;

		case ST_C_COMMENT_END:		// */		5
			if(c == '/')
			{
				state = ST_DEFAULT;
				break;
			}
			if(c == '*')// /****something*like*this*****/
			{
				// Stay in this state
				break;
			}
			if(c == '\n')
			{
				// Stay in this state
				m_line++;
				break;
			}
			if(c == EOF)
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Unexpected end of file, unterminated /* C-style */ comment"));
				return LEX_ERROR;
			}

			// Everything else
			state = ST_C_COMMENT;
			break;

		case ST_ID:			// smth		6
			if(isalnum(c) || c == '_')
			{
				// Stay in this state
				m_string += c;
				break;
			}

			m_file.unget();
			return Keyword(m_string);


		case ST_VARIABLE:		// $variable
			if(isalnum(c) || c == '_')
			{
				// Stay in this state
				m_string += c;
				break;
			}

			m_file.unget();
			return LEX_VARIABLE;

		case ST_STRING:			// "		7
			if(c == '\\')// Escape character
			{
				state = ST_STRING_ESC;
				break;
			}
			if(c == '"')// End of string
			{
				return LEX_STRING;
			}
			if(c == '\n')
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Unexpected end of line, unterminated string constant"));
				m_line++;
				return LEX_ERROR;
			}
			if(c == EOF)
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Unexpected end of file, unterminated string constant"));
				return LEX_ERROR;
			}

			// Stay in this state
			m_string += c;
			break;

		case ST_STRING_ESC:		// \escape	9
			if(c == 'a')// \a - Alert (Bell)
			{
				m_string += '\a';
				state = ST_STRING;
				break;
			}
			if(c == 'b')// \b - Backspace
			{
				m_string += '\b';
				state = ST_STRING;
				break;
			}
			if(c == 'f')// \f - Formfeed
			{
				m_string += '\f';
				state = ST_STRING;
				break;
			}
			if(c == 'n')// \n - Newline
			{
				m_string += '\n';
				state = ST_STRING;
				break;
			}
			if(c == 'r')// \r - Carriage return
			{
				m_string += '\r';
				state = ST_STRING;
				break;
			}
			if(c == 't')// \t - Horizontal tab
			{
				m_string += '\t';
				state = ST_STRING;
				break;
			}
			if(c == 'v')// \v - Vertical tab
			{
				m_string += '\v';
				state = ST_STRING;
				break;
			}
			if(c == 'x')// \xHH - HEX
			{
				m_int = 0;
				state = ST_STRING_ESC_HEX;
				break;
			}
			if(c >= '0' && c <= '7')// \000 - OCT
			{
				m_int = c - '0';
				state = ST_STRING_ESC_OCT;
				break;
			}
			if(c == '\\')// \\ Backslash
			{
				m_string += '\\';
				state = ST_STRING;
				break;
			}
			if(c == '\'')// \' Single quote
			{
				m_string += '\'';
				state = ST_STRING;
				break;
			}
			if(c == '\"')// \" Double quote
			{
				m_string += '\"';
				state = ST_STRING;
				break;
			}
			if(c == '\r')// Trash MS Windows \r
			{
				PRINT_WARNING(cerr, m_filename, m_line, _("CR character (\\r or 13 in ascii) was detected in string escape sequence after backslash. This can be OK when you want to use multiline string here and your script uses CR-LF style of lines termination (common for text editors under MS Windows(R))"));

				// Stay in this state and hope \n will continue
				break;
			}
			if(c == '\n')// Multiline string
			{
				m_line++;
				state = ST_STRING;
				break;
			}
			if(c == EOF)
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Unexpected end of file, unterminated string constant"));
				return LEX_ERROR;
			}

			PRINT_WARNING(cerr, m_filename, m_line, string(_("Unrecognized escape sequence in string constant: \\")) + c2s(c));
			m_string += '\\';
			m_string += c;
			state = ST_STRING;
			break;

		case ST_STRING_ESC_HEX:		// \xA		10
			if(isdigit(c))
			{
				m_int = c - '0';
				state = ST_STRING_ESC_HEX_1;
				break;
			}
			c = tolower(c);
			if(c >= 'a' && c <= 'f')
			{
				m_int = 10 + c - 'a';
				state = ST_STRING_ESC_HEX_1;
				break;
			}
			if(c == EOF)
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Unexpected end of file, unterminated string constant"));
				return LEX_ERROR;
			}

			PRINT_WARNING(cerr, m_filename, m_line, string(_("Character '")) + c2s(c) + _("' is not valid in HEX escape sequence context"));
			m_string += "\\x";
			m_file.unget();
			state = ST_STRING;
			break;

		case ST_STRING_ESC_HEX_1:	// \xAB		11
			if(isdigit(c))
			{
				m_int <<= 4;
				m_int += c - '0';
				m_string += m_int;
				state = ST_STRING;
				break;
			}
			c = tolower(c);
			if(c >= 'a' && c <= 'f')
			{
				m_int <<= 4;
				m_int += 10 + c - 'a';
				m_string += m_int;
				state = ST_STRING;
				break;
			}
			if(c == EOF)
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Unexpected end of file, unterminated string constant"));
				return LEX_ERROR;
			}

			PRINT_WARNING(cerr, m_filename, m_line, string(_("Character '")) + c2s(c) + _("' is not valid in HEX escape sequence context"));
			m_string += "\\x";
			m_string += (m_int < 10) ? '0' + m_int : 'a' + m_int - 10;// TODO: lower/upper
			m_file.unget();
			state = ST_STRING;
			break;

		case ST_STRING_ESC_OCT:		// \12		12
			if(c >= '0' && c <= '7')
			{
				m_int <<= 3;
				m_int += c - '0';
				state = ST_STRING_ESC_OCT_1;
				break;
			}
			if(c == EOF)
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Unexpected end of file, unterminated string constant"));
				return LEX_ERROR;
			}

			PRINT_WARNING(cerr, m_filename, m_line, string(_("Character '")) + c2s(c) + _("' is not valid in OCT escape sequence"));
			m_string += '\\';
			m_string += '0' + m_int;
			m_file.unget();
			state = ST_STRING;
			break;

		case ST_STRING_ESC_OCT_1:	// \123		13
			if(c >= '0' && c <= '7')
			{
				m_int <<= 3;
				m_int += c - '0';

				if(m_int > 255)
				{
					PRINT_WARNING(cerr, m_filename, m_line, _("The value of OCT escape sequence is too big ( > 0377)"));
					m_string += '\\';
					m_string += '0' + (m_int>>6);
					m_string += '0' + (m_int>>3)%8;
					m_string += '0' + m_int%8;
				}
				else
				{
					m_string += m_int;
				}

				state = ST_STRING;
				break;
			}
			if(c == EOF)
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Unexpected end of file, unterminated string constant"));
				return LEX_ERROR;
			}

			PRINT_WARNING(cerr, m_filename, m_line, string(_("Character '")) + c2s(c) + _("' is not valid in OCT escape sequence context"));
			m_string += '\\';
			m_string += '0' + (m_int>>3);
			m_string += '0' + m_int%8;
			m_file.unget();
			state = ST_STRING;
			break;

		case ST_INT:			// 5		14
			if(isdigit(c))
			{
				// Stay in this state
				m_int *= 10;
				m_int += c - '0';
				break;
			}
			if(c == '.')
			{
				m_float = m_int;
				state = ST_FLOAT;
				break;
			}
			if(tolower(c) == 'e')
			{
				m_float = m_int;
				state = ST_EXP_SIGN;
				break;
			}

			m_file.unget();
			return LEX_INT;

		case ST_INT_ZERO:		// 0		15
			if(c >= '0' && c <= '7')
			{
				m_int = c - '0';
				state = ST_INT_OCT;
				break;
			}
			if(c >= '8' && c <= '9')
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Numbers 8 and 9 are not valid in OCT escape sequence context"));
				return LEX_ERROR;
			}
			if(c == '.')
			{
				m_float = 0.0f;
				state = ST_FLOAT;
				break;
			}
			if(tolower(c) == 'x')
			{
				m_int = 0;
				state = ST_INT_HEX;
				break;
			}

			m_int = 0;
			m_file.unget();
			return LEX_INT;

		case ST_INT_OCT:		// 02		16
			if(c >= '0' && c <= '7')
			{
				m_int <<= 3;
				m_int += c - '0';
				break;
			}
			if(c >= '8' && c <= '9')
			{
				PRINT_ERROR(cerr, m_filename, m_line, _("Numbers 8 and 9 are not valid in OCT escape sequence context"));
				return LEX_ERROR;
			}

			m_file.unget();
			return LEX_INT;

		case ST_INT_HEX:		// 0xffe	18
			if(isdigit(c))
			{
				m_int <<= 4;
				m_int += c - '0';
				break;
			}
			c = tolower(c);
			if(c >= 'a' && c <= 'f')
			{
				m_int <<= 4;
				m_int += 10 + c - 'a';
				break;
			}

			m_file.unget();
			return LEX_INT;

		case ST_FLOAT:			// 0.6		19
			if(isdigit(c))
			{
				m_float += (c - '0') * float_dms;
				float_dms /= 10.0f;
				break;
			}
			if(tolower(c) == 'e')
			{
				state = ST_EXP_SIGN;
				break;
			}

			m_file.unget();
			return LEX_FLOAT;

		case ST_EXP_SIGN:		// 15e-		21
			if(isdigit(c))
			{
				exp = c - '0';
				state = ST_EXP;
				break;
			}
			if(c == '-')
			{
				exp_sign = -1;
				state = ST_EXP;
				break;
			}
			if(c == '+')
			{
				exp_sign = 1;
				state = ST_EXP;
				break;
			}
			break;

		case ST_EXP:			// 15e4		22
			if(isdigit(c))
			{
				exp *= 10;
				exp += c - '0';
				break;
			}

			m_file.unget();
			m_float *= pow(10.0, exp * exp_sign);
			return LEX_FLOAT;

		case ST_OP_ASSIGN:		// =
			if(c == '=')
				return LEX_OP_EQUAL;

			m_file.unget();
			return LEX_OP_ASSIGN;

		case ST_OP_LESS:		// <
			if(c == '=')
				return LEX_OP_LESS_EQ;

			m_file.unget();
			return LEX_OP_LESS;

		case ST_OP_NOT:
			if(c == '=')
				return LEX_OP_NOT_EQ;

			m_file.unget();
			return LEX_OP_NOT;

		case ST_OP_GREATER:		// >
			if(c == '=')
				return LEX_OP_GREATER_EQ;

			m_file.unget();
			return LEX_OP_GREATER;

		case ST_OP_PLUS:		// +		23
			if(c == '=')
				return LEX_OP_PLUS_AS;
			if(c == '+')
				return LEX_OP_PLUS_PLUS;

			m_file.unget();
			return LEX_OP_PLUS;

		case ST_OP_MINUS:		// -
			if(c == '=')
				return LEX_OP_MINUS_AS;
			if(c == '-')
				return LEX_OP_MINUS_MINUS;

			m_file.unget();
			return LEX_OP_MINUS;

		case ST_OP_MULT:		// *
			if(c == '=')
				return LEX_OP_MULT_AS;

			m_file.unget();
			return LEX_OP_MULT;

		case ST_OP_DIV:			// /		1
			if(c == '=')
			{
				return LEX_OP_DIV_AS;
			}
			if(c == '/')
			{
				state = ST_CPP_COMMENT;
				break;
			}
			if(c == '*')
			{
				state = ST_C_COMMENT;
				break;
			}

			m_file.unget();
			return LEX_OP_DIV;

		case ST_OP_MOD:
			if(c == '=')
				return LEX_OP_MOD_AS;

			m_file.unget();
			return LEX_OP_MOD;

		case ST_OP_POINT:
			if(c == '=')
			{
				return LEX_OP_POINT_AS;
			}
			if(isdigit(c))
			{
				m_float = (c - '0') * float_dms;
				float_dms /= 10.0f;
				state = ST_FLOAT;
				break;
			}

			m_file.unget();
			return LEX_OP_POINT;


		case ST_OP_AND:
			if(c == '&')
				return LEX_OP_AND;

			m_file.unget();
			PRINT_ERROR(cerr, m_filename, m_line, string(_("Unexpected character '")) + c2s(c) + _("', this is not operator &&"));
			return LEX_ERROR;

		case ST_OP_OR:
			if(c == '|')
				return LEX_OP_OR;

			m_file.unget();
			PRINT_ERROR(cerr, m_filename, m_line, string(_("Unexpected character '")) + c2s(c) + _("', this is not operator ||"));
			return LEX_ERROR;

		default:
			DBG_THROW(runtime_error(_("Undefined state, this should never happen.")));
			break;
		}
	}
}

}// namespace
