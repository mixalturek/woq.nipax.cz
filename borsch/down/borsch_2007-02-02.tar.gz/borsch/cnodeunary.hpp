/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CNODEUNARY_HPP__
#define __CNODEUNARY_HPP__

#include "general.hpp"
#include "lextoken.hpp"
#include "cnode.hpp"
#include "cnodevalue.hpp"

namespace borsch
{

class CNode;
class CNodeValue;

class CNodeUnary : public CNode
{
public:
	CNodeUnary(CNode* next, LEXTOKEN op,
		const string& file = GENERATED, int line = 0);

	~CNodeUnary(void);

	virtual CNodeValue Execute(void);
	virtual void Dump(ostream& os, int indent = 0) const;

	LEXTOKEN GetOp(void) const { return m_op; }

private:
	CNodeUnary(void);
	CNodeUnary(const CNodeUnary& object);
	CNodeUnary& operator=(const CNodeUnary& object);

protected:
	CNode* m_next;// If NULL (return;), CNodeEmptyCommand() is generated
	LEXTOKEN m_op;
};

ostream& operator<<(ostream& os, const CNodeUnary& node);

}// namespace

#endif
