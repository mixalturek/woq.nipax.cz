/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cparser.hpp"

#include "cexception.hpp"
#include "cnodeunary.hpp"
#include "cnodebinary.hpp"
#include "cnodevariable.hpp"
#include "cnodefunccall.hpp"
#include "cnodeifelse.hpp"
#include "cnodeloop.hpp"
#include "cnodeemptycommand.hpp"
#include "cnodevalue.hpp"
#include "cnodefunction.hpp"
#include "ccontext.hpp"
#include "cnodejump.hpp"


#define	THROW_UNEXPECTED_TOKEN_EXCEPTION() \
	DBG_THROW(CUnexpectedTokenException(m_next_token, m_lexan.GetFilename(), m_lexan.GetLine()))


namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Constructor

CParser::CParser(CLexan& lexan)
	:
	m_lexan(lexan),
	m_next_token(m_lexan.Next()),
	m_global_block(m_lexan.GetFilename(), m_lexan.GetLine())
{

}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CParser::~CParser(void)
{

}


/////////////////////////////////////////////////////////////////////////////
//// Parse

bool CParser::Parse(void)
{
	try
	{
		S();
		GenerateBuildinFunctions();
		return true;
	}
	catch(CUnexpectedTokenException& ex)
	{
		cerr << ex;
		return false;
	}
	catch(CNotAssignableException& ex)
	{
		cerr << ex;
		return false;
	}
	catch(...)
	{
		PRINT_ERROR(cerr, m_lexan.GetFilename(), m_lexan.GetLine(), "Unexpected exception while parsing source file occured");
		return false;
	}

	return true;
}


/////////////////////////////////////////////////////////////////////////////
//// GenerateBuildinFunctions()

void CParser::GenerateBuildinFunctions(void)
{
	CContext& context = CContext::Instance();

	list<string>* params;

	params = new list<string>();
	params->push_back("param");
	context.AddFunction(new CNodeFunction("echo", params,
		NULL, "BUILDIN_FUNCTION", 0));

	params = new list<string>();
	params->push_back("param");
	context.AddFunction(new CNodeFunction("exit", params,
		NULL, "BUILDIN_FUNCTION", 0));

	params = new list<string>();
	params->push_back("name");
	context.AddFunction(new CNodeFunction("get_global", params,
		NULL, "BUILDIN_FUNCTION", 0));

	params = new list<string>();
	params->push_back("name");
	params->push_back("value");
	context.AddFunction(new CNodeFunction("set_global", params,
		NULL, "BUILDIN_FUNCTION", 0));
}


/////////////////////////////////////////////////////////////////////////////
//// Execute()

int CParser::Execute(void)
{
	try
	{
		m_global_block.Execute();
		return 0;
	}
	catch(CContinueException& ex)
	{
		PRINT_ERROR(cerr, ex.GetFile(), ex.GetLine(), _("Continue command outside of a loop"));
		return 1;
	}
	catch(CBreakException& ex)
	{
		PRINT_ERROR(cerr, ex.GetFile(), ex.GetLine(), _("Break command outside of a loop"));
		return 1;
	}
	catch(CReturnException& ex)
	{
		PRINT_ERROR(cerr, ex.GetFile(), ex.GetLine(), _("Return command outside of a function"));
		return 1;
	}
	catch(CExitException& ex)
	{
		switch(ex.GetValue().GetType())
		{
		case LEX_VOID:
			cout << _("Script exited with no value");
			return 1;

		case LEX_BOOL:
			cout << _("Script exited with value ");
			ex.GetValue().Dump(cout, 0);
			return ex.GetValue().GetBool();

		case LEX_INT:
			cout << _("Script exited with value ");
			ex.GetValue().Dump(cout, 0);
			return ex.GetValue().GetInt();

		case LEX_FLOAT:
			cout << _("Script exited with value ");
			ex.GetValue().Dump(cout, 0);
			return (int)ex.GetValue().GetFloat();

		case LEX_STRING:
			cout << _("Script exited with value ");
			ex.GetValue().Dump(cout, 0);
			return 0;

		default:
			assert(false);
			return 1;
		}
	}
	catch(COperatorNotAllowedException& ex)
	{
		PRINT_ERROR(cerr, ex.GetFile(), ex.GetLine(), ex.what());
		return 1;
	}
	catch(CBadFunctionCallException& ex)
	{
		PRINT_ERROR(cerr, ex.GetFile(), ex.GetLine(), ex.what());
		return 1;
	}
	catch(CVariableNotInitializedException& ex)
	{
		PRINT_ERROR(cerr, ex.GetFile(), ex.GetLine(), ex.what());
		return 1;
	}

	// Never should be called
	assert(false);
	return 0;
}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CParser::Dump(ostream& os) const
{
//	DumpIndent(os, indent);
	os << "<Script>" << endl;


	CNode::DumpIndent(os, 1);
	os << "<GlobalCommands>" << endl;

	m_global_block.Dump(os,  2);

	CNode::DumpIndent(os, 1);
	os << "</GlobalCommands>" << endl;


	CNode::DumpIndent(os, 1);
	os << "<GlobalFunctions>" << endl;

	CContext::Instance().Dump(os, 1);

	CNode::DumpIndent(os, 1);
	os << "</GlobalFunctions>" << endl;


//	DumpIndent(os, indent);
	os << "</Script>" << endl;
}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CParser& node)
{
	node.Dump(os);
	return os;
}


/////////////////////////////////////////////////////////////////////////////
////

void CParser::S(void)
{
	switch(m_next_token)
	{
	// S -> function func_name ( Params ) { Block } S
	case LEX_FUNCTION:
	{
		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_FUNC_NAME)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		string name = m_lexan.GetString();

		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_LPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		list<string>* params = Params();

		if(m_next_token != LEX_RPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_LVA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		CNode* block = Block();

		if(m_next_token != LEX_RVA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

//		m_functions.push_back(new CNodeFunction(name, params,
//			block, m_lexan.GetFilename(), m_lexan.GetLine()));
		CContext::Instance().AddFunction(new CNodeFunction(name, params,
			block, m_lexan.GetFilename(), m_lexan.GetLine()));

		S();

		return;
	}

	// S -> Cmd S
	case LEX_RETURN:
	case LEX_IF:
	case LEX_WHILE:
	case LEX_FOR:
	case LEX_BREAK:
	case LEX_CONTINUE:
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LVA:
	case LEX_LPA:
	case LEX_SEMICOLON:
	case LEX_OP_NOT:
	case LEX_OP_MINUS:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
		m_global_block.PushBackCommand(Cmd());
		S();
		return;

	case LEX_NULL:
		return;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

list<string>* CParser::Params(void)
{
	switch(m_next_token)
	{
	// Params -> epsilon
	case LEX_RPA:
		return NULL;

	// Params -> var Params_c
	case LEX_VARIABLE:
	{
		string name = m_lexan.GetString();
		m_next_token = m_lexan.Next();

		list<string>* lst = Params_c();
		if(lst == NULL)
			lst = new list<string>();

		lst->push_front(name);

		return lst;
	}

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

list<string>* CParser::Params_c(void)
{
	switch(m_next_token)
	{
	// Params_c -> epsilon
	case LEX_RPA:
		return NULL;

	// Params_c -> , var Params_c
	case LEX_OP_COMMA:
	{
		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_VARIABLE)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		string name = m_lexan.GetString();

		m_next_token = m_lexan.Next();

		list<string>* lst = Params_c();
		if(lst == NULL)
			lst = new list<string>();

		lst->push_front(name);

		return lst;
	}

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::Cmd(void)
{
	switch(m_next_token)
	{
	// Cmd -> return Ee ;
	case LEX_RETURN:
	{
		m_next_token = m_lexan.Next();

		CNode* node = new CNodeUnary(Ee(), LEX_RETURN,
			m_lexan.GetFilename(), m_lexan.GetLine());

		if(m_next_token != LEX_SEMICOLON)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();
		return node;
	}

	// Cmd -> if ( E ) Cmd Cmd_c
	case LEX_IF:
	{
		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_LPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		CNode* condition = E();

		if(m_next_token != LEX_RPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		CNode* if_section = Cmd();
		CNode* else_section = Cmd_c();

		return new CNodeIfElse(condition, if_section, else_section,
			m_lexan.GetFilename(), m_lexan.GetLine());
	}

	// Cmd -> while ( E ) Cmd
	case LEX_WHILE:
	{
		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_LPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		CNode* condition = E();

		if(m_next_token != LEX_RPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		return new CNodeLoop(NULL, condition, NULL, Cmd(),
			m_lexan.GetFilename(), m_lexan.GetLine());
	}

	// Cmd -> for ( Ee ; Ee ; Ee ) Cmd
	case LEX_FOR:
	{
		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_LPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		CNode* init = Ee();

		if(m_next_token != LEX_SEMICOLON)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		CNode* condition = Ee();

		if(m_next_token != LEX_SEMICOLON)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		CNode* inc = Ee();

		if(m_next_token != LEX_RPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		return new CNodeLoop(init, condition, inc, Cmd(),
			m_lexan.GetFilename(), m_lexan.GetLine());
	}

	// Cmd -> break ;
	case LEX_BREAK:
	{
		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_SEMICOLON)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		return new CNodeJump(LEX_BREAK,
			m_lexan.GetFilename(), m_lexan.GetLine());
	}

	// Cmd -> continue ;
	case LEX_CONTINUE:
	{
		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_SEMICOLON)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		return new CNodeJump(LEX_CONTINUE,
			m_lexan.GetFilename(), m_lexan.GetLine());
	}

	// Cmd -> E ;
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LPA:
	case LEX_OP_NOT:
	case LEX_OP_MINUS:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
	{
		CNode* node = E();

		if(m_next_token != LEX_SEMICOLON)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		return node;
	}

	// Cmd -> { Block }
	case LEX_LVA:
	{
		m_next_token = m_lexan.Next();

		CNode* node = Block();

		if(m_next_token != LEX_RVA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		return node;
	}

	// Cmd -> ;
	case LEX_SEMICOLON:
		m_next_token = m_lexan.Next();
		return new CNodeEmptyCommand(m_lexan.GetFilename(), m_lexan.GetLine());

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::Cmd_c(void)
{
	switch(m_next_token)
	{
	// Cmd_c -> else Cmd
	case LEX_ELSE:
		m_next_token = m_lexan.Next();
		return Cmd();

	// Cmd_c -> epsilon
	case LEX_FUNCTION:
	case LEX_RETURN:
	case LEX_IF:
	case LEX_WHILE:
	case LEX_FOR:
	case LEX_BREAK:
	case LEX_CONTINUE:
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LVA:
	case LEX_RVA:
	case LEX_LPA:
	case LEX_SEMICOLON:
	case LEX_OP_NOT:
	case LEX_OP_MINUS:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
	case LEX_NULL:
		return NULL;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNodeBlock* CParser::Block(void)
{
	switch(m_next_token)
	{
	// Block -> epsilon
	case LEX_RVA:
		// It will be faster run empty block sometime, than NULL tests everytime...
		return new CNodeBlock(m_lexan.GetFilename(), m_lexan.GetLine());

	// Block -> Cmd Block
	case LEX_RETURN:
	case LEX_IF:
	case LEX_WHILE:
	case LEX_FOR:
	case LEX_BREAK:
	case LEX_CONTINUE:
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LVA:
	case LEX_LPA:
	case LEX_SEMICOLON:
	case LEX_OP_NOT:
	case LEX_OP_MINUS:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
	{
		CNode* node = Cmd();
		CNodeBlock* block = Block();
		block->PushFrontCommand(node);

		return block;
	}

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::Ee(void)
{
	switch(m_next_token)
	{
	// Ee -> E
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LPA:
	case LEX_OP_NOT:
	case LEX_OP_MINUS:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
		return E();

	// E -> epsilon
	case LEX_RPA:
	case LEX_SEMICOLON:
		return NULL;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::E(void)
{
	switch(m_next_token)
	{
	// E -> A E_c
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LPA:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
		return E_c(A());

	// E -> ! A E_c
	case LEX_OP_NOT:
		return E_c(new CNodeUnary(A(), LEX_OP_NOT,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// E -> - A E_c
	case LEX_OP_MINUS:
		m_next_token = m_lexan.Next();
		return E_c(new CNodeUnary(A(), LEX_OP_MINUS,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::A(void)
{
	switch(m_next_token)
	{
	// A -> B A_c
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LPA:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
		return A_c(B());

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::B(void)
{
	switch(m_next_token)
	{
	// B -> C B_c
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LPA:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
		return B_c(C());

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::C(void)
{
	switch(m_next_token)
	{
	// C -> D C_c
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LPA:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
		return C_c(D());

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::D(void)
{
	switch(m_next_token)
	{
	// D -> F D_c
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LPA:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
		return D_c(F());

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::F(void)
{
	switch(m_next_token)
	{
	// F -> G F_c
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LPA:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
		return F_c(G());

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::G(void)
{
	switch(m_next_token)
	{
	// G -> var G_c
	case LEX_VARIABLE:
	{
		CNode* node = new CNodeVariable(m_lexan.GetString(),
			m_lexan.GetFilename(), m_lexan.GetLine());

		m_next_token = m_lexan.Next();

		return G_c(node);
	}

	// G -> func_name ( L )
	case LEX_FUNC_NAME:
	{
		string name = m_lexan.GetString();

		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_LPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		CNodeBlock* parameters = L();

		if(m_next_token != LEX_RPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		return new CNodeFuncCall(name, parameters,
			m_lexan.GetFilename(), m_lexan.GetLine());
	}

	// G -> ( E )
	case LEX_LPA:
	{
		m_next_token = m_lexan.Next();

		CNode* node = E();

		if(m_next_token != LEX_RPA)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		m_next_token = m_lexan.Next();

		return node;
	}

	// G -> bool_val
	case LEX_BOOL:
	{
		CNode* node = new CNodeValue(m_lexan.GetBool(),
			m_lexan.GetFilename(), m_lexan.GetLine());

		m_next_token = m_lexan.Next();
		return node;
	}

	// G -> int_val
	case LEX_INT:
	{
		CNode* node = new CNodeValue(m_lexan.GetInt(),
			m_lexan.GetFilename(), m_lexan.GetLine());

		m_next_token = m_lexan.Next();
		return node;
	}

	// G -> float_val
	case LEX_FLOAT:
	{
		CNode* node = new CNodeValue(m_lexan.GetFloat(),
			m_lexan.GetFilename(), m_lexan.GetLine());

		m_next_token = m_lexan.Next();
		return node;
	}

	// G -> string_val
	case LEX_STRING:
	{
		CNode* node = new CNodeValue(m_lexan.GetString(),
			m_lexan.GetFilename(), m_lexan.GetLine());

		m_next_token = m_lexan.Next();
		return node;
	}

	// G -> ++ var
	case LEX_OP_PLUS_PLUS:
	{
		m_next_token = m_lexan.Next();

		if(m_next_token != LEX_VARIABLE)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		CNode* ret = new CNodeUnary(new CNodeVariable(
			m_lexan.GetString(),
			m_lexan.GetFilename(), m_lexan.GetLine()),
			LEX_OP_PLUS_PLUS,
			m_lexan.GetFilename(), m_lexan.GetLine());

		m_next_token = m_lexan.Next();
		return ret;
	}

	// G -> -- var
	case LEX_OP_MINUS_MINUS:
	{
		m_next_token = m_lexan.Next();
		if(m_next_token != LEX_VARIABLE)
			THROW_UNEXPECTED_TOKEN_EXCEPTION();

		CNode* ret = new CNodeUnary(new CNodeVariable(
			m_lexan.GetString(),
			m_lexan.GetFilename(), m_lexan.GetLine()),
			LEX_OP_PLUS_PLUS,
			m_lexan.GetFilename(), m_lexan.GetLine());

		m_next_token = m_lexan.Next();
		return ret;
	}

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNodeBlock* CParser::L(void)
{
	switch(m_next_token)
	{
	// L -> E L_c
	case LEX_VARIABLE:
	case LEX_FUNC_NAME:
	case LEX_LPA:
	case LEX_OP_NOT:
	case LEX_OP_MINUS:
	case LEX_BOOL:
	case LEX_INT:
	case LEX_FLOAT:
	case LEX_STRING:
	case LEX_OP_PLUS_PLUS:
	case LEX_OP_MINUS_MINUS:
	{
		CNode* node = E();
		CNodeBlock* block = L_c();

		if(block == NULL)
			block = new CNodeBlock(m_lexan.GetFilename(), m_lexan.GetLine());

		block->PushFrontCommand(node);

		return block;
	}

	// L -> epsilon
	case LEX_RPA:
		return NULL;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::E_c(CNode* node)
{
	switch(m_next_token)
	{
	// E_c -> = A E_c
	case LEX_OP_ASSIGN:
		if(typeid(*node) != typeid(CNodeVariable))
			DBG_THROW(CNotAssignableException(m_lexan.GetFilename(), m_lexan.GetLine()));

		m_next_token = m_lexan.Next();

		return new CNodeBinary(node, E_c(A()), LEX_OP_ASSIGN,
			m_lexan.GetFilename(), m_lexan.GetLine());

	// E_c -> += A E_c
	case LEX_OP_PLUS_AS:
		if(typeid(*node) != typeid(CNodeVariable))
			DBG_THROW(CNotAssignableException(m_lexan.GetFilename(), m_lexan.GetLine()));

		m_next_token = m_lexan.Next();

		return new CNodeBinary(node, E_c(A()), LEX_OP_PLUS_AS,
			m_lexan.GetFilename(), m_lexan.GetLine());

	// E_c -> -= A E_c
	case LEX_OP_MINUS_AS:
		if(typeid(*node) != typeid(CNodeVariable))
			DBG_THROW(CNotAssignableException(m_lexan.GetFilename(), m_lexan.GetLine()));

		m_next_token = m_lexan.Next();

		return new CNodeBinary(node, E_c(A()), LEX_OP_MINUS_AS,
			m_lexan.GetFilename(), m_lexan.GetLine());

	// E_c -> *= A E_c
	case LEX_OP_MULT_AS:
		if(typeid(*node) != typeid(CNodeVariable))
			DBG_THROW(CNotAssignableException(m_lexan.GetFilename(), m_lexan.GetLine()));

		m_next_token = m_lexan.Next();

		return new CNodeBinary(node, E_c(A()), LEX_OP_MULT_AS,
			m_lexan.GetFilename(), m_lexan.GetLine());

	// E_c -> /= A E_c
	case LEX_OP_DIV_AS:
		if(typeid(*node) != typeid(CNodeVariable))
			DBG_THROW(CNotAssignableException(m_lexan.GetFilename(), m_lexan.GetLine()));

		m_next_token = m_lexan.Next();

		return new CNodeBinary(node, E_c(A()), LEX_OP_DIV_AS,
			m_lexan.GetFilename(), m_lexan.GetLine());

	// E_c -> %= A E_c
	case LEX_OP_MOD_AS:
		if(typeid(*node) != typeid(CNodeVariable))
			DBG_THROW(CNotAssignableException(m_lexan.GetFilename(), m_lexan.GetLine()));

		m_next_token = m_lexan.Next();

		return new CNodeBinary(node, E_c(A()), LEX_OP_MOD_AS,
			m_lexan.GetFilename(), m_lexan.GetLine());

	// E_c -> epsilon
	case LEX_RPA:
	case LEX_OP_COMMA:
	case LEX_SEMICOLON:
		return node;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::A_c(CNode* node)
{
	switch(m_next_token)
	{
	// A_c -> || B A_c
	case LEX_OP_OR:
		m_next_token = m_lexan.Next();
		return A_c(new CNodeBinary(node, B(), LEX_OP_OR,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// A_c -> epsilon
	case LEX_RPA:
	case LEX_OP_COMMA:
	case LEX_SEMICOLON:
	case LEX_OP_ASSIGN:
	case LEX_OP_PLUS_AS:
	case LEX_OP_MINUS_AS:
	case LEX_OP_MULT_AS:
	case LEX_OP_DIV_AS:
	case LEX_OP_MOD_AS:
		return node;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::B_c(CNode* node)
{
	switch(m_next_token)
	{
	// B_c -> && C B_c
	case LEX_OP_AND:
		m_next_token = m_lexan.Next();
		return B_c(new CNodeBinary(node, C(), LEX_OP_AND,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// B_c -> epsilon
	case LEX_RPA:
	case LEX_OP_COMMA:
	case LEX_SEMICOLON:
	case LEX_OP_ASSIGN:
	case LEX_OP_PLUS_AS:
	case LEX_OP_MINUS_AS:
	case LEX_OP_MULT_AS:
	case LEX_OP_DIV_AS:
	case LEX_OP_MOD_AS:
	case LEX_OP_OR:
		return node;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::C_c(CNode* node)
{
	switch(m_next_token)
	{
	// C_c -> < D C_c
	case LEX_OP_LESS:
		m_next_token = m_lexan.Next();
		return C_c(new CNodeBinary(node, D(), LEX_OP_LESS,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// C_c -> > D C_c
	case LEX_OP_GREATER:
		m_next_token = m_lexan.Next();
		return C_c(new CNodeBinary(node, D(), LEX_OP_GREATER,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// C_c -> <= D C_c
	case LEX_OP_LESS_EQ:
		m_next_token = m_lexan.Next();
		return C_c(new CNodeBinary(node, D(), LEX_OP_LESS_EQ,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// C_c -> >= D C_c
	case LEX_OP_GREATER_EQ:
		m_next_token = m_lexan.Next();
		return C_c(new CNodeBinary(node, D(), LEX_OP_GREATER_EQ,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// C_c -> == D C_c
	case LEX_OP_EQUAL:
		m_next_token = m_lexan.Next();
		return C_c(new CNodeBinary(node, D(), LEX_OP_EQUAL,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// C_c -> != D C_c
	case LEX_OP_NOT_EQ:
		m_next_token = m_lexan.Next();
		return C_c(new CNodeBinary(node, D(), LEX_OP_NOT_EQ,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// B_c -> epsilon
	case LEX_RPA:
	case LEX_OP_COMMA:
	case LEX_SEMICOLON:
	case LEX_OP_ASSIGN:
	case LEX_OP_PLUS_AS:
	case LEX_OP_MINUS_AS:
	case LEX_OP_MULT_AS:
	case LEX_OP_DIV_AS:
	case LEX_OP_MOD_AS:
	case LEX_OP_OR:
	case LEX_OP_AND:
		return node;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::D_c(CNode* node)
{
	switch(m_next_token)
	{
	// D_c -> + F D_c
	case LEX_OP_PLUS:
		m_next_token = m_lexan.Next();
		return D_c(new CNodeBinary(node, F(), LEX_OP_PLUS,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// D_c -> - F D_c
	case LEX_OP_MINUS:
		m_next_token = m_lexan.Next();
		return D_c(new CNodeBinary(node, F(), LEX_OP_MINUS,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// D_c -> epsilon
	case LEX_RPA:
	case LEX_OP_COMMA:
	case LEX_SEMICOLON:
	case LEX_OP_ASSIGN:
	case LEX_OP_PLUS_AS:
	case LEX_OP_MINUS_AS:
	case LEX_OP_MULT_AS:
	case LEX_OP_DIV_AS:
	case LEX_OP_MOD_AS:
	case LEX_OP_OR:
	case LEX_OP_AND:
	case LEX_OP_LESS:
	case LEX_OP_GREATER:
	case LEX_OP_LESS_EQ:
	case LEX_OP_GREATER_EQ:
	case LEX_OP_EQUAL:
	case LEX_OP_NOT_EQ:
		return node;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::F_c(CNode* node)
{
	switch(m_next_token)
	{
	// f_c -> * G F_c
	case LEX_OP_MULT:
		m_next_token = m_lexan.Next();
		return F_c(new CNodeBinary(node, G(), LEX_OP_MULT,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// D_c -> - F D_c
	case LEX_OP_DIV:
		m_next_token = m_lexan.Next();
		return F_c(new CNodeBinary(node, G(), LEX_OP_DIV,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// D_c -> % F D_c
	case LEX_OP_MOD:
		m_next_token = m_lexan.Next();
		return F_c(new CNodeBinary(node, G(), LEX_OP_MOD,
			m_lexan.GetFilename(), m_lexan.GetLine()));

	// D_c -> epsilon
	case LEX_RPA:
	case LEX_OP_COMMA:
	case LEX_SEMICOLON:
	case LEX_OP_ASSIGN:
	case LEX_OP_PLUS_AS:
	case LEX_OP_MINUS_AS:
	case LEX_OP_MULT_AS:
	case LEX_OP_DIV_AS:
	case LEX_OP_MOD_AS:
	case LEX_OP_OR:
	case LEX_OP_AND:
	case LEX_OP_LESS:
	case LEX_OP_GREATER:
	case LEX_OP_LESS_EQ:
	case LEX_OP_GREATER_EQ:
	case LEX_OP_EQUAL:
	case LEX_OP_NOT_EQ:
	case LEX_OP_PLUS:
	case LEX_OP_MINUS:
		return node;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNode* CParser::G_c(CNode* node)
{
	switch(m_next_token)
	{
	// G_c -> ++
	case LEX_OP_PLUS_PLUS:
		m_next_token = m_lexan.Next();
		return new CNodeUnary(node, LEX_OP_PLUS_PLUS_POST,
			m_lexan.GetFilename(), m_lexan.GetLine());

	// G_c -> --
	case LEX_OP_MINUS_MINUS:
		m_next_token = m_lexan.Next();
		return new CNodeUnary(node, LEX_OP_MINUS_MINUS_POST,
			m_lexan.GetFilename(), m_lexan.GetLine());

	// G_c -> epsilon
	case LEX_RPA:
	case LEX_OP_COMMA:
	case LEX_SEMICOLON:
	case LEX_OP_ASSIGN:
	case LEX_OP_PLUS_AS:
	case LEX_OP_MINUS_AS:
	case LEX_OP_MULT_AS:
	case LEX_OP_DIV_AS:
	case LEX_OP_MOD_AS:
	case LEX_OP_OR:
	case LEX_OP_AND:
	case LEX_OP_LESS:
	case LEX_OP_GREATER:
	case LEX_OP_LESS_EQ:
	case LEX_OP_GREATER_EQ:
	case LEX_OP_EQUAL:
	case LEX_OP_NOT_EQ:
	case LEX_OP_PLUS:
	case LEX_OP_MINUS:
	case LEX_OP_MULT:
	case LEX_OP_DIV:
	case LEX_OP_MOD:
		return node;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

CNodeBlock* CParser::L_c(void)
{
	switch(m_next_token)
	{
	// L_c -> , E L_c
	case LEX_OP_COMMA:
	{
		m_next_token = m_lexan.Next();

		CNode* node = E();
		CNodeBlock* block = L_c();

		if(block == NULL)
			block = new CNodeBlock(m_lexan.GetFilename(), m_lexan.GetLine());

		block->PushFrontCommand(node);

		return block;
	}

	// L -> epsilon
	case LEX_RPA:
		return NULL;

	default:
		THROW_UNEXPECTED_TOKEN_EXCEPTION();
	}
}

}// namespace
