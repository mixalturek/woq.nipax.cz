/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <iostream>
//#include <fstream>
#include "general.hpp"
#include "clexan.hpp"
#include "cparser.hpp"

using namespace std;
using namespace borsch;


void my_terminate();
void my_unexpected();

void (*old_terminate)() = set_terminate(my_terminate);
void (*old_unexpected)() = set_unexpected(my_unexpected);


/////////////////////////////////////////////////////////////////////////////
//// my_terminate()

void my_terminate()
{
	cerr << _("Uncatched exception or throwing exception in destructor!")
		<< endl;
	old_terminate();
}


/////////////////////////////////////////////////////////////////////////////
//// my_unexpected()

void my_unexpected()
{
	cerr << _("Unexpected exception was thrown!") << endl;
	old_unexpected();
}


/////////////////////////////////////////////////////////////////////////////
//// main()

int main(int argc, char *argv[])
{
	if(argc < 2)
	{
		cerr << _("Usage: ") << argv[0] << " [--lex-dump] [--call-tree-dump] " << _("<filename>") << endl;
		return 1;
	}

	try
	{
		bool lex_dump = false;
		bool call_tree_dump = false;

		for(int i = 1; i < argc; i++)
		{
			if(!lex_dump)
				if(string(argv[i]) == string("--lex-dump"))
					lex_dump = true;

			if(!call_tree_dump)
				if(string(argv[i]) == string("--call-tree-dump"))
					call_tree_dump = true;
		}

		CLexan lexan(argv[argc-1]);
		CParser parser(lexan);

		if(lex_dump)
		{
			LEXTOKEN token;

			cout << "<?xml version='1.0' encoding='utf-8' standalone='yes'?>" << endl;
			cout << "<tokens>" << endl;

			while(true)
			{
				token = lexan.Next();

				switch(token)
				{
				case LEX_FUNC_NAME:
				case LEX_VARIABLE:
				case LEX_STRING:
					cout << "    <"
						<< GetTokenName(token)
						<< " string=\""
						<< lexan.GetString()
						<< "\"/>" << endl;
					break;

				case LEX_BOOL:
					cout << "    <"
						<< GetTokenName(token)
						<< " bool=\""
						<< ((lexan.GetBool()) ? "true" : "false")
						<< "\"/>" << endl;
					break;

				case LEX_INT:
					cout
						<< "    <"
						<< GetTokenName(token)
						<< " int=\""
						<< lexan.GetInt()
						<< "\"/>" << endl;
					break;

				case LEX_FLOAT:
					cout << "    <"
						<< GetTokenName(token)
						<< " float=\""
						<< lexan.GetFloat()
						<< "\"/>" << endl;
					break;

				default:
					cout << "    <"
						<< GetTokenName(token)
						<< "/>" << endl;
					break;
				}

				if(token == LEX_NULL)
					break;
			}

			cout << "</tokens>" << endl;

			return 0;
		}

		if(!parser.Parse())
		{
			PRINT_ERROR(cerr, lexan.GetFilename(), lexan.GetLine(), "Error while parsing source file");
			return 1;
		}

		if(call_tree_dump)
		{
			cout << "<?xml version='1.0' encoding='utf-8' standalone='yes'?>" << endl;

			parser.Dump(cout);
			return 0;
		}

		return parser.Execute();
	}
	catch(std::bad_alloc& ex)
	{
		cerr << _("Unable to allocate memory: ") << ex.what() << endl;
		return 2;
	}
	catch(std::runtime_error& ex)
	{
		cerr << ex.what() << endl;
		return 2;
	}
	catch(...)
	{
		cerr << _("Unhandled exception occurs!") << endl;
		return 2;
	}

	return 0;
}
