/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "ccontext.hpp"

namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
//// Default constructor

CContext::CContext(void)
	:
	m_functions(),
	m_global_variables(),
	m_local_variables()
{
	PushLocal();
}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CContext::~CContext(void)
{
	list<CNodeFunction*>::iterator it;

	for(it = m_functions.begin(); it != m_functions.end(); it++)
	{
		delete (*it);
		*it = NULL;
	}

	m_functions.clear();
}


/////////////////////////////////////////////////////////////////////////////
//// GetFunction()

CNodeFunction* CContext::GetFunction(const string& name)
{
	list<CNodeFunction*>::iterator it;

	for(it = m_functions.begin(); it != m_functions.end(); it++)
	{
		if((*it)->GetName() == name)
			return *it;
	}

	return NULL;
}


/////////////////////////////////////////////////////////////////////////////
//// GetLocalVariable()

CNodeValue& CContext::GetLocalVariable(const string& name, bool create)
{
	// In global context, not in function
	if(m_local_variables.size() == 1)
		return GetGlobalVariable(name, create);

	assert(!m_local_variables.empty());

	map<string, CNodeValue>::iterator it = m_local_variables.top().find(name);

	if(it != m_local_variables.top().end())
	{
		return (*it).second;
	}
	else
	{
		if(create)
			return m_local_variables.top()[name];
		else
			DBG_THROW(CVariableNotInitializedException(
				_("Local variable \"") + name
				+ _("\" has not been initialized yet"),
				"UNKNOWNFILE", 0));
	}
}


/////////////////////////////////////////////////////////////////////////////
//// GetGlobalVariable()

CNodeValue& CContext::GetGlobalVariable(const string& name, bool create)
{
	map<string, CNodeValue>::iterator it = m_global_variables.find(name);

	if(it != m_global_variables.end())
	{
		return (*it).second;
	}
	else
	{
		if(create)
			return m_global_variables[name];
		else
			DBG_THROW(CVariableNotInitializedException(
				_("Global variable \"") + name
				+ _("\" has not been initialized yet"),
				"UNKNOWNFILE", 0));
	}
}


/////////////////////////////////////////////////////////////////////////////
//// Dump()

void CContext::Dump(ostream& os, int indent) const
{
	list<CNodeFunction*>::const_iterator it;
	for(it = m_functions.begin(); it != m_functions.end(); it++)
		(*it)->Dump(os, indent+1);

}


/////////////////////////////////////////////////////////////////////////////
//// operator<<

ostream& operator<<(ostream& os, const CContext& node)
{
	node.Dump(os, 0);
	return os;
}

}// namespace
