/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CNODE_HPP__
#define __CNODE_HPP__

#include "general.hpp"

namespace borsch
{

class CNodeValue;

class CNode
{
public:
	CNode(const string& file = GENERATED, int line = 0);
	virtual ~CNode(void);

	virtual CNodeValue Execute(void) = 0;
	virtual void Dump(ostream& os, int indent = 0) const;

	static void DumpIndent(ostream& os, int indent);

	const string& GetFile(void) const { return m_file; }
	int GetLine(void) const { return m_line; }

private:
	CNode(const CNode& object);
	CNode& operator=(const CNode& object);

protected:
	string m_file;
	int m_line;
};

ostream& operator<<(ostream& os, const CNode& node);

}// namespace

#endif
