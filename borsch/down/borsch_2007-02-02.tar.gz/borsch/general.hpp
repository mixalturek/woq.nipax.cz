/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __GENERAL_HPP__
#define __GENERAL_HPP__


/////////////////////////////////////////////////////////////////////////////
//// Defines

// Debug/release
#define DEBUG

// Use colored output (terminal must support this)
#define COLOR_OUTPUT

// Default CNode* filename
#define GENERATED "GENERATED"


/////////////////////////////////////////////////////////////////////////////
//// Includes

//#ifdef HAVE_CONFIG_H
//#include <config.h>
//#endif

#include <cassert>
#include <iostream>
#include <stdexcept>

using namespace std;


/////////////////////////////////////////////////////////////////////////////
//// Macros

// gettext
#define _(string) (string)

// debug
#ifdef DEBUG
#define DBG(obj) {cout << (char)0x1B << "[" << 0 << ";" << 32 << ";" << 40 << "m"; \
		 cout << "[debug " << __FILE__ << ":" << __LINE__ << "] " << (obj) << endl; \
		 cout << (char)0x1B << "[" << 0 << ";" << 37 << ";" << 40 << "m";}
#else
#define DBG(obj)
#endif


/////////////////////////////////////////////////////////////////////////////
//// Errors, warnings

#ifdef COLOR_OUTPUT

// Error - right, fg red, bg transparent
#define PRINT_ERROR(stream, file, line, str) \
	stream << (char)0x1B << "[" << 1 << ";" << 31 << ";" << 40 << "m"; \
	stream << _("[ERROR ") << (file) << ":" << (line) << "] " << (str) << endl; \
	stream << (char)0x1B << "[" << 0 << ";" << 37 << ";" << 40 << "m";

// Warning - right, fg yellow, bg transparent
#define PRINT_WARNING(stream, file, line, str) \
	stream << (char)0x1B << "[" << 1 << ";" << 33 << ";" << 40 << "m"; \
	stream << _("[WARNING ") << (file) << ":" << (line) << "] " << (str) << endl; \
	stream << (char)0x1B << "[" << 0 << ";" << 37 << ";" << 40 << "m";
#else

// Error
#define PRINT_ERROR(stream, file, line, str) \
	stream << _("[ERROR ") << (file) << ":" << (line) << "] " << (str) << endl;

// Warning
#define PRINT_WARNING(stream, file, line, str) \
	stream << _("[WARNING ") << (file) << ":" << (line) << "] " << (str) << endl;

#endif // #ifdef COLOR_OUTPUT


#ifdef DEBUG
#define DBG_THROW(obj) { cout << "[THROWING EXCEPTION] " << __FILE__ << ":" << __LINE__ << " function " << __FUNCTION__ << "()" << endl; throw (obj); }
#endif

#endif // #ifndef __GENERAL_HPP__
