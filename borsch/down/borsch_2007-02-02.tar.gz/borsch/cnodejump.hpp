/***************************************************************************
 *   Borsch interpreter                                                    *
 *   Copyright (C) 2006 Michal Turek                                       *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; version 2 of the License   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CNODEJUMP_HPP__
#define __CNODEJUMP_HPP__

#include <exception>
#include "general.hpp"
#include "lextoken.hpp"
#include "cnodevalue.hpp"

namespace borsch
{

/////////////////////////////////////////////////////////////////////////////
////

class CBreakException : public exception
{
public:
	CBreakException(const string& file = GENERATED, int line = 0)
		:
		m_file(file),
		m_line(line)
	{

	}

	virtual ~CBreakException() throw() { }

	const string& GetFile(void) const { return m_file; }
	int GetLine(void) const { return m_line; }

private:
	string m_file;
	int m_line;
};


/////////////////////////////////////////////////////////////////////////////
////

class CContinueException : public exception
{
public:
	CContinueException(const string& file = GENERATED, int line = 0)
		:
		m_file(file),
		m_line(line)
	{

	}

	virtual ~CContinueException() throw() { }

	const string& GetFile(void) const { return m_file; }
	int GetLine(void) const { return m_line; }

private:
	string m_file;
	int m_line;
};


/////////////////////////////////////////////////////////////////////////////
////

class CReturnException : public exception
{
public:
	CReturnException(CNodeValue value, const string& file = GENERATED, int line = 0)
		:
		m_value(value),
		m_file(file),
		m_line(line)
	{

	}

	virtual ~CReturnException() throw() { }

	const CNodeValue& GetValue(void) const { return m_value; }
	const string& GetFile(void) const { return m_file; }
	int GetLine(void) const { return m_line; }

private:
	CNodeValue m_value;
	string m_file;
	int m_line;
};


/////////////////////////////////////////////////////////////////////////////
////

class CExitException : public exception
{
public:
	CExitException(CNodeValue value, const string& file = GENERATED, int line = 0)
		:
		m_value(value),
		m_file(file),
		m_line(line)
	{

	}

	virtual ~CExitException() throw() { }

	const CNodeValue& GetValue(void) const { return m_value; }
	const string& GetFile(void) const { return m_file; }
	int GetLine(void) const { return m_line; }

private:
	CNodeValue m_value;
	string m_file;
	int m_line;
};


/////////////////////////////////////////////////////////////////////////////
////

// Break, continue only, return is CNodeUnary
class CNodeJump : public CNode
{
public:
	CNodeJump(LEXTOKEN type, const string& file = GENERATED, int line = 0);
	virtual ~CNodeJump(void);

	virtual CNodeValue Execute(void);
	virtual void Dump(ostream& os, int indent = 0) const;

private:
	CNodeJump(const CNodeJump& object);
	CNodeJump& operator=(const CNodeJump& object);

private:
	LEXTOKEN m_type;
};

ostream& operator<<(ostream& os, const CNodeJump& node);

}// namespace

#endif
