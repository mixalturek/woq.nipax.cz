function phpads_deliverActiveX(content)
{
        content = content.replace(/<scr'\+''\+'ipt/i,"<script");        
        content = content.replace(/<\/scr'\+''\+'ipt/i,"</script");     
        document.write(content);        
}
