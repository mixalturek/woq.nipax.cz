function enquiry_statechanged(xmlhttp, id)
{
if (xmlhttp.readyState == 4) {
if (!xmlhttp.responseText) {
document.getElementById('vote-' + id).innerHTML = 'Neulo�eno.';
} else {
var answers = xmlhttp.responseXML.getElementsByTagName('answer');
for (var i=0; i < answers.length; i++) {
document.getElementById('enquiry-percent-' + answers[i].getAttribute('id') + '-' + id).innerHTML = answers[i].firstChild.data;
document.getElementById('enquiry-bar-' + answers[i].getAttribute('id') + '-' + id).width = answers[i].getAttribute('width');
}
document.getElementById('answered-' + id).innerHTML = xmlhttp.responseXML.getElementsByTagName('answered')[0].firstChild.data;
document.getElementById('vote-' + id).innerHTML = 'Hlasov�n� ulo�eno.';
}
}
}
function enquiry_vote(url, f, id)
{
var xmlhttp = (window.XMLHttpRequest ? new XMLHttpRequest : (window.ActiveXObject ? new ActiveXObject("Microsoft.XMLHTTP") : false));
if (!xmlhttp) {
return false;
}
document.getElementById('vote-' + id).innerHTML = 'Ukl�d� se.';
var content = '';
for (var i = 0; i < f.elements.length; i++) {
if (f.elements[i].type == 'hidden' || (f.elements[i].type == 'radio' && f.elements[i].checked)) {
content += (content ? '&' : '') + encodeURIComponent(f.elements[i].name) + '=' + encodeURIComponent(f.elements[i].value);
}
}
xmlhttp.open(f.method, url);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
xmlhttp.onreadystatechange = function() {
enquiry_statechanged(xmlhttp, id);
};
xmlhttp.send(content);
return true;
}
