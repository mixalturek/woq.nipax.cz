function addSidebar(name, url, config_url){
if(config_url == null) config_url = "";
if((typeof window.sidebar == "object") && (typeof window.sidebar.addPanel == "function")){
window.sidebar.addPanel(name, url, config_url);
}else{
window.alert("V� prohl��e� nepodporuje tuto funkci. Zkuste Mozillu.");
}
}
var o = 0;
var id = 0;
var pause = 5000;
function jobsStart() {
id = window.setTimeout("jobsScroll()", pause);
document.getElementById("jobs-in").style.height = Math.ceil(document.getElementById("jobs-lst").offsetHeight / 2) + 8 + "px";
}
function jobsScroll() {
if (o == 0) {
o = -1 * Math.ceil(document.getElementById("jobs-lst").offsetHeight - document.getElementById("jobs-in").offsetHeight);
} else if (o < 0) {
o = 0;
}
document.getElementById("jobs-lst").style.top = o+"px";
id = window.setTimeout("jobsScroll()", pause);
}
function jobsSleep(a) {
if (a) {
window.clearTimeout(id);
} else {
id = window.setTimeout("jobsScroll()", pause);
}
}
function rebuild_ie_flash() {
var pg_objects = document.getElementsByTagName("object");
for (var i=0; i<pg_objects.length; i++) {
pg_objects[i].outerHTML = pg_objects[i].outerHTML;
}
return true
}