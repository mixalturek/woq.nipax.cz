function mail_replace()
{
	var name, server, i;
	for (i = 0; i < document.links.length; i++) {
		if (document.links[i].protocol == 'mailto:' && document.links[i].href.indexOf('@') < 0 && document.links[i].href.indexOf(' ') > 0) {
			name = document.links[i].href.substring(7, document.links[i].href.indexOf(' '));
			server = document.links[i].href.substring(document.links[i].href.lastIndexOf(' ') + 1, document.links[i].href.length);
			document.links[i].href = 'mailto:' + name + '@' + server;
			if (document.links[i].innerHTML.substring(0, document.links[i].innerHTML.indexOf(' ')) == name
			    && document.links[i].innerHTML.substring(document.links[i].innerHTML.lastIndexOf(' ') + 1, document.links[i].innerHTML.length) == server) {
				document.links[i].innerHTML = name + '@' + server;
			}
		}
	}
    
    var x = document.getElementById('commentSubmit');
    if (x) {
        x.parentNode.removeChild(x);
    }
    
}

/**
 * zavadejici nazev z historickych duvodu
 */
function modDate() {
    var node = document.getElementById('articleDate').firstChild;
    node.nodeValue = modDatetimeString(node.nodeValue);
    modCommentDates();
}

function modDatetimeString(datetimeString) {
    var td = new Date();
    var tsd = (td.getDate() + '.' + (td.getMonth() + 1) + '.' + td.getFullYear());
    var yd = new Date();
    yd.setTime(yd.getTime()  - 24 * 60 * 60 * 1000);
    var ysd = (yd.getDate() + '.' + (yd.getMonth() + 1) + '.' + yd.getFullYear());
    var dbDate = datetimeString.match(/^[0-9]+\.[0-9]+\.[0-9]+/);
    if (dbDate[0] == ysd) {
        return datetimeString.replace(/^[0-9]+\.[0-9]+\.[0-9]+\s+([0-9]+:[0-9]+)$/, 'včera $1');
    }
    else if (dbDate[0] == tsd) {
        return datetimeString.replace(/^[0-9]+\.[0-9]+\.[0-9]+\s+([0-9]+:[0-9]+)$/, 'dnes $1');
    }
    return datetimeString;
}

function modCommentDates() {
    if (!document.getElementsByTagName) return false;
    var dates = document.getElementsByTagName("div");
    for (var i=0; i < dates.length; i++) {
        if (dates[i].className.match("discuss")) {
            node = dates[i].firstChild;
            if (node.childNodes[node.childNodes.length - 1].nodeValue.match(/[0-9]{1,2}\.\s*[0-9]{1,2}\.\s*[0-9]{4}/)) {
                node.childNodes[node.childNodes.length - 1].nodeValue = ', ' + modDatetimeString(node.childNodes[node.childNodes.length - 1].nodeValue.slice(2));
            }
        }
    }
}

function modBlogHomepageDates() {
    if (!document.getElementsByTagName) return false;
    var dates = document.getElementsByTagName("div");
    for (var i=0; i < dates.length; i++) {
        if (dates[i].className.match("top")) {
            node = dates[i].childNodes[0];
            var rMatch = node.nodeValue.match(/^[0-9]{1,2}\.\s*[0-9]{1,2}\.\s*[0-9]{4}\s+[0-9]+:[0-9]+/);
            if (rMatch) {
                node.nodeValue = modDatetimeString(rMatch[0]);
            }
        }
    }
}

function ajaxInstance()
{
	var ajax = false;
	/*@cc_on @*/
	/*@if (@_jscript_version >= 5)
		try {
			ajax = new ActiveXObject('Msxml2.XMLHTTP');
		} catch (e) {
			try {
				ajax = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (E) {
				ajax = false;
			}
		}
	@end @*/
	if (!ajax && typeof XMLHttpRequest != 'undefined') {
		ajax = new XMLHttpRequest();
	}
	return ajax;
}



function ajaxReplace(id, url)
{
	var ajax = ajaxInstance();
	if (!ajax) {
		return false;
	}
	ajax.open('GET', url, true);
	ajax.onreadystatechange = function() {
		if (ajax.readyState == 4) {
			document.getElementById(id).innerHTML = ajax.responseText;
		}
	}
	ajax.send(null);
	return true;
}


function getCookie(cookieName) {
    var results = document.cookie.match(cookieName + '=(.*?)(;|$)');
    if (results) {
        return (decodeURIComponent(results[1]).replace(/\+/g, ' '));
    }
    else {
        return null;
    }
}


function deleteCookie(cookieName) {
    var cookieDate = new Date();
    cookieDate.setTime(cookieDate.getTime() - 1);
    document.cookie = cookieName += "=; expires=" + cookieDate.toGMTString();
}

function deleteDiscussCookies() {
    deleteCookie('discuss_name');
    deleteCookie('discuss_web');
    deleteCookie('discuss_email');
    document.getElementById('discuss_name').value = '';
    document.getElementById('discuss_email').value = '';
    document.getElementById('discuss_web').value = '';
}
