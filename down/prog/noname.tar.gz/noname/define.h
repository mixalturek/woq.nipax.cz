// pro p�epo��t�v�n� stup�� na radi�ny sin(), cos()
#ifndef PI180
	#define PI180 0.0174532925199432957692369076848861
#endif

#ifndef POCET_NEPRATEL
	#define POCET_NEPRATEL 1
#endif

/*
 *	NASTAVEN� OBRAZOVKY
 */

// hloubka v obrazovce
#ifndef HLOUBKA_SC
	#define HLOUBKA_SC -50.0
#endif

// polovina ���ky viditeln� sc�ny (nula ve st�edu)
#ifndef SIRKA_SC
	#define SIRKA_SC 28.0
#endif

// polovina v��ky viditeln� sc�ny (nula ve st�edu)
#ifndef VYSKA_SC
	#define VYSKA_SC 21.0
#endif

/*
 *	NASTAVEN� LOD� (HR��)
 */

// zrychlen� lod�
#ifndef ZRYCHLENI
	#define ZRYCHLENI 0.0005
#endif

#ifndef DELKA_LODI
	#define DELKA_LODI 2.5f
#endif

#ifndef POLOMER_LODI
	#define POLOMER_LODI 0.8f
#endif

/*
 *	TEXTURY
 */

#ifndef POCET_TEXTUR
	#define POCET_TEXTUR 4
#endif

#ifndef TEXTURA_HRAC
	#define TEXTURA_HRAC 0
#endif

#ifndef TEXTURA_FONT
	#define TEXTURA_FONT 1
#endif

#ifndef TEXTURA_PARTICLE
	#define TEXTURA_PARTICLE 2
#endif

#ifndef TEXTURA_NEPR_NEPOHYB
	#define TEXTURA_NEPR_NEPOHYB 3
#endif