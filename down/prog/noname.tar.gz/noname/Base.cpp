// Base.cpp: implementation of the CBase class.
//
//////////////////////////////////////////////////////////////////////

#include "Base.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBaseMove::CBaseMove()
{

}

CBaseMove::~CBaseMove()
{

}

void CBaseMove::Init(double nx, double ny, double nvx, double nvy, double u_natoceni, double u_pohybu)
{
	CBaseStatic::Init(nx, ny);

	rychlost_x = nvx;
	rychlost_y = nvy;

	uhel_natoceni = u_natoceni;
	uhel_pohybu = u_pohybu;
}
