// EnemyStatic.cpp: implementation of the CEnemyStatic class.
//
//////////////////////////////////////////////////////////////////////

#include "EnemyStatic.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#include <math.h>

#include "hrac.h"
extern CHrac hrac;

CEnemyStatic::CEnemyStatic()
{
	life = 10;
	counter_draw = 0;

	for(int i=0; i<POCET_STREL; i++)
	{
		strela[i].active = false;
	}
}

CEnemyStatic::~CEnemyStatic()
{

}

void CEnemyStatic::Draw()
{
	counter_draw++;

	glLoadIdentity();
	glTranslated(x, y, HLOUBKA_SC);// pozice

	glBindTexture(GL_TEXTURE_2D, texture[TEXTURA_NEPR_NEPOHYB]);

	glColor3ub(255, 0, 0);
	glBegin(GL_TRIANGLE_STRIP);
		glTexCoord2d(1,1); glVertex3d( 1.0, 1.0, 0.0);// Horn� prav�
		glTexCoord2d(0,1); glVertex3d(-1.0, 1.0, 0.0);// Horn� lev�
		glTexCoord2d(1,0); glVertex3d( 1.0,-1.0, 0.0);// Doln� prav�
		glTexCoord2d(0,0); glVertex3d(-1.0,-1.0, 0.0);// Doln� lev�
	glEnd();

	for(int i=0; i<POCET_STREL; i++)
	{
		strela[i].Draw();
	}

	Vystrel();
}

void CEnemyStatic::Vystrel()
{
	if(counter_draw%15 == 0)//v�st�el ka�d� 15. p�ekreslen� sc�ny
	{
		for(int i=0; i<POCET_STREL; i++)//hled� neaktivn� st�elu
		{
			if(!strela[i].active)
			{

				strela[i].active = true;
				strela[i].zasah = false;
				
				strela[i].SetColor(255,0,0);

				double delka;
				delka = sqrt((x - hrac.x)*(x - hrac.x) + (y - hrac.y)*(y - hrac.y));//vzdalenost mezi nimi
				delka *= 10;// zpomalen�
			
				if(delka!=0)
					strela[i].Init(x, y, -(x - hrac.x)/delka, -(y - hrac.y)/delka);
				break;//vyst�el� v�dy jen jednou
			}
		}
	}
}
