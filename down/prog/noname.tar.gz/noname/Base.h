// Base.h: interface for the CBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASE_H__2E182941_3AA1_11D7_A1EF_BA3BFCE48E72__INCLUDED_)
#define AFX_BASE_H__2E182941_3AA1_11D7_A1EF_BA3BFCE48E72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "define.h"
#include "basestatic.h"

class CBaseMove : public CBaseStatic
{
public:
	virtual void Init(double nx=0.0, double ny=0.0, double nvx=0.0, double nvy=0.0, double u_natoceni=0.0, double u_pohybu=0.0);
	CBaseMove();
	virtual ~CBaseMove();

	virtual void Draw() = 0; // NULL

	double rychlost_x, rychlost_y;//rychlost pohybu v os�ch
	double uhel_natoceni;
	double uhel_pohybu;//sm�r, kterym let�
};

#endif // !defined(AFX_BASE_H__2E182941_3AA1_11D7_A1EF_BA3BFCE48E72__INCLUDED_)
