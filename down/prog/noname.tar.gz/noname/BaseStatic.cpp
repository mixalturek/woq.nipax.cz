// BaseStatic.cpp: implementation of the CBaseStatic class.
//
//////////////////////////////////////////////////////////////////////

#include "BaseStatic.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBaseStatic::CBaseStatic()
{

}

CBaseStatic::~CBaseStatic()
{

}

void CBaseStatic::Init(double nx, double ny)
{
	x = nx;
	y = ny;
}

bool CBaseStatic::IsVisible()
{
	if(x > SIRKA_SC || x < -SIRKA_SC ||	y > VYSKA_SC || y < -VYSKA_SC)//je za okrajem obrazovky
		return false;
	return true;
}
