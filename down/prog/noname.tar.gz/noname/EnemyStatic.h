// EnemyStatic.h: interface for the CEnemyStatic class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ENEMYSTATIC_H__6A632A02_3B5D_11D7_A1EF_ACAF5F653EEE__INCLUDED_)
#define AFX_ENEMYSTATIC_H__6A632A02_3B5D_11D7_A1EF_ACAF5F653EEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseStatic.h"
#include "EnemyStrela.h"	// Added by ClassView


#define POCET_STREL 10

class CEnemyStatic : public CBaseStatic  
{
public:
	void Vystrel();
	CEnemyStrela strela[POCET_STREL];
	void Draw();
	CEnemyStatic();
	virtual ~CEnemyStatic();

	int life;

private:
	unsigned int counter_draw;//d�l� prodlevu mezi st�elami
};

#endif // !defined(AFX_ENEMYSTATIC_H__6A632A02_3B5D_11D7_A1EF_ACAF5F653EEE__INCLUDED_)
