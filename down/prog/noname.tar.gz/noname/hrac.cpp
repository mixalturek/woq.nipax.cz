// hrac.cpp: implementation of the hrac class.
//
//////////////////////////////////////////////////////////////////////

#include "hrac.h"
#include <math.h>

extern GLUquadricObj *quadratic;// Bude ukl�dat quadratic objekt
extern GLuint texture[POCET_TEXTUR];

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHrac::CHrac()
{
	life = 100;
}

CHrac::~CHrac()
{

}

void CHrac::Draw()
{
// LO�
	glLoadIdentity();
	
	glTranslated(x, y, HLOUBKA_SC);// pozice
	glRotated(uhel_natoceni, 0.0, 0.0, 1.0);
	glRotated(rot_vlastni_osa, 1.0, 0.0, 0.0);//ot��en� kolem sv� osy
	glRotated(90.0, 0.0, 1.0, 0.0);//aby byla lo� vid�t z boku (ne zezadu)
	glTranslated(0.0, 0.0, -DELKA_LODI/2.0);//vycentrov�n�

	glDisable(GL_BLEND);
	glEnable(GL_LIGHTING);
	
	glBindTexture(GL_TEXTURE_2D, texture[TEXTURA_HRAC]);// Vybere texturu
	gluCylinder(quadratic,POLOMER_LODI,0.0f,DELKA_LODI,15,8);// Lo�

// V�FUKOV� PLYN
	if(stisk_zrychleni) // v�fuk
	{
		glLoadIdentity();
		glTranslated(x, y, HLOUBKA_SC);// pozice
		glRotated(uhel_natoceni, 0.0, 0.0, 1.0);
		
		glDisable(GL_LIGHTING);
		glEnable(GL_BLEND);// o�e�e �ernou ��st textury
		glColor4ub(255, 255, 0, 255); // �lut� barva
		
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURA_PARTICLE]);
		glBegin(GL_TRIANGLE_STRIP);
			glTexCoord2d(1,1); glVertex3d(-DELKA_LODI/15,  1.8  , 0.0);// Horn� prav�
			glTexCoord2d(0,1); glVertex3d(-3.0,            1.8, 0.0);// Horn� lev�
			glTexCoord2d(1,0); glVertex3d(-DELKA_LODI/15, -1.8, 0.0);// Doln� prav�
			glTexCoord2d(0,0); glVertex3d(-3.0,           -1.8, 0.0);// Doln� lev�
		glEnd();
	}

// ST�ELA
	strela.Draw();

// POHYBUJE SE
	rot_vlastni_osa += 3.0;//ot��� se kolem sv� osy

	x += rychlost_x;//pohyb na ose x
	y += rychlost_y;//pohyb na ose y

// POKUD ZAJEDE ZA OKRAJ, ODRAZ� SE

	if(x > SIRKA_SC || x < -SIRKA_SC)
		rychlost_x = -rychlost_x;

	if(y > VYSKA_SC || y < -VYSKA_SC)
		rychlost_y = -rychlost_y;

}

void CHrac::Init(double nx, double ny, double nvx, double nvy, double u_natoceni, double u_pohybu)
{
	CBaseMove::Init(nx, ny, nvx, nvy, u_natoceni, u_pohybu);

	stisk_zrychleni = false;

	rot_vlastni_osa=0.0;

	key_faster = VK_UP;
	key_po_smeru = VK_RIGHT;
	key_proti_smeru = VK_LEFT;
	key_vystrel = VK_SPACE;
}

void CHrac::Vystrel()
{
	strela.active = true;
	strela.zasah = false;
	strela.SetColor(235, 205, 100);

	strela.Init(x, y, 0.1 * cos(uhel_natoceni * PI180), 0.1 * sin(uhel_natoceni * PI180));
}
