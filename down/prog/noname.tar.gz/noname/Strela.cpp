// Strela.cpp: implementation of the CStrela class.
//
//////////////////////////////////////////////////////////////////////

#include "Strela.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CStrela::CStrela()
{
	active = false;
}

CStrela::~CStrela()
{

}

void CStrela::Draw()
{
	if(active)
	{
		glLoadIdentity();
		glTranslated(x, y, HLOUBKA_SC);// pozice

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURA_PARTICLE]);
		glColor3ub(r, g, b);
		glEnable(GL_BLEND);
		glDisable(GL_LIGHTING);
		glBegin(GL_TRIANGLE_STRIP);
			glTexCoord2d(1,1); glVertex3d( 0.5, 0.5, 0.0);// Horn� prav�
			glTexCoord2d(0,1); glVertex3d(-0.5, 0.5, 0.0);// Horn� lev�
			glTexCoord2d(1,0); glVertex3d( 0.5,-0.5, 0.0);// Doln� prav�
			glTexCoord2d(0,0); glVertex3d(-0.5,-0.5, 0.0);// Doln� lev�
		glEnd();

		x += rychlost_x;//pohyb na ose x
		y += rychlost_y;//pohyb na ose y

		if(!IsVisible())//nejde vid�t
			active = false;//neaktivn� (hr�� m��e znovu vyst�elit)
	}
}

void CStrela::SetColor(unsigned __int8 nr, unsigned __int8 ng, unsigned __int8 nb)
{
	r = nr;
	g = ng;
	b = nb;
}
