// Strela.h: interface for the CStrela class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STRELA_H__2E182942_3AA1_11D7_A1EF_BA3BFCE48E72__INCLUDED_)
#define AFX_STRELA_H__2E182942_3AA1_11D7_A1EF_BA3BFCE48E72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Base.h"

#include "define.h"

#include "windows.h"
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library



extern GLuint texture[POCET_TEXTUR];

class CStrela : public CBaseMove
{
public:
	void SetColor(unsigned __int8 nr = 255, unsigned __int8 ng = 255, unsigned __int8 nb = 255);
	bool active;
	unsigned __int8 r, g, b;
	bool zasah;

	virtual void Draw();
	CStrela();
	virtual ~CStrela();
};

#endif // !defined(AFX_STRELA_H__2E182942_3AA1_11D7_A1EF_BA3BFCE48E72__INCLUDED_)
