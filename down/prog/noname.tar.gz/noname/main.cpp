/*
 *		This Code Was Created By Jeff Molofee 2000
 *		A HUGE Thanks To Fredric Echols For Cleaning Up
 *		And Optimizing This Code, Making It More Flexible!
 *		If You've Found This Code Useful, Please Let Me Know.
 *		Visit My Site At nehe.gamedev.net
 */

#include "define.h"

#pragma comment (lib,"opengl32.lib")
#pragma comment (lib,"glu32.lib")
#pragma comment (lib,"glaux.lib")

//#include "afx.h"
#include <windows.h>		// Header File For Windows
#include <stdio.h>
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include <math.h>
#include <time.h>

#include "hrac.h"
#include "enemystatic.h"


HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application

bool	keys[256];			// Array Used For The Keyboard Routine
bool	active=TRUE;		// Window Active Flag Set To TRUE By Default
bool	fullscreen=TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default

GLuint texture[POCET_TEXTUR];
GLUquadricObj *quadratic;// Bude ukl�dat quadratic objekt
GLuint base;// Ukazatel na prvn� z display list� pro font

CHrac hrac;
CEnemyStatic enemy_static[POCET_NEPRATEL];

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc

AUX_RGBImageRec *LoadBMP(char *Filename)				// Loads A Bitmap Image
{
	FILE *File=NULL;									// File Handle

	if (!Filename)										// Make Sure A Filename Was Given
	{
		return NULL;									// If Not Return NULL
	}

	File=fopen(Filename,"r");							// Check To See If The File Exists

	if (File)											// Does The File Exist?
	{
		fclose(File);									// Close The Handle
		return auxDIBImageLoad(Filename);				// Load The Bitmap And Return A Pointer
	}

	return NULL;										// If Load Failed Return NULL
}

int LoadGLTextures()									// Load Bitmaps And Convert To Textures
{
	int Status=FALSE;									// Status Indicator

	AUX_RGBImageRec *TextureImage[POCET_TEXTUR];					// Create Storage Space For The Texture

	memset(TextureImage,0,sizeof(void *)*POCET_TEXTUR);           	// Set The Pointer To NULL

	// Load The Bitmap, Check For Errors, If Bitmap's Not Found Quit
	if ((TextureImage[0]=LoadBMP("data/hrac.bmp")) 
		&& (TextureImage[1]=LoadBMP("data/font.bmp"))
		&& (TextureImage[2]=LoadBMP("data/particle.bmp"))
		&& (TextureImage[3]=LoadBMP("data/nepr_nepohyb.bmp")))
	{
		Status=TRUE;									// Set The Status To TRUE

		glGenTextures(POCET_TEXTUR, &texture[0]);					// Create The Texture

		for (int loop=0; loop<POCET_TEXTUR; loop++)// Generuje jednotliv� textury
		{

			// Typical Texture Generation Using Data From The Bitmap
			glBindTexture(GL_TEXTURE_2D, texture[loop]);
			glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[loop]->sizeX, TextureImage[loop]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[loop]->data);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		}
	}

	for (int loop=0; loop<POCET_TEXTUR; loop++)
	{
		if (TextureImage[loop])									// If Texture Exists
		{
			if (TextureImage[loop]->data)							// If Texture Image Exists
			{
				free(TextureImage[loop]->data);					// Free The Texture Image Memory
			}

			free(TextureImage[loop]);								// Free The Image Structure
		}
	}

	return Status;										// Return The Status
}

GLvoid glPrint(GLint x, GLint y, double scx, double scy, const char *fmt, ...)	// Custom GL "Print" Routine
{
	char text[256];								// Holds Our String
	va_list ap;										// Pointer To List Of Arguments
	if (fmt == NULL)									// If There's No Text
		return;											// Do Nothing
	
	va_start(ap, fmt);									// Parses The String For Variables
	    vsprintf(text, fmt, ap);						// And Converts Symbols To Actual Numbers
	va_end(ap);											// Results Are Stored In Text

	glDisable(GL_DEPTH_TEST);// Vypne hloubkov� testov�n�
	glDisable(GL_LIGHTING);
	glEnable(GL_BLEND);

	glMatrixMode(GL_PROJECTION);// Vybere projek�n� matici
	glPushMatrix();// Ulo�� projek�n� matici
	glLoadIdentity();// Reset matice
	glOrtho(0, 640, 0, 480, 1, -1);// Nastaven� kolm� projekce
	glMatrixMode(GL_MODELVIEW);// V�b�r matice
	glPushMatrix();// Ulo�en� matice
	glLoadIdentity();// Reset matice
	glTranslated(x,y,0);// Pozice textu (0,0 - lev� doln�)
	
	glBindTexture(GL_TEXTURE_2D, texture[TEXTURA_FONT]);

	glPushAttrib(GL_LIST_BIT);							// Pushes The Display List Bits
	glListBase(base);// Sets The Base Character to 0
	
	glScaled(scx, scy, 1.0);
	glCallLists(strlen(text), GL_UNSIGNED_BYTE, text);	// Draws The Display List Text
	glPopAttrib();										// Pops The Display List Bits

	glMatrixMode(GL_PROJECTION);// V�b�r projek�n� matice
	glPopMatrix();// Obnoven� ulo�en� projek�n� matice
	glMatrixMode(GL_MODELVIEW);// V�b�r matice modelview
	glPopMatrix();// Obnoven� ulo�en� modelview matice

	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);// Zapne hloubkov� testov�n�
}

GLvoid BuildFont(GLvoid)								// Build Our Font Display List
{
	float	cx;											// Holds Our X Character Coord
	float	cy;											// Holds Our Y Character Coord

	base=glGenLists(256);								// Creating 256 Display Lists
	for (int loop=0; loop<256; loop++)						// Loop Through All 256 Lists
	{
		cx=float(loop%16)/16.0f;						// X Position Of Current Character
		cy=float(loop/16)/16.0f;						// Y Position Of Current Character

		glNewList(base+loop,GL_COMPILE);				// Start Building A List
			glEnable(GL_BLEND);
			glDisable(GL_LIGHTING);
			glEnable(GL_TEXTURE_2D);
			glBegin(GL_QUADS);							// Use A Quad For Each Character
				glTexCoord2f(cx,1-cy-0.0625f);			// Texture Coord (Bottom Left)
				glVertex2i(0,0);						// Vertex Coord (Bottom Left)
				glTexCoord2f(cx+0.0625f,1-cy-0.0625f);	// Texture Coord (Bottom Right)
				glVertex2i(16,0);						// Vertex Coord (Bottom Right)
				glTexCoord2f(cx+0.0625f,1-cy);			// Texture Coord (Top Right)
				glVertex2i(16,16);						// Vertex Coord (Top Right)
				glTexCoord2f(cx,1-cy);					// Texture Coord (Top Left)
				glVertex2i(0,16);						// Vertex Coord (Top Left)
			glEnd();									// Done Building Our Quad (Character)
			glTranslated(10,0,0);						// Move To The Right Of The Character
			glDisable(GL_BLEND);
		glEndList();									// Done Building The Display List
	}													// Loop Until All 256 Are Built
}

GLvoid KillFont(GLvoid)									// Delete The Font From Memory
{
	glDeleteLists(base,256);							// Delete All 256 Display Lists
}

GLvoid ReSizeGLScene(GLsizei width, GLsizei height)		// Resize And Initialize The GL Window
{
	if (height==0)										// Prevent A Divide By Zero By
	{
		height=1;										// Making Height Equal One
	}

	glViewport(0,0,width,height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,100.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
}

int InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	if (!LoadGLTextures())// Nahraje texturu
	{
		return FALSE;
	}

	BuildFont();// Vytvo�� font

	glBlendFunc(GL_SRC_ALPHA,GL_ONE);// Vybere typ blendingu
	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);

	quadratic=gluNewQuadric();// Vr�t� ukazatel na nov� quadratic
	gluQuadricNormals(quadratic, GLU_SMOOTH);// Vygeneruje norm�lov� vektory (hladk�)
	gluQuadricTexture(quadratic, GL_TRUE);// Vygeneruje texturov� koordin�ty

	return TRUE;
}

int DrawGLScene(GLvoid)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	for(int i=0; i<POCET_NEPRATEL; i++)//vykreslen� nep��tel
	{
		enemy_static[i].Draw();
	}

	hrac.Draw();//vykreslen� hr��e
		
	glColor3ub(0,0,255);
	glPrint(50, 400, 3.0, 2.0, "Max Corporation �");
	glPrint(240,300, 0.7, 0.7, "http://www.maxcorp.zde.cz/");

	glColor3ub(255,255,0);
	glPrint(0, 200, 0.6, 0.6,"Hr��  - %d", hrac.life);
	glColor3ub(255,0,0);
	glPrint(0, 190, 0.6, 0.6,"Nep�. - %d", enemy_static[0].life);

	glColor3ub(255,255,255);
	glPrint(65, 0, 0.7, 0.7, "fullscreen/wokno=|F1| ; konec=|ESC| ; pohyb=|�ipky| ; st�elba=|SPACE|");

/*	ZJI�T�N� VELIKOSTI VIDITELN� SC�NY

	glLoadIdentity();
	glTranslated(0,0,HLOUBKA_SC);
	glDisable(GL_TEXTURE_2D);
	glColor3ub(255,0,0);
	glBegin(GL_QUADS);
		glVertex3d(-30,-10, 0);//lev dol
		glVertex3d(-30, 20, 0);//lev hor
		glVertex3d( 28, 20, 0);//prav hor
		glVertex3d( 28,-10, 0);//prav dol
	glEnd();
*/
	return TRUE;
}

GLvoid KillGLWindow(GLvoid)								// Properly Kill The Window
{
	if (fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Ne�sp�n� voln�n� DC a RC.","UKON�OVAC� ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Ne�sp�n� uvoln�n� renderovac�ho kontextu.","UKON�OVAC� ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Ne�sp�n� uvoln�n� kontextu za��zen�.","UKON�OVAC� ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Ne�sp�n� uvoln�n� hWnd.","UKON�OVAC� ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Nelze odregistrovat t��du okna.","UKON�OVAC� ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}

	KillFont();//sma�e font
}

/*	This Code Creates Our OpenGL Window.  Parameters Are:					*
 *	title			- Title To Appear At The Top Of The Window				*
 *	width			- Width Of The GL Window Or Fullscreen Mode				*
 *	height			- Height Of The GL Window Or Fullscreen Mode			*
 *	bits			- Number Of Bits To Use For Color (8/16/24/32)			*
 *	fullscreenflag	- Use Fullscreen Mode (TRUE) Or Windowed Mode (FALSE)	*/
 
BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	fullscreen=fullscreenflag;			// Set The Global Fullscreen Flag

	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Nelze zaregistrovat t��du okna.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}
	
	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"Po�adovan� fullscreenov� m�d nen� podporovan�\nva�� grafickou kartou. Chcete b�h v okn�?","ERROR",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				fullscreen=FALSE;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL,"Program bude ukon�en.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;									// Return FALSE
			}
		}
	}

	if (fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"OpenGL",							// Class Name
								title,								// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								0, 0,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Error p�i vytv��en� okna.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(hWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Nelze vytvo�it kontext za��zen�.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Nelze naj�t odpov�daj�c� PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Nelze nastavit PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Nelze vytvo�it renderovac� kontext.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Nelze aktivovat renderovac� kontext.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Ne�sp�n� inicializace.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	return TRUE;									// Success
}

LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=TRUE;						// Program Is Active
			}
			else
			{
				active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

		case WM_SYSCOMMAND:							// Intercept System Commands
		{
			switch (wParam)							// Check System Calls
			{
				case SC_SCREENSAVE:					// Screensaver Trying To Start?
				case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
			break;									// Exit
		}

		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

		case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			keys[wParam] = TRUE;					// If So, Mark It As TRUE
			return 0;								// Jump Back
		}

		case WM_KEYUP:								// Has A Key Been Released?
		{
			keys[wParam] = FALSE;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}

		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

int WINAPI WinMain(	HINSTANCE	hInstance,			// Instance
					HINSTANCE	hPrevInstance,		// Previous Instance
					LPSTR		lpCmdLine,			// Command Line Parameters
					int			nCmdShow)			// Window Show State
{
	srand((unsigned) time(NULL));//incializace gener�toru randomov�ch ��sel

	MSG		msg;									// Windows Message Structure
	BOOL	done=FALSE;								// Bool Variable To Exit Loop

// NA�TEN� INICIALIZA�N�CH HODNOT (velikost okna...)
	FILE *fr;
	if((fr=fopen("settings.txt","r"))==NULL)
	{
		MessageBox(NULL,"Nelze otev��t soubor SETTINGS.TXT s inicializa�n�mi hodnotami.\nProgram bude okon�en.","ERROR",MB_ICONSTOP);
		return 0;
	}

	//pomocn� prom�nn�
	int color_depth=32, fullscreen_width=1024, fullscreen_height=768, window_width=640, window_height=480;
	fscanf(fr,"%d - barevna hloubka\n", &color_depth);
	fscanf(fr,"%d - sirka obrazovky pro fullscreen\n", &fullscreen_width);
	fscanf(fr,"%d - vyska obrazovky pro fullscreen\n", &fullscreen_height);
	fscanf(fr,"%d - sirka okna pro wokenni mod\n", &window_width);
	fscanf(fr,"%d - vyska okna pro wokenni mod\n", &window_height);

	// Ask The User Which Screen Mode They Prefer
	if (MessageBox(NULL,"Chcete b�h ve fullscreenu?", "Fullscreen?",MB_YESNO|MB_ICONQUESTION)==IDNO)
	{
		fullscreen=FALSE;							// Windowed Mode
	}

	// Create Our OpenGL Window
	if(fullscreen)
	{
		if (!CreateGLWindow("NoName", fullscreen_width, fullscreen_height, color_depth, fullscreen))
		{
			return 0;									// Quit If Window Was Not Created
		}
	}
	else
	{
		if (!CreateGLWindow("Max Corporation", window_width, window_height, color_depth, fullscreen))
		{
			return 0;						// Quit If Window Was Not Created
		}
	}

	hrac.Init();//inicializace hr��e

	for(int i=0; i<POCET_NEPRATEL; i++)//inicializace nep��tel
	{
		enemy_static[i].Init(10.0, 10.0);
	}

	while(!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				done=TRUE;							// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if (active)								// Program Active?
			{
				if (keys[VK_ESCAPE])				// Was ESC Pressed?
				{
					done=TRUE;						// ESC Signalled A Quit
				}
				else								// Not Time To Quit, Update Screen
				{
					DrawGLScene();					// Draw The Scene
					SwapBuffers(hDC);				// Swap Buffers (Double Buffering)

					if(keys[hrac.key_proti_smeru])//rotace lodi
					{
						hrac.uhel_natoceni += 1.0;
					}

					if(keys[hrac.key_po_smeru])//rotace lodi
					{
						hrac.uhel_natoceni -= 1.0;
					}

					if(keys[hrac.key_faster])//zrychlov�n� lodi
					{
						hrac.stisk_zrychleni = true;//zobraz� se v�fuk
						// p�epo��t�n� pozice
						hrac.rychlost_x += ZRYCHLENI * cos(hrac.uhel_natoceni * PI180);
						hrac.rychlost_y += ZRYCHLENI * sin(hrac.uhel_natoceni * PI180);
					}

					if(!keys[hrac.key_faster])//konec zrychlov�n� lodi
					{						
						hrac.stisk_zrychleni = false;// zru�� v�fuk
					}

					if(keys[hrac.key_vystrel])//vyst�elen�
					{
						if(!hrac.strela.active)//pokud u� st�ela nen� aktivn�
						{
							hrac.Vystrel();
						}
					}
				}
			}

			if (keys[VK_F1])						// Is F1 Being Pressed?
			{
				keys[VK_F1]=FALSE;					// If So Make Key FALSE
				KillGLWindow();						// Kill Our Current Window
				fullscreen=!fullscreen;				// Toggle Fullscreen / Windowed Mode
				// Recreate Our OpenGL Window
				if(fullscreen)
				{
					if (!CreateGLWindow("NoName", fullscreen_width, fullscreen_height, color_depth, fullscreen))
					{
						return 0;									// Quit If Window Was Not Created
					}
				}
				else
				{
					if (!CreateGLWindow("Max Corporation", window_width, window_height, color_depth, fullscreen))
					{
						return 0;						// Quit If Window Was Not Created
					}
				}			
			}
		}
	}

	// Shutdown
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}