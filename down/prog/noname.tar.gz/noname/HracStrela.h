// HracStrela.h: interface for the CHracStrela class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HRACSTRELA_H__34B23CC1_3C52_11D7_A1EF_DE8F12A22377__INCLUDED_)
#define AFX_HRACSTRELA_H__34B23CC1_3C52_11D7_A1EF_DE8F12A22377__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Strela.h"

class CHracStrela : public CStrela  
{
public:
	CHracStrela();
	virtual ~CHracStrela();
	
	virtual void Draw();

};

#endif // !defined(AFX_HRACSTRELA_H__34B23CC1_3C52_11D7_A1EF_DE8F12A22377__INCLUDED_)
