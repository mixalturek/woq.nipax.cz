// EnemyStrela.cpp: implementation of the CEnemyStrela class.
//
//////////////////////////////////////////////////////////////////////

#include "EnemyStrela.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

extern CHrac hrac;

CEnemyStrela::CEnemyStrela()
{

}

CEnemyStrela::~CEnemyStrela()
{

}

void CEnemyStrela::Draw()
{
	CStrela::Draw();

	if(active && !zasah)//pokud je st�ela aktivn� a je�t� nezas�hla
	{
		if(x < hrac.x+POLOMER_LODI && x > hrac.x-POLOMER_LODI && y < hrac.y+POLOMER_LODI && y > hrac.y-POLOMER_LODI)
		{
			zasah = true;// aby se nedekrementovalo v�ckr�t
			SetColor(100,100,100);

			if(--hrac.life == 0)// ode�te se �ivot a zkontroluje nulov� hodnota
			{
				hrac.Init(); // znovu inicializace
				hrac.life = 100; // nastaven� �ivota zp�t
			}
		}
	}
}
