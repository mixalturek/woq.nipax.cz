// BaseStatic.h: interface for the CBaseStatic class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASESTATIC_H__6A632A01_3B5D_11D7_A1EF_ACAF5F653EEE__INCLUDED_)
#define AFX_BASESTATIC_H__6A632A01_3B5D_11D7_A1EF_ACAF5F653EEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "define.h"

class CBaseStatic  
{
public:
	bool IsVisible();
	virtual void Init(double nx = 0.0, double ny = 0.0);
	virtual void Draw() = 0;// NULL
	CBaseStatic();
	virtual ~CBaseStatic();

	double x,y;//pozice
};

#endif // !defined(AFX_BASESTATIC_H__6A632A01_3B5D_11D7_A1EF_ACAF5F653EEE__INCLUDED_)
