// HracStrela.cpp: implementation of the CHracStrela class.
//
//////////////////////////////////////////////////////////////////////

#include "HracStrela.h"

#include "enemystatic.h"
extern CEnemyStatic enemy_static[POCET_NEPRATEL];

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHracStrela::CHracStrela()
{

}

CHracStrela::~CHracStrela()
{

}

void CHracStrela::Draw()
{
	CStrela::Draw();

	if(active && !zasah)//pokud je st�ela aktivn� a je�t� nezas�hla
	{
		for(int i=0; i<POCET_NEPRATEL; i++)
		{
			if(x < enemy_static[i].x+POLOMER_LODI && x > enemy_static[i].x-POLOMER_LODI && y < enemy_static[i].y+POLOMER_LODI && y > enemy_static[i].y-POLOMER_LODI)
			{
				zasah = true;// aby se nedekrementovalo v�ckr�t
				SetColor(100,100,100);
				
				if(--enemy_static[i].life == 0)// ode�te se �ivot a zkontroluje nulov� hodnota
				{
					enemy_static[i].Init(10.0, 10.0); // reinicializace
					enemy_static[i].life = 10; // nastaven� �ivota zp�t
				}
			}
		}
	}
}