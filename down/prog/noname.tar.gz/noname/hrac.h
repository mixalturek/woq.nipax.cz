// hrac.h: interface for the hrac class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HRAC_H__72CFDBC3_390A_11D7_A1EF_BCB8BD279475__INCLUDED_)
#define AFX_HRAC_H__72CFDBC3_390A_11D7_A1EF_BCB8BD279475__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "define.h"

#include "windows.h"
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

#include "base.h"
#include "hracstrela.h"

class CHrac : public CBaseMove
{
public:
	unsigned int life;
	void Vystrel();
	virtual void Init(double nx=0.0, double ny=0.0, double nvx=0.0, double nvy=0.0, double u_natoceni=0.0, double u_pohybu=0.0);
	virtual void Draw();
	CHrac();
	virtual ~CHrac();

	CHracStrela strela;

	double rot_vlastni_osa;//rotace okolo sv� osy	
	bool stisk_zrychleni;//

	int key_faster, key_po_smeru, key_proti_smeru, key_vystrel;//ukl�d� ovl�d�n� (kl�vesy)
};

#endif // !defined(AFX_HRAC_H__72CFDBC3_390A_11D7_A1EF_BCB8BD279475__INCLUDED_)
