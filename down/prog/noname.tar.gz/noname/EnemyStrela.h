// EnemyStrela.h: interface for the CEnemyStrela class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ENEMYSTRELA_H__6A632A03_3B5D_11D7_A1EF_ACAF5F653EEE__INCLUDED_)
#define AFX_ENEMYSTRELA_H__6A632A03_3B5D_11D7_A1EF_ACAF5F653EEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Strela.h"
#include "hrac.h"

class CEnemyStrela : public CStrela  
{
public:
	virtual void Draw();
	CEnemyStrela();
	virtual ~CEnemyStrela();
};

#endif // !defined(AFX_ENEMYSTRELA_H__6A632A03_3B5D_11D7_A1EF_ACAF5F653EEE__INCLUDED_)
