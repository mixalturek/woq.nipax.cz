/***************************************************************************
 *   trn - semestralni prace do x36osy                                     *
 *   Copyright (C) 2006 by Michal Turek                                    *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#include <cctype>
#include <ctime>
#include "all.h"
#include "ctranslater.h"

#define DEBUG

/////////////////////////////////////////////////////////////////////////////
//// Konstanty

const int NUM_TRANSLATERS = 3;
const int NUM_CLIENTS = 30;
const int MAX_CHARS = 100;

#ifdef DEBUG
const int MAX_DELAY = 100000;
#endif


/////////////////////////////////////////////////////////////////////////////
//// Promenne

vector<pthread_t> g_translater_threads;// Stacilo by i obycejny pole,
vector<pthread_t> g_client_threads;// ale uz to predelavat nebudu
CTranslater g_translaters[NUM_TRANSLATERS];

pthread_mutex_t g_io_mutex = PTHREAD_MUTEX_INITIALIZER;

bool g_done = false;


/////////////////////////////////////////////////////////////////////////////
//// Nahodne zpozdeni

#ifdef DEBUG
void Delay()
{
	int stop = rand() % MAX_DELAY;

	for(int i = 0; i < stop; i++)
		;
}
#endif


/////////////////////////////////////////////////////////////////////////////
//// Vlakno prekladatelu

void* TranslaterThread(void* arg)
{
	char c;
	int counter;
	CTranslater* tr = (CTranslater*)arg;
	int my_id = tr->GetID();

	pthread_mutex_lock(&g_io_mutex);
	cout << "Translater " << my_id << ": Entering thread" << endl;
	pthread_mutex_unlock(&g_io_mutex);


	/* Kdyby prekladatel ani jednou behem vykonavani programu neprekladal
	 * znaky, tak by se zaseknul v podminene promenne v CTranslater::Pop()
	 * (nema definovan timeout) a program by se nikdy neukoncil
	 * Aby se to projevilo, staci zakomentovat nasledujici prikaz, nastavit
	 * vic prekladatelu nez klientu, prekompilovat a spustit...
	 */
	tr->JobFinished();


	while(!g_done)
	{
		counter = 0;

		while((c = tr->Pop()) != '\0')
		{
			pthread_mutex_lock(&g_io_mutex);
			if(c >= 'a' && c <= 'z')
				cout << "Translater " << my_id << ": "
				<< c << " -> " << (char)toupper(c) << endl;
			else
				cout << "Translater " << my_id << ": "
				<< c << " -> " << (char)tolower(c) << endl;
			pthread_mutex_unlock(&g_io_mutex);
			counter++;

#ifdef DEBUG
			Delay();
#endif
		}

		pthread_mutex_lock(&g_io_mutex);
		cout << "Translater " << my_id << ": "
			<< "Translated " << counter << " characters" << endl;
		pthread_mutex_unlock(&g_io_mutex);

		tr->JobFinished();
	}


	pthread_mutex_lock(&g_io_mutex);
	cout << "Translater " << my_id << ": " << "Leaving thread" << endl;
	pthread_mutex_unlock(&g_io_mutex);

	return NULL;
}


/////////////////////////////////////////////////////////////////////////////
//// Vlakno klientu

void* ClientThread(void* arg)
{
	int my_id = (int)arg;
	int tr_id;
	int i;
	int num_chars = 1 + rand() % MAX_CHARS;
	char c;

	pthread_mutex_lock(&g_io_mutex);
	cout << "Client " << my_id << ": Entering thread" << endl;
	pthread_mutex_unlock(&g_io_mutex);

#ifdef DEBUG
	Delay();
#endif

	for(i = 0; i < NUM_TRANSLATERS; i++)// Hleda volneho prekladatele
	{
		if(g_translaters[i].TryToOccupy())
			break;
	}

	if(i == NUM_TRANSLATERS)// Zadny prekladatel volny
	{
		pthread_mutex_lock(&g_io_mutex);
		cout << "Client " << my_id
		<< ": All translaters are occupied, leaving thread" << endl;
		pthread_mutex_unlock(&g_io_mutex);

		return NULL;
	}

	tr_id = i;// ID prekladatele

	for(i = 0; i < num_chars; i++)// Plneni fronty
	{
		if(rand() % 2)
			c = 'a' + (rand() % ('z'-'a'));
		else
			c = 'A' + (rand() % ('Z'-'A'));

		pthread_mutex_lock(&g_io_mutex);
		cout << "Client " << my_id << ">" << tr_id
			<< ": Sending " << c << endl;
		pthread_mutex_unlock(&g_io_mutex);
		g_translaters[tr_id].Push(c);

#ifdef DEBUG
		Delay();
#endif
	}

	pthread_mutex_lock(&g_io_mutex);
	cout << "Client " << my_id << ">" << tr_id << ": Sended " << i
			<< " characters, leaving thread" << endl;
	pthread_mutex_unlock(&g_io_mutex);

	g_translaters[tr_id].Push('\0');// Zarazka

	return NULL;
}


/////////////////////////////////////////////////////////////////////////////
//// Vstup do programu

int main(int argc, char *argv[])
{
	srand(time(NULL));
	g_translater_threads.reserve(NUM_TRANSLATERS);
	g_client_threads.reserve(NUM_CLIENTS);

	try
	{
		for(int i = 0; i < NUM_TRANSLATERS; i++)
		{
			pthread_t tmp;
			int code;

			code = pthread_create(&tmp, NULL, TranslaterThread,
					(void *)&g_translaters[i]);

			if(code != 0)
				throw runtime_error("Unable to create thread");

			g_translater_threads.push_back(tmp);
		}

		for(int i = 0; i < NUM_CLIENTS; i++)
		{
			pthread_t tmp;
			int code;

			code = pthread_create(&tmp, NULL, ClientThread,
					(void *)i);

			if(code != 0)
				throw runtime_error("Unable to create thread");

			g_client_threads.push_back(tmp);

#ifdef DEBUG
			Delay();
#endif
		}

	}
	catch(runtime_error& ex)
	{
		pthread_mutex_lock(&g_io_mutex);
		cerr << ex.what() << endl;
		pthread_mutex_unlock(&g_io_mutex);
		return 1;
	}
	catch(...)
	{
		pthread_mutex_lock(&g_io_mutex);
		cerr << "Unknown exception occured!" << endl;
		pthread_mutex_unlock(&g_io_mutex);
		return 1;
	}


	vector<pthread_t>::iterator it;

	for(it = g_client_threads.begin(); it != g_client_threads.end(); it++)
		pthread_join(*it, NULL);

	g_done = true;

	pthread_mutex_lock(&g_io_mutex);
	cout << "All clients finished" << endl;
	pthread_mutex_unlock(&g_io_mutex);

	for(int i = 0; i < NUM_TRANSLATERS; i++)
		g_translaters[i].CondSignal();

	for(it = g_translater_threads.begin(); it != g_translater_threads.end();
			it++)
		pthread_join(*it, NULL);

	pthread_mutex_lock(&g_io_mutex);
	cout << "All translaters finished" << endl;
	pthread_mutex_unlock(&g_io_mutex);

	pthread_mutex_destroy(&g_io_mutex);

	return 0;
}
