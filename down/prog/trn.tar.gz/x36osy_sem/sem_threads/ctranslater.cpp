/***************************************************************************
 *   trn - semestralni prace do x36osy                                     *
 *   Copyright (C) 2006 by Michal Turek                                    *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "ctranslater.h"

extern bool g_done;
int CTranslater::m_num_translaters = 0;

CTranslater::CTranslater() :
	m_id(m_num_translaters++),
	m_occupied(false)
{
	pthread_mutex_init(&m_mutex, NULL);
	pthread_cond_init(&m_cond, NULL);
}

CTranslater::~CTranslater()
{
	pthread_mutex_destroy(&m_mutex);
	pthread_cond_destroy(&m_cond);
}

void CTranslater::Push(char c)
{
	pthread_mutex_lock(&m_mutex);
	m_queue.push(c);
	pthread_cond_signal(&m_cond);
	pthread_mutex_unlock(&m_mutex);
}

char CTranslater::Pop()
{
	char ret;

	pthread_mutex_lock(&m_mutex);

	while(m_queue.empty())
		pthread_cond_wait(&m_cond, &m_mutex);

	ret = m_queue.front();
	m_queue.pop();

	pthread_mutex_unlock(&m_mutex);

	return ret;
}

bool CTranslater::TryToOccupy()
{
	bool ret;

	pthread_mutex_lock(&m_mutex);
	if(m_occupied)// Zabrany?
		ret = false;
	else// Volny?
	{
		m_occupied = true;
		ret = true;
	}
	pthread_mutex_unlock(&m_mutex);

	return ret;
}

void CTranslater::JobFinished()
{
	// Casovy omezeni je kvuli ukoncovani aplikace

	struct timespec ts;
	struct timeval tp;

	pthread_mutex_lock(&m_mutex);
	m_occupied = false;

	while(!m_occupied)
	{
		gettimeofday(&tp, NULL);
		ts.tv_sec  = tp.tv_sec;
		ts.tv_nsec = tp.tv_usec * 1000;
		ts.tv_sec += 1;

		pthread_cond_timedwait(&m_cond, &m_mutex, &ts);

		if(g_done)
			break;
	}

	pthread_mutex_unlock(&m_mutex);
}

void CTranslater::CondSignal()
{
	pthread_mutex_lock(&m_mutex);// Mozna to tu byt nemusi, nejsem si jistej
	pthread_cond_signal(&m_cond);
	pthread_mutex_unlock(&m_mutex);// a dokumentace je nejaka zmatena :(
}
