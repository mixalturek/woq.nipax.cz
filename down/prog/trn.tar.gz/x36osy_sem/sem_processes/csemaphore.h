/***************************************************************************
 *   trn - semestralni prace do x36osy                                     *
 *   Copyright (C) 2006 by Michal Turek                                    *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#ifndef __CSEMAPHORE_H__
#define __CSEMAPHORE_H__

#include "all.h"

using namespace std;


union semun
{
	int val;
	struct semid_ds *buf;
	unsigned short int *array;
	struct seminfo *__buf;
};
/*
struct sembuf
{
	ushort sem_num;		// ��slo ��ta�e v poli
	short sem_op;		// Operace nad ��ta�em
	short sem_flg;		// IPC_NOWAIT, SEM_UNDO
}
*/

// Binary semaphore
class CSemaphore
{
public:
	CSemaphore(key_t key, int num);
	~CSemaphore();

	void Lock(int which);
	void UnLock(int which);
	void Sleep(int which);
	void Wake(int which);

private:
	int m_id;
	int m_num;
};

#endif
