/***************************************************************************
 *   trn - semestralni prace do x36osy                                     *
 *   Copyright (C) 2006 by Michal Turek                                    *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "ctranslater.h"

CTranslater::CTranslater(int id, key_t sem_key, key_t mem_key, int mem_size) :
	m_id(id),
	m_sem(sem_key, 2),
	m_shmem(mem_key, mem_size + sizeof(bool) + 2*sizeof(int)),
	m_queue_size(mem_size)
{
	m_occupied = (bool*)m_shmem.Attach();
	m_write_pos = (int*)(m_occupied + sizeof(bool));
	m_read_pos = (int*)(m_write_pos + sizeof(int));
	m_queue = (char*)(m_read_pos + sizeof(int));

	*m_occupied = false;
}

CTranslater::~CTranslater()
{

}

void CTranslater::Push(char c)
{
	m_sem.Lock(0);
	if(*m_write_pos < m_queue_size)
		m_queue[(*m_write_pos)++] = c;
	m_sem.UnLock(0);
}

char CTranslater::Pop()
{
	char ret;

	m_sem.Lock(0);
	if(*m_read_pos < *m_write_pos)
		ret = m_queue[(*m_read_pos)++];
	else
		ret = '\0';
	m_sem.UnLock(0);

	return ret;
}

bool CTranslater::TryToOccupy()
{
	bool ret;

	m_sem.Lock(0);
	if(*m_occupied)
		ret = false;
	else
	{
		*m_occupied = true;
		*m_read_pos = 0;
		*m_write_pos = 0;

		ret = true;
	}
	m_sem.UnLock(0);

	return ret;
}

void CTranslater::TranslaterFunc()
{
	cout << "Translater " << m_id << ": Entering process" << endl;

	while(true)
	{
		WaitForJob();

		// New job
		char c;

		for(int i = 0; i < m_queue_size; i++)
		{
			while((c = Pop()) == '\0')
				sleep(0);

			// End of job
			if(c == '*')
				break;

			if(c >= 'a' && c <= 'z')
				cout << "Translater " << m_id << ": "
					<< c << " -> "
					<< (char)toupper(c) << endl;
			else
				cout << "Translater " << m_id << ": "
					<< c << " -> "
					<< (char)tolower(c) << endl;
		}
	}
}

void CTranslater::WaitForJob()
{
	m_sem.Lock(0);
	*m_occupied = false;
	m_sem.UnLock(0);

	cout << "Translater " << m_id << ": "
			<< "No job, sleeping . .. ... .... ..... ......" << endl;
	m_sem.Sleep(1);
	cout << "Translater " << m_id << ": "
			<< "I have just woke up, good morning" << endl;
}

void CTranslater::NewJob()
{
	m_sem.Wake(1);
}
