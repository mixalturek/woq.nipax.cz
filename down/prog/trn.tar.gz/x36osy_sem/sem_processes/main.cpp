/***************************************************************************
 *   trn - semestralni prace do x36osy                                     *
 *   Copyright (C) 2006 by Michal Turek                                    *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


/*
ipcs [-msq]
ipcrm	-m shmid
	-s semid
	-q msqid
*/


#include "all.h"
#include "ctranslater.h"


/////////////////////////////////////////////////////////////////////////////
//// Constants

#define DEBUG

#define SHM_KEY 987654
#define SEM_KEY 589641

const int NUM_TRANSLATERS = 3;
const int NUM_CLIENTS = 30;
const int MAX_CHARS = 100;

#ifdef DEBUG
const int MAX_DELAY = 10000000;
#endif


/////////////////////////////////////////////////////////////////////////////
//// Variables

pid_t g_pid_translaters[NUM_TRANSLATERS];	// Translaters PID
pid_t g_pid_clients[NUM_CLIENTS];		// Clients PID

CTranslater* g_translaters[NUM_TRANSLATERS];


/////////////////////////////////////////////////////////////////////////////
//// Random delay

#ifdef DEBUG
void Delay()
{
	int stop = rand() % MAX_DELAY;

	for(int i = 0; i < stop; i++)
		;
}
#endif


/////////////////////////////////////////////////////////////////////////////
////

bool Init()
{
	for(int i = 0; i < NUM_TRANSLATERS; i++)
		g_translaters[i] = NULL;

	try
	{
		for(int i = 0; i < NUM_TRANSLATERS; i++)
			g_translaters[i] = new CTranslater(i,
					SEM_KEY+i, SHM_KEY+i, MAX_CHARS);
	}
	catch(runtime_error& ex)
	{
		cerr << "Initialization failed: " << ex.what() << endl;
		return false;
	}

	return true;
}

void Destroy()
{
	for(int i = 0; i < NUM_TRANSLATERS; i++)
	{
		if(g_translaters[i] != NULL)
		{
			delete g_translaters[i];
			g_translaters[i] = NULL;
		}
	}
}


/////////////////////////////////////////////////////////////////////////////
//// Client process

void Client(int my_id)
{
	cout << "Client " << my_id << ": Entering process" << endl;
	int tr_id;
	int i;
	int num_chars = 1 + rand() % MAX_CHARS;
	char c;

	srand(time(NULL));// V main() nema vyznam... :-)

#ifdef DEBUG
	Delay();
#endif

	for(i = 0; i < NUM_TRANSLATERS; i++)// Hleda volneho prekladatele
	{
		if(g_translaters[i]->TryToOccupy())
			break;
	}

	if(i == NUM_TRANSLATERS)// Zadny prekladatel volny
	{
		cout << "Client " << my_id
		<< ": All translaters are occupied, leaving process" << endl;

		return;
	}

	tr_id = i;// ID prekladatele
	cout << "Client " << my_id << ">" << tr_id
			<< ": Weaking up translater" << endl;
	g_translaters[tr_id]->NewJob();

	for(i = 0; i < num_chars; i++)// Plneni fronty
	{
		if(rand() % 2)
			c = 'a' + (rand() % ('z'-'a'));
		else
			c = 'A' + (rand() % ('Z'-'A'));

		cout << "Client " << my_id << ">" << tr_id
			<< ": Sending " << c << endl;

		g_translaters[tr_id]->Push(c);

#ifdef DEBUG
		Delay();
#endif
	}

	cout << "Client " << my_id << ">" << tr_id << ": Sended " << i
			<< " characters, leaving process" << endl;

	g_translaters[tr_id]->Push('*');// Zarazka
}


/////////////////////////////////////////////////////////////////////////////
//// Enter to program

int main(int argc, char *argv[])
{
	try
	{
//		srand(time(NULL));// Do kazdyho klienta

		if(!Init())
		{
//			cerr << "!Init()" << endl;
			Destroy();
			return 1;
		}

		pid_t child_pid;

		for(int i = 0; i < NUM_TRANSLATERS; i++)
		{
			child_pid = fork();

			if(child_pid == 0)// Child
			{
				g_translaters[i]->TranslaterFunc();
				return 0;
			}
			else// Parent
				g_pid_translaters[i] = child_pid;
		}


		for(int i = 0; i < NUM_CLIENTS; i++)
		{
			child_pid = fork();

			if(child_pid == 0)// Child
			{
				Client(i);
				return 0;
			}
			else// Parent
				g_pid_clients[i] = child_pid;

#ifdef DEBUG
			Delay();
#endif
		}


		for(int i = 0; i < NUM_CLIENTS; i++)
		{
			waitpid(g_pid_clients[i], NULL, 0);
			cout << "Client " << i << ": finished" << endl;
		}

//		cerr << "sleeping" << endl;
//		sleep(5);

		for(int i = 0; i < NUM_TRANSLATERS; i++)
		{
/*			char *shm;

			if((shm = (char *)shmat(g_shm_id[i], NULL, 0)) == (char *)-1)
			{
				perror("Shmat failed");
				kill(g_pid_translaters[i], SIGTERM);
				continue;
			}
			shm[0] = '*';
			if(shmdt(shm) < 0)
			{
				perror("Shmdt failed");
				// What to do?
			}
*/
//			waitpid(g_pid_translaters[i], NULL, 0);
			kill(g_pid_translaters[i], SIGTERM);
			cout << "Translater " << i << ": finished" << endl;
		}

		Destroy();
	}
	catch(runtime_error& ex)
	{
		cerr << ex.what() << endl;
		return 1;
	}
	catch(...)
	{
		cerr << "Unknown exception occured!" << endl;
		return 1;
	}

	return 0;
}
