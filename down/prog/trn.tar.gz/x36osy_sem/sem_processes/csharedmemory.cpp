/***************************************************************************
 *   trn - semestralni prace do x36osy                                     *
 *   Copyright (C) 2006 by Michal Turek                                    *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#include "csharedmemory.h"

using namespace std;


CSharedMemory::CSharedMemory(key_t key, int size) :
	m_id(-1),
	m_size(size),
	m_data(NULL)
{
	if((m_id = shmget(key, size, IPC_CREAT | 0600)) < 0)
		throw runtime_error("Shmget failed");
}

CSharedMemory::~CSharedMemory()
{
	Detach();

	if(m_id != -1)
	{
		if(shmctl(m_id, IPC_RMID, 0) < 0)
		{
			throw runtime_error("Shmctl failed");
		}
	}
}

char* CSharedMemory::Attach()
{
	if(m_data != NULL)
		return m_data;

	if((m_data = (char *)shmat(m_id, NULL, 0)) == (char *)-1)
	{
		m_data = NULL;
		throw runtime_error("Shmat failed");
	}

	return m_data;
}

void CSharedMemory::Detach()
{
	if(m_data != NULL)
	{
		if(shmdt(m_data) < 0)
			throw runtime_error("Shmdt failed");

		m_data = NULL;
	}
}

