/***************************************************************************
 *   trn - semestralni prace do x36osy                                     *
 *   Copyright (C) 2006 by Michal Turek                                    *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#include "csemaphore.h"

using namespace std;


CSemaphore::CSemaphore(key_t key, int num) :
	m_id(-1),
	m_num(num)
{
	if((m_id = semget(key, m_num, IPC_CREAT | 0600)) < 0)
	{
		throw runtime_error("Semget failed");
	}


	union semun argument;
	unsigned short values[m_num];

	for(int i = 0; i < m_num; i++)
		values[i] = 1;

	argument.array = values;

	if(semctl(m_id, 0, SETALL, argument) < 0)
		throw runtime_error("Semctl failed");
}

CSemaphore::~CSemaphore()
{
	if(m_id != -1)
	{
		semun ignored_argument;

		if(semctl(m_id, m_num, IPC_RMID, ignored_argument) < 0 )
			throw runtime_error("Semctl failed");
	}
}

void CSemaphore::Lock(int which)
{
	sembuf operations[1];

	operations[0].sem_num = which;		// Use the first counter
	operations[0].sem_op = -1;		// Decrement by 1
	operations[0].sem_flg = SEM_UNDO;	// Permit undo'ing

	if(semop(m_id, operations, 1) < 0)
		throw runtime_error("Semop failed");
}

void CSemaphore::UnLock(int which)
{
	sembuf operations[1];

	operations[0].sem_num = which;		// Use the first counter
	operations[0].sem_op = 1;		// Decrement by 1
	operations[0].sem_flg = SEM_UNDO;	// Permit undo'ing

	if(semop(m_id, operations, 1) < 0)
		throw runtime_error("Semop failed");
}

void CSemaphore::Sleep(int which)
{
	sembuf operations[1];

	operations[0].sem_num = which;		// Use the first counter
	operations[0].sem_op = 0;		// Sleep
	operations[0].sem_flg = SEM_UNDO;	// Permit undo'ing

	if(semop(m_id, operations, 1) < 0)
		throw runtime_error("Semop failed");
}

void CSemaphore::Wake(int which)
{
	Lock(which);
	UnLock(which);// ?
}
