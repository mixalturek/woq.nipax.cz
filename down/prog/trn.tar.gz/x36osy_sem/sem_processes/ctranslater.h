/***************************************************************************
 *   trn - semestralni prace do x36osy                                     *
 *   Copyright (C) 2006 by Michal Turek                                    *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#ifndef __CTRANSLATER_H__
#define __CTRANSLATER_H__

#include "all.h"
#include "csemaphore.h"
#include "csharedmemory.h"


class CTranslater
{
public:
	CTranslater(int id, key_t sem_key, key_t mem_key, int mem_size);
	~CTranslater();

	bool TryToOccupy();// true = byl volny a muze se zacit pouzivat

	void Push(char c);
	char Pop();// Return \0 if empty

	void TranslaterFunc();
	void WaitForJob();
	void NewJob();

private:
	int m_id;// Vypisy

	CSemaphore m_sem;
	CSharedMemory m_shmem;
	int m_queue_size;

	// Pointers to shared memory
	// | m_occupied | m_write_pos | m_read_pos | m_queue |

	bool* m_occupied;
	int* m_write_pos;
	int* m_read_pos;
	char* m_queue;
};


#endif
