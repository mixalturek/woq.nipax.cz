/***************************************************************************
 *   Knapsack problem #5 - genetic algorihms                               *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cknapsack.hpp"
#include <algorithm>

/////////////////////////////////////////////////////////////////////////////
////

CKnapsack::CKnapsack(int ID, int n, int M, vector<THING>& data)
	:
	m_ID(ID),
	m_n(n),
	m_M(M),
	m_things(data),
	m_population(NULL),
	m_new_population(NULL),
	m_cur_best(),
	m_best(),
	m_num_populations(0),
	m_last_best_change(m_num_populations)
{
	assert(n < MAX_THINGS);
	assert(NUM_COPIED_BEST_PARRENTS < POPULATION_SIZE);
	assert(POPULATION_SIZE*2 < NEW_POPULATION_SIZE);

	m_population = new CHROMOSOME[POPULATION_SIZE];
	m_new_population = new CHROMOSOME[NEW_POPULATION_SIZE];
}


/////////////////////////////////////////////////////////////////////////////
////

CKnapsack::~CKnapsack()
{
	if(m_population != NULL)
		delete [] m_population;

	if(m_new_population != NULL)
		delete [] m_new_population;
}


/////////////////////////////////////////////////////////////////////////////
////

void CKnapsack::InitializePopulation()
{
	for(int i = 0; i < POPULATION_SIZE; i++)
	{
		m_population[i].things = 0;
		m_population[i].weight = 0;
		m_population[i].cost = 0;

		for(int j = 0; j < m_n; j++)
		{
			if(rand() % 2)
			{
				m_population[i].things[j] = true;
				m_population[i].weight += m_things[j].weight;
				m_population[i].cost += m_things[j].cost;
			}
		}
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void CKnapsack::Mutation(CHROMOSOME& ch)
{
	int pos = rand() % m_n;

	ch.things[pos] = !ch.things[pos];

	if(ch.things[pos])
	{
		ch.weight += m_things[pos].weight;
		ch.cost += m_things[pos].cost;
	}
	else
	{
		ch.weight -= m_things[pos].weight;
		ch.cost -= m_things[pos].cost;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

bool CompareChromosomes(const CHROMOSOME& c1, const CHROMOSOME& c2)
{
	return c1.cost > c2.cost;
}

void CKnapsack::Reproduction(void)
{
	int i = 0;
	int j = 0;

	// Copy best from previous population
	for( ; i < NUM_COPIED_BEST_PARRENTS; i++)
		m_new_population[i] = m_population[i];

	// Recombinations
	for( ; i < NEW_POPULATION_SIZE; i++)
	{
		int first = rand() % POPULATION_SIZE;
		int second = rand() % POPULATION_SIZE;
		int where = rand() % m_n;

		m_new_population[i].things = m_population[first].things;
		for(j = where; j < m_n; j++)
			m_new_population[i].things[j] = m_population[second].things[j];

		// Recalculate weight and cost
		m_new_population[i].weight = 0;
		m_new_population[i].cost = 0;
		for(j = 0; j < m_n; j++)
		{
			if(m_new_population[i].things[j])
			{
				m_new_population[i].weight += m_things[j].weight;
				m_new_population[i].cost += m_things[j].cost;
			}
		}
	}

	// Mutations
	for(int i = 0; i < NUM_MUTATIONS_IN_POPULATION; i++)
		Mutation(m_new_population[rand() % NEW_POPULATION_SIZE]);

	// Selection
	sort(m_new_population, m_new_population+NEW_POPULATION_SIZE, CompareChromosomes);

	i = 0;
	j = 0;

	while(i < POPULATION_SIZE && j < NEW_POPULATION_SIZE)
	{
		if(m_new_population[j].weight < m_M)
		{
			m_population[i] = m_new_population[j];
			i++;
		}

		j++;
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void CKnapsack::SolveKnapsack()
{
	for(int i = 0; i < NUM_SEPARATE_RUNS; i++)
	{
		cout << "------------------- Run #" << i << " -------------------" << endl;

		InitializePopulation();

		while(m_num_populations - m_last_best_change < STOP_BEST_NOT_CHANGED)
		{
			cout << "New population:\t\tp " << m_num_populations
				<< ",\tw " << m_cur_best.weight
				<< ",\tc " << m_cur_best.cost << endl;

			Reproduction();
			CheckBest();

			m_num_populations++;

			// gnuplot
//			cout << m_num_populations << " " << m_cur_best.cost << endl;
		}

		if(m_cur_best.cost > m_best.cost)
		{
			m_best = m_cur_best;

			cout << "Best changed:\t\tp " << m_num_populations
				<< ",\tw " << m_best.weight
				<< ",\tc " << m_best.cost << endl;
		}

		// gnuplot
//		m_num_populations = 0;

		m_cur_best.things = 0;
		m_cur_best.weight = 0;
		m_cur_best.cost = 0;
		m_last_best_change = m_num_populations;
	}

	cout << "SOLUTION:\t\tp " << m_num_populations
		<< ",\tw " << m_best.weight
		<< ",\tc " << m_best.cost << endl;
}


/////////////////////////////////////////////////////////////////////////////
////

void CKnapsack::CheckBest(void)
{
	for(int i = 0; i < POPULATION_SIZE; i++)
	{
		if(m_population[i].weight < m_M
			&& m_population[i].cost > m_cur_best.cost)
		{
			m_cur_best = m_population[i];
			m_last_best_change = m_num_populations;

			cout << "Current best changed:\tp " << m_num_populations
				<< ",\tw " << m_cur_best.weight
				<< ",\tc " << m_cur_best.cost << endl;

			// First valid is the best (sort in Reproduction())
			break;
		}
	}
}
