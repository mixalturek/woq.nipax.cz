/***************************************************************************
 *   Knapsack problem #5 - genetic algorihms                               *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <cassert>
#include <iostream>
#include <vector>
#include <bitset>

#define MAX_THINGS			64

#define NUM_SEPARATE_RUNS		5
#define STOP_BEST_NOT_CHANGED		50
#define NUM_COPIED_BEST_PARRENTS	3
#define POPULATION_SIZE			20
#define NEW_POPULATION_SIZE		500
#define NUM_MUTATIONS_IN_POPULATION	5

using namespace std;


/////////////////////////////////////////////////////////////////////////////
//// Data structures

struct THING
{
	int weight;
	int cost;

	THING(int w, int c) : weight(w), cost(c) { }
};

struct CHROMOSOME
{
	bitset<MAX_THINGS> things;
	int weight;
	int cost;

	CHROMOSOME() : things(0), weight(0), cost(0) { }
};


/////////////////////////////////////////////////////////////////////////////
//// Solves knapsack problem

class CKnapsack
{
public:
	CKnapsack(int ID, int n, int M, vector<THING>& data);
	~CKnapsack();
	void SolveKnapsack();

private:
	void InitializePopulation();
	void CheckBest(void);
	void Mutation(CHROMOSOME& ch);
	void Reproduction(void);

private:
	// Problem configuration
	int m_ID;
	int m_n;
	int m_M;
	vector<THING> m_things;

	// Current and temporary population and known best solution
	CHROMOSOME* m_population;
	CHROMOSOME* m_new_population;
	CHROMOSOME m_cur_best;
	CHROMOSOME m_best;

	// Populations counter and population number
	// when best known solution last changed (stop condition)
	int m_num_populations;
	int m_last_best_change;
};

