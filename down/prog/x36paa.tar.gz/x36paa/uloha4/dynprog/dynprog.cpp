/***************************************************************************
 *   Knapsack problem #3 - dynamic programming                             *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <bitset>

#define MAX_THINGS 64

using namespace std;


/////////////////////////////////////////////////////////////////////////////
//// Data structures

struct THING
{
	int weight;
	int cost;

	THING(int w, int c) : weight(w), cost(c) { }
};

struct DATA
{
	int weight;
	int cost;
	bitset<MAX_THINGS> things;
};


/////////////////////////////////////////////////////////////////////////////
//// Solves knapsack problem using dynamic programming

#define ACT_THING	data[j-1]
#define ACT		table[i*(n+1) + j]
#define LEFT		table[i*(n+1) + j-1]
#define DOWN		table[(i - ACT_THING.weight)*(n+1) + j-1]


int Knapsack(int ID, int n, int M, vector<THING>& data)
{
	DATA* table = new DATA[(n+1)*(M+1)];
	int ret = 0;

	// Initialize first row and column
	for(int i = 0; i <= n; i++)
	{
		table[i].cost = 0;
		table[i].weight = 0;
		table[i].things = 0;
		ret++;
	}

	for(int i = 0; i <= M; i++)
	{
		table[i*(n+1)].cost = 0;
		table[i*(n+1)].weight = 0;
		table[i*(n+1)].things = 0;
		ret++;
	}

	// Calculate table items
	for(int i = 1; i <= M; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			if(ACT_THING.weight > i)
			{
				ACT.cost = LEFT.cost;
				ACT.weight = LEFT.weight;
				ACT.things = LEFT.things;
			}
			else
			{
				if(LEFT.cost > DOWN.cost + ACT_THING.cost)
				{
					ACT.cost = LEFT.cost;
					ACT.weight = LEFT.weight;
					ACT.things = LEFT.things;
				}
				else
				{
					ACT.cost = DOWN.cost + ACT_THING.cost;
					ACT.weight = DOWN.weight + ACT_THING.weight;
					ACT.things = DOWN.things;
					ACT.things[j-1] = true;
				}
			}

			ret++;
		}
	}

/*	// Display solution
	int index = M*(n + 1) + n;
	cout << ID << " " << n << " "  << table[index].cost << " ";

	for(int i = 0; i < n; i++)
		cout << " " << table[index].things[i];

	cout << endl;
*/
	return ret;
}


/////////////////////////////////////////////////////////////////////////////
//// Enter to the program

int main(int argc, char* argv[])
{
	if(argc < 2)
	{
		cerr << "Usage: " << argv[0] << " <filename>" << endl;
		return 1;
	}

	ifstream is(argv[1]);
	if(!is.is_open())
	{
		cerr << "Couldn't open input file: " << argv[1] << endl;
		return 1;
	}

	int ID = 0;
	int n = 0;
	int M = 0;
	vector<THING> data;

	int sum = 0;
	int count = 0;

	while(is.good())
	{
		is >> ID;
		is >> n;
		is >> M;

		// Empty line at the end of the file
		if(!is.good())
			break;

		for(int i = 0; i < n; i++)
		{
			int weight, cost;
			is >> weight;
			is >> cost;

			data.push_back(THING(weight, cost));
		}

		count++;
		sum += Knapsack(ID, n, M, data);

		data.clear();
	}

	cout << (sum/count) << endl;

	is.close();
	return 0;
}
