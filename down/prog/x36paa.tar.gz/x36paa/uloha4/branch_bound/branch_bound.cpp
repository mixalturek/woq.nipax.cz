/***************************************************************************
 *   Knapsack problem #3 - branch & bound method                           *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>

#define MAX_THINGS 40

using namespace std;


/////////////////////////////////////////////////////////////////////////////
//// Data structures

struct THING
{
	int weight;
	int cost;

	THING(int w, int c) : weight(w), cost(c) { }
};


/////////////////////////////////////////////////////////////////////////////
//// Solves knapsack problem using branch & bound method

class CKnapsack
{
public:
	CKnapsack(int ID, int n, int M, vector<THING>& data)
		:
		m_ID(ID),
		m_n(n),
		m_M(M),
		m_data(data),
		m_remcost(n),
		m_rescost(0),
		m_resthings(0),
		m_count(0)
	{
		m_remcost[m_n - 1] = m_data[m_n - 1].cost;

		for(int i = m_n - 2; i >= 0; i--)
			m_remcost[i] = m_remcost[i + 1] + m_data[i].cost;
	}

	~CKnapsack()
	{

	}

	void SolveKnapsack(int index = 0, int cost = 0, int weight = 0, bitset<MAX_THINGS> things = 0)
	{
		// End of recursion
		if(index >= m_n)
			return;

		m_count++;

		// Actual thing won't be there
		if(cost + m_remcost[index] > m_rescost)
			SolveKnapsack(index + 1, cost, weight, things);

		// Actual thing will be there
		if(weight + m_data[index].weight <= m_M)
		{
			if(cost + m_remcost[index] > m_rescost)
			{
				// Update the best solution
				if(cost + m_data[index].cost > m_rescost)
				{
					m_rescost = cost + m_data[index].cost;
					things[index] = true;
					m_resthings = things;
				}

				things[index] = true;

				SolveKnapsack(index + 1,
					cost + m_data[index].cost,
					weight + m_data[index].weight,
					things);
			}
		}
	}

	void PrintResult()
	{
		cout << m_ID << " " << m_n << " " << m_rescost << " ";

		for(int i = 0; i < m_n; i++)
			cout << " " << m_resthings[i];

		cout << endl;
	}

	int GetCount(void) const { return m_count; }

private:
	int m_ID;		// Problem configuration
	int m_n;
	int m_M;
	vector<THING> m_data;

	vector<int> m_remcost;		// Remaining costs
	int m_rescost;			// Result cost
	bitset<MAX_THINGS> m_resthings;	// Result

	int m_count;
};


/////////////////////////////////////////////////////////////////////////////
//// Enter to the program

int main(int argc, char* argv[])
{
	if(argc < 2)
	{
		cerr << "Usage: " << argv[0] << " <filename>" << endl;
		return 1;
	}

	ifstream is(argv[1]);
	if(!is.is_open())
	{
		cerr << "Couldn't open input file: " << argv[1] << endl;
		return 1;
	}

	int ID = 0;
	int n = 0;
	int M = 0;
	vector<THING> data;

	int sum = 0;
	int count = 0;

	while(is.good())
	{
		is >> ID;
		is >> n;
		is >> M;

		// Empty line at the end of the file
		if(!is.good())
			break;

		for(int i = 0; i < n; i++)
		{
			int weight, cost;
			is >> weight;
			is >> cost;

			data.push_back(THING(weight, cost));
		}

		CKnapsack knap(ID, n, M, data);
		knap.SolveKnapsack();
//		knap.PrintResult();

		count++;
		sum += knap.GetCount();

		data.clear();
	}

	cout << (sum/count) << endl;

	is.close();
	return 0;
}
