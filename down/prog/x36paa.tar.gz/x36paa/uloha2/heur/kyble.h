/******************************************/
/* KYBLE V1.0       PAA  1999     kyble.h */
/* Reseni zobecneneho problemu dvou kyblu */
/* Copyright (c) 1999 by KP CVUT-FEL      */
/******************************************/

#ifndef kyble_h
#define kyble_h

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAXBCKTS 10            /* compile-time max. pocet kyblu */
#define min(x,y) (x<y)?x:y     /* makro */


/* Control prints */
// #define DEBUG

/* Control prints - operations */
//#define DEBUGO

/* Control prints - queue */
//#define DEBUGQ

/* Pri preteceni fronty program skonci */
#define HARDERR

#define MAXVERTEX 100000  /* max. pocet uzlu grafu stav. prostoru */
#define MAXQUEUE  30000   /* max. pocet rozpracovanych uzlu */
#define MAXBUCKET 5       /* run-time max. pocet kyblu */


typedef struct vertex
{
	unsigned oper;              /* provadena operace */
	unsigned which1, which2;    /* kyble, se kterymi se pracovalo */
	unsigned bucket[MAXBCKTS];  /* aktualni stav kyblu */
	unsigned backptr;           /* kudy vedla cesta do tohoto uzlu */
	unsigned count;             /* vzdalenost od pocatecniho stavu (pocet operaci) */
	unsigned hits;              /* pocet navstiveni daneho uzlu */

	unsigned int priority;      // Cim nizsi cislo, tim vyssi priorita
	bool closed;                // Uz byl uzavren?
} vertex;


void set_final_buckets(void);
void set_full_buckets(void);
void putvertex(unsigned b);
unsigned set_initial_buckets(void);
unsigned isempty(unsigned b, unsigned which);
unsigned isfull(unsigned b, unsigned which);
unsigned empty(unsigned bk, unsigned which);
unsigned fill(unsigned bk, unsigned which);
unsigned pour(unsigned bk, unsigned which1, unsigned which2);
unsigned check(unsigned b);
unsigned initcheck(unsigned b);
unsigned compare(unsigned b, unsigned bk);
void assign_rewrite(FILE **F, const char *Name);
void enqueue(unsigned b);
unsigned dequeue(void);
void save(unsigned temp, unsigned prev);
void search(void);
void dump_vertices(void);
void save_vertices(void);
int main(void);

void ComputePriority(unsigned int state);

#endif
