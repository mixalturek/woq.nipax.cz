/***************************************************************************
 *   Bucket problem - heuristic                                            *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 ***************************************************************************/


#include "kyble.h"

extern unsigned full_buckets[MAXBCKTS];   /* objem jednotl. kyblu */
extern unsigned final_buckets[MAXBCKTS];  /* koncovy stav */
extern vertex vertices[MAXVERTEX];        /* souvisly seznam uzlu */
extern unsigned ffree;                    /* ukazatel na prvni volne misto v poli uzlu */
extern unsigned queue[MAXQUEUE];          /* fronta rozpracovanych uzlu */
extern unsigned qcnt;                     /* pocet prvku ve fronte */
extern unsigned first,last;               /* prvni, posledni prvek fronty */
extern FILE* trace;                       /* ulozeni prubehu vypoctu */
extern FILE* fv;                          /* ulozeni reseni */
// struct time t;                         /* cas vypoctu */
extern struct tm * t_m;
extern time_t t;

#define MAXSIZE 20
// Flagy navstivenych uzlu
bool g_visited[MAXSIZE][MAXSIZE][MAXSIZE][MAXSIZE][MAXSIZE];


// Suma objemu vsech kyblu
unsigned int g_sum_of_sizes = 0;


void set_full_buckets(void)
{
	full_buckets[0]=14;
	full_buckets[1]=10;
	full_buckets[2]=12;
	full_buckets[3]=3;
	full_buckets[4]=8;
	full_buckets[5]=3;// Unused
	full_buckets[6]=3;
	full_buckets[7]=3;
	full_buckets[8]=3;
	full_buckets[9]=3; /* */
}

unsigned set_initial_buckets(void)
{
	unsigned b=1;
	ffree=1;			/* pro jistotu */
	(vertices+b)->backptr=0;	/* pocatecni stav nema predchudce */
	(vertices+b)->bucket[0]=0;
	(vertices+b)->bucket[1]=0;
	(vertices+b)->bucket[2]=0;
	(vertices+b)->bucket[3]=0;
	(vertices+b)->bucket[4]=0;
	(vertices+b)->bucket[5]=0;// Unused
	(vertices+b)->bucket[6]=0;
	(vertices+b)->bucket[7]=0;
	(vertices+b)->bucket[8]=0;
	(vertices+b)->bucket[9]=0; /* */
	putvertex(0);

	ComputePriority(1);
	return b;
}

void set_final_buckets(void)
{
	final_buckets[0]=7;
	final_buckets[1]=0;
	final_buckets[2]=7;
	final_buckets[3]=0;
	final_buckets[4]=7;
	final_buckets[5]=3;// Unused
	final_buckets[6]=3;
	final_buckets[7]=3;
	final_buckets[8]=3;
	final_buckets[9]=3; /* */

	for(int i = 0; i < MAXBUCKET; i++)
		g_sum_of_sizes += final_buckets[i];

//	printf("%d\n", g_sum_of_sizes);
//	getchar();
}


void ComputePriority(unsigned int state)
{
	unsigned sum_of_sizes = 0;
	for(int i = 0; i < MAXBUCKET; i++)
		sum_of_sizes += (vertices+state)->bucket[i];

	(vertices+state)->priority = abs(g_sum_of_sizes - sum_of_sizes);
	(vertices+state)->closed = false;

//	printf("%d - %d = %d\n", g_sum_of_sizes, sum_of_sizes, (vertices+newstate)->priority);
//	getchar();
}


unsigned int GetNextVertex()
{
	unsigned int min = (unsigned int)-1;
	unsigned int ret = 0;

	// Hleda uzel s maximalni prioritou (min. rozdil objemu)
	for(int i = 1; i < ffree; i++)
	{
		if(!(vertices+i)->closed)
		{
			if((vertices+i)->priority < min)
			{
				min = (vertices+i)->priority;
				ret = i;
			}

//			printf("%d ", (vertices+i)->priority);
		}
	}

//	printf("\n*** %d ***\n", (vertices+ret)->priority);
//	getchar();

	// Zavre uzel, priste se uz nebude brat v uvahu
	(vertices+ret)->closed = true;

	return ret;
}


void InsertToQueue(unsigned int newstate, unsigned int laststate)
{
	vertex* v = vertices+newstate;
	if(g_visited[v->bucket[0]][v->bucket[1]][v->bucket[2]][v->bucket[3]][v->bucket[4]] != true)
	{
		g_visited[v->bucket[0]][v->bucket[1]][v->bucket[2]][v->bucket[3]][v->bucket[4]] = true;

		putvertex(newstate);

		// Nastavi predchudce uzlu pro backtracking
		(vertices+newstate)->backptr = laststate;

		// Vypocet priority uzlu
		ComputePriority(newstate);
	}
}


/* Reseni problemu kyblu Vasi heuristikou */
void search(void)
{
	// Zadny stav jeste nebyl navstiven
	for(int i = 0; i < MAXSIZE; i++)
		for(int j = 0; j < MAXSIZE; j++)
			for(int k = 0; k < MAXSIZE; k++)
				for(int l = 0; l < MAXSIZE; l++)
					for(int m = 0; m < MAXSIZE; m++)
						g_visited[i][j][k][l][m] = false;


	unsigned int state, newstate;

	// Postupne prochazi vsechny uzly, poradi podle jejich priority
	while(state = GetNextVertex())
	{
		// Nalezeno reseni problemu?
		if(check(state))
		{
			printf("NALEZENO RESENI: %d\n", state);
			fprintf(trace, "NALEZENO RESENI: %d\n", state);

			save(state, (vertices+state)->backptr);
			break;
		}

		// Naplneni
		for(int i = 0; i < MAXBUCKET; i++)
			if(!isfull(state, i))
				InsertToQueue(fill(state, i), state);

		// Vyprazdneni
		for(int i = 0; i < MAXBUCKET; i++)
			if(!isempty(state, i))
				InsertToQueue(empty(state, i), state);

		// Preliti
		for(int i = 0; i < MAXBUCKET; i++)
			for(int j = 0; j < MAXBUCKET; j++)
				if(i != j && !isempty(state, i) && !isfull(state, j))
					InsertToQueue(pour(state, i, j), state);
	}

	printf("SEARCH: DONE\n");
	fprintf(trace,"SEARCH: DONE\n");
}
