/***************************************************************************
 *   Knapsack problem #1 - cost/weight heuristic                           *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;


struct THING
{
	int weight;
	int cost;
	int order;// For sorting to the original order
	bool used;

	THING(int w, int c, int o, int u) : weight(w), cost(c), order(o), used(u) { }
};


/////////////////////////////////////////////////////////////////////////////
//// Temporary compare methods for sorting

bool SortCostWeight(const THING& t1, const THING& t2)
{
	return ((float)t1.cost / t1.weight) > ((float)t2.cost / t2.weight);
}

bool SortOrder(const THING& t1, const THING& t2)
{
	return t1.order < t2.order;
}


/////////////////////////////////////////////////////////////////////////////
//// Solves knapsack problem

void Knapsack(int ID, int n, int M, vector<THING>& data)
{
	sort(data.begin(), data.end(), SortCostWeight);

	int cost = 0;
	int weight = 0;

	vector<THING>::iterator it;
	for(it = data.begin(); it != data.end(); it++)
	{
		if(weight + it->weight < M)
		{
			weight += it->weight;
			cost += it->cost;
			it->used = true;
		}
	}

	sort(data.begin(), data.end(), SortOrder);

	cout << ID << " " << n << " " << cost << " ";

	for(it = data.begin(); it != data.end(); it++)
		cout << " " << it->used;

	cout << endl;
}


/////////////////////////////////////////////////////////////////////////////
//// Enter to program

int main(int argc, char* argv[])
{
	if(argc < 2)
	{
		cerr << "Usage: " << argv[0] << " <filename>" << endl;
		return 1;
	}

	ifstream is(argv[1]);
	if(!is.is_open())
	{
		cerr << "Couldn't open input file: " << argv[1] << endl;
		return 1;
	}

	int ID = 0;
	int n = 0;
	int M = 0;
	vector<THING> data;

	while(is.good())
	{
		is >> ID;
		is >> n;
		is >> M;

		// Empty line at the end of file
		if(!is.good())
			break;

		for(int i = 0; i < n; i++)
		{
			int weight, cost;
			is >> weight;
			is >> cost;

			data.push_back(THING(weight, cost, i, false));
		}

//		for(int i = 0; i < 1000; i++)
			Knapsack(ID, n, M, data);


		data.clear();
	}

	is.close();
	return 0;
}
