/***************************************************************************
 *   Knapsack problem #1 - brute force                                     *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <cassert>

using namespace std;

// Aliases for std::pair members
#define WEIGHT first
#define COST second


/////////////////////////////////////////////////////////////////////////////
//// Generate binary representation of number

vector<bool> ToBinary(unsigned int number, int num_bin_digits)
{
	// Integer variable has 32 bit
	assert(num_bin_digits <= 32);

	unsigned int mask = 1;
	vector<bool> ret;

	for(int i = 0; i < num_bin_digits; i++)
	{
		ret.push_back(number & mask);
		mask <<= 1;
	}

	reverse(ret.begin(), ret.end());
	return ret;
}


/////////////////////////////////////////////////////////////////////////////
//// Solves knapsack problem

void Knapsack(int ID, int n, int M, vector<pair<int, int> >& data)
{
	int max_cost = -1;
	vector<bool> max_things;

	unsigned int num = (int)pow(2.0f, n);

	// All combinations
	for(unsigned int i = 0; i < num; i++)
	{
		vector<bool> things = ToBinary(i, n);
		int sum_weight = 0;
		int sum_cost = 0;

		for(int j = 0; j < n; j++)
		{
			sum_weight += data[j].WEIGHT * things[j];
			sum_cost += data[j].COST * things[j];
		}

		if(sum_weight <= M && max_cost < sum_cost)
		{
			max_cost = sum_cost;
			max_things = things;
		}
	}


	cout << ID << " " << n << " " << max_cost << " ";

	vector<bool>::const_iterator it;
	for(it = max_things.begin(); it != max_things.end(); it++)
		cout << " " << *it;

	cout << endl;
}


/////////////////////////////////////////////////////////////////////////////
//// Enter to program

int main(int argc, char* argv[])
{
	if(argc < 2)
	{
		cerr << "Usage: " << argv[0] << " <filename>" << endl;
		return 1;
	}

	ifstream is(argv[1]);
	if(!is.is_open())
	{
		cerr << "Couldn't open input file: " << argv[1] << endl;
		return 1;
	}

	int ID = 0;
	int n = 0;
	int M = 0;
	vector<pair<int, int> > data;

	while(is.good())
	{
		is >> ID;
		is >> n;
		is >> M;

		// Empty line at the end of file
		if(!is.good())
			break;

		for(int i = 0; i < n; i++)
		{
			int weight, cost;
			is >> weight;
			is >> cost;

			data.push_back(pair<int, int>(weight, cost));
		}

//		for(int i = 0; i < 10; i++)
			Knapsack(ID, n, M, data);


		data.clear();
	}

	is.close();
	return 0;
}
