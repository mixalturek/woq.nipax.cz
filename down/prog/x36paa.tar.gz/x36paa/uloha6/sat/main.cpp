/***************************************************************************
 *   SAT problem #6 - genetic algorihms                                    *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <ctime>
#include <fstream>
#include "csattest.hpp"


/////////////////////////////////////////////////////////////////////////////
//// Enter to the program

int main(int argc, char* argv[])
{
/*	if(argc < 2)
	{
		cerr << "Usage: " << argv[0] << " <filename>" << endl;
		return 1;
	}

	srand(time(NULL));

	Csat sat;
	if(!sat.LoadFromFile(argv[1]))
		return 1;

	for(int i = 0; i < 50; i++)
	{
		sat.SetupGenetic();
		sat.RunGA();

		if(sat.SolutionFound())
			cout << "Solution is " << sat.GetBestValue() << endl;
		else
			cout << "Solution was not found." << endl;
	}
*/

	if(argc < 2)
	{
		cerr << "Usage: " << argv[0] << " <directory>" << endl;
		return 1;
	}

	srand(time(NULL));

	try
	{
		CsatTest sat;
		sat.Run(argv[1]);
	}
	catch(runtime_error& ex)
	{
		cerr << ex.what() << endl;
		return 1;
	}
	catch(...)
	{
		cerr << "Unknown exception occured, terminating application." << endl;
		return 1;
	}

	return 0;
}
