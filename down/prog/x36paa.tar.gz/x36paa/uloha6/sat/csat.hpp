/***************************************************************************
 *   SAT problem #6 - genetic algorihms                                    *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <cassert>
#include <iostream>
#include <vector>
#include <bitset>
#include <stdexcept>

// The variable weights will be randomly generated from 0 to MAX_WEIGHT
#define MAX_WEIGHT	100

// For bitset<>
#define MAX_VARIABLES	64

using namespace std;


/////////////////////////////////////////////////////////////////////////////
//// Solves SAT problem

struct CHROMOSOME
{
	bitset<MAX_VARIABLES> vars;
	int rating;
};


class Csat
{
public:
	Csat();
	~Csat();

	void LoadFromFile(const string& filename);
	void PrintConfiguration(void) const;

	bool IsSatisfied(const CHROMOSOME& chrom) const;
	int Fitness(CHROMOSOME& chrom);
	int EvaluateSolution(const CHROMOSOME& chrom) const;

	void RunGA(void);
	void RenewPopulation(void);
	void Generate(CHROMOSOME& chrom);
	int EvaluatePopulation(void);
	void Mutate(CHROMOSOME& chrom);
	void Crossover(CHROMOSOME& chrom1, CHROMOSOME& chrom2);
	int Tournament(void) const;
	pair<int, int> BestChromosomes(void) const;

	bool SolutionFound(void) const { return m_best_found; }
	int GetBestValue(void) const { return m_best.rating; }

	void SetupGenetic(void);
	void TryImproveSolution(CHROMOSOME& chrom);
	void SaveSolution(const CHROMOSOME& chrom);


protected:
	string m_filename;

	// Problem configuration
	int m_num_vars;
	int m_num_clauses;
	vector< vector<int> > m_clauses;
	vector<int> m_weights;// Indexed from 1!

	// Genetic configuration
	int m_clause_bonus;
	int m_formula_bonus;
	int m_num_generations;
	int m_population_size;
	int m_tournament_size;
	double m_cross_probability;
	double m_mutation_probability;
	bool m_try_improve_solution;

	// Other
	bool m_best_found;
	CHROMOSOME m_best;
	CHROMOSOME* m_population;
	CHROMOSOME* m_new_population;
};

