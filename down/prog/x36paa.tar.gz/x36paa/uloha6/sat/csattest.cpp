/***************************************************************************
 *   SAT problem #6 - genetic algorihms                                    *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <dirent.h>
#include <sstream>

#include "csattest.hpp"


/////////////////////////////////////////////////////////////////////////////
//// Constructor

CsatTest::CsatTest()
	:
	Csat()
{

}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

CsatTest::~CsatTest()
{

}


/////////////////////////////////////////////////////////////////////////////
////

string ToString(int num)
{
	ostringstream s;
	s << num;
	return s.str();
}

string ToString(double num)
{
	ostringstream s;
	s << num;
	return s.str();
}


/////////////////////////////////////////////////////////////////////////////
////

bool CsatTest::IsCnf(const string& filename) const
{
	int pos = filename.rfind('.');
	string ext = filename.substr(pos+1, filename.length()-pos-1);

	if(ext == "cnf")
		return true;

	return false;
}

vector<string> CsatTest::ListDirectory(string dirname) const
{
	vector<string> ret;
	DIR* handle = NULL;
	dirent* entry = NULL;

	if(dirname[dirname.length()-1] != '/')
		dirname += string("/");

	handle = opendir(dirname.c_str());
	if(handle == NULL)
		throw runtime_error("Couldn't open directory: " + dirname);

	while((entry = readdir(handle)) != NULL)
	{
		if(IsCnf(entry->d_name))
			ret.push_back(dirname + entry->d_name);
	}

	closedir(handle);
	sort(ret.begin(), ret.end());

	return ret;
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::Run(const string& dirname)
{
	vector<string> filenames = ListDirectory(dirname);

	cout << "Uncomment tests in the CsatTest::Run()." << endl;

//	RunNumSatisfied(filenames);
//	RunPopulationQualityInGeneration(filenames);
//	RunDisableTryImproveSolution(filenames);
//	RunPopulationSize(filenames);
//	RunPopulationSize1(filenames);
//	RunMutationAVG(filenames);
//	RunMutation(filenames);
//	RunCrossoverAVG(filenames);
//	RunCrossover(filenames);
//	RunTournamentAVG(filenames);
//	RunTournament(filenames);
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunNumSatisfied(const vector<string>& filenames)
{
	int num = 0;

	ofstream os("../graphs/num_satisfied.dat");
	if(!os.is_open())
		throw runtime_error("Couldn't open output file.");


	for(int clauses = 91; clauses >= 40; clauses--)
	{
		cout << clauses << " ----------------------------------------------" << endl;
		num = 0;

		for(int i = 0; i < (int)filenames.size(); i++)
		{
			cout << filenames[i] << endl;
			LoadFromFile(filenames[i]);

			SetupGenetic();
			m_num_clauses = clauses;
			m_try_improve_solution = false;// Staci jakykoli, zbytecne zpomaluje

			RunGA();
			if(SolutionFound())
				num++;
		}

		os << clauses << "\t" << num << endl;
	}


	os.close();
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunPopulationQualityInGeneration(const vector<string>& filenames)
{
	ofstream os("../graphs/pop_qual_in_gen.dat");
	if(!os.is_open())
		throw runtime_error("Couldn't open output file.");

	SetupGenetic();
	m_num_generations = 1000;
	vector<unsigned long> quality(m_num_generations);

	for(int i = 0; i < (int)filenames.size(); i++)
	{
		cout << filenames[i] << endl;
		LoadFromFile(filenames[i]);

		SetupGenetic();
		m_num_clauses = NUM_CLAUSES_FOR_TESTING;
		m_num_generations = 1000;

		// Content of Csat::RunGA()
		for(int i = 0; i < m_population_size; i++)
			Generate(m_population[i]);

		EvaluatePopulation();

		for(int i = 0; i < m_num_generations; i++)
		{
			RenewPopulation();
			quality[i] += EvaluatePopulation();
		}
		// Content of Csat::RunGA()
	}

	for(int i = 0; i < (int)quality.size(); i++)
		os << i << "\t" << (quality[i] / filenames.size()) << endl;

	os.close();
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunDisableTryImproveSolution(const vector<string>& filenames)
{
	ofstream os("../graphs/try_improve_solution_true3.dat");
	if(!os.is_open())
		throw runtime_error("Couldn't open output file.");

	SetupGenetic();
	m_num_generations = 5000;
	vector<unsigned long> quality(m_num_generations);

	for(int i = 0; i < (int)filenames.size(); i++)
	{
		cout << filenames[i] << endl;
		LoadFromFile(filenames[i]);

		SetupGenetic();
		m_num_clauses = NUM_CLAUSES_FOR_TESTING;
		m_num_generations = 5000;
		m_try_improve_solution = true;

		// Content of Csat::RunGA()
		for(int i = 0; i < m_population_size; i++)
			Generate(m_population[i]);

		EvaluatePopulation();

		for(int i = 0; i < m_num_generations; i++)
		{
			RenewPopulation();
			quality[i] += EvaluatePopulation();
		}
		// Content of Csat::RunGA()
	}

	for(int i = 0; i < (int)quality.size(); i++)
		os << i << "\t" << (quality[i] / filenames.size()) << endl;

	os.close();
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunPopulationSize(const vector<string>& filenames)
{
	// V Csat::Csat() je nutny alokovat dostatek pameti!!!
	int sizes[] = {16, 32, 64, 128, 256, 512};

	for(int index = 0; index < 6; index++)
	{
		cout << sizes[index] << " ----------------------------------------------" << endl;
		ofstream os(("../graphs/population_size_" + ToString(sizes[index]) + ".dat").c_str());
		if(!os.is_open())
			throw runtime_error("Couldn't open output file.");

		SetupGenetic();
		m_num_generations = 5000;
		vector<unsigned long> quality(m_num_generations);

		for(int i = 0; i < (int)filenames.size(); i++)
		{
			cout << filenames[i] << endl;
			LoadFromFile(filenames[i]);

			SetupGenetic();
			m_num_clauses = NUM_CLAUSES_FOR_TESTING;
			m_num_generations = 5000;
			m_try_improve_solution = false;
			m_population_size = sizes[index];

			// Content of Csat::RunGA()
			for(int i = 0; i < m_population_size; i++)
				Generate(m_population[i]);

			EvaluatePopulation();

			for(int i = 0; i < m_num_generations; i++)
			{
				RenewPopulation();
				quality[i] += EvaluatePopulation();
			}
			// Content of Csat::RunGA()
		}

		for(int i = 0; i < (int)quality.size(); i++)
			os << i << "\t" << (quality[i] / filenames.size()) << endl;

		os.close();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunPopulationSize1(const vector<string>& filenames)
{
	// V Csat::Csat() je nutny alokovat dostatek pameti!!!
	int sizes[] = {16, 32, 64, 100, 128, 256, 512};

	for(int index = 2; index < 7; index++)
	{
		cout << sizes[index] << " ----------------------------------------------" << endl;
		ofstream os(("../graphs/population_size2_" + ToString(sizes[index]) + ".dat").c_str());
		if(!os.is_open())
			throw runtime_error("Couldn't open output file.");

		SetupGenetic();
		m_num_generations = 5000;
		vector<unsigned long> quality(m_num_generations);

//		for(int i = 0; i < (int)filenames.size(); i++)
		int i = 0;
		{
			cout << filenames[i] << endl;
			LoadFromFile(filenames[i]);

			SetupGenetic();
			m_num_clauses = NUM_CLAUSES_FOR_TESTING;
			m_num_generations = 5000;
			m_try_improve_solution = false;
			m_population_size = sizes[index];

			// Content of Csat::RunGA()
			for(int i = 0; i < m_population_size; i++)
				Generate(m_population[i]);

			EvaluatePopulation();

			for(int i = 0; i < m_num_generations; i++)
			{
				RenewPopulation();
				quality[i] += EvaluatePopulation();
			}
			// Content of Csat::RunGA()
		}

		for(int i = 0; i < (int)quality.size(); i += 50)
			os << i << "\t" << quality[i] << endl;
//			os << i << "\t" << (quality[i] / filenames.size()) << endl;

		os.close();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunMutationAVG(const vector<string>& filenames)
{
	// V Csat::Csat() je nutny alokovat dostatek pameti!!!
	double probability[] = {0.005, 0.01, 0.02, 0.03, 0.04, 0.05, 0.1, 0.2};

	for(int index = 4; index < 5; index++)
	{
		cout << probability[index] << " ----------------------------------------------" << endl;
		ofstream os(("../graphs/mutation_avg_" + ToString(probability[index]) + ".dat").c_str());
		if(!os.is_open())
			throw runtime_error("Couldn't open output file.");

		SetupGenetic();
		m_num_generations = 5000;
		vector<unsigned long> quality(m_num_generations);

		for(int i = 0; i < (int)filenames.size(); i++)
//		int i = 0;
		{
			cout << filenames[i] << endl;
			LoadFromFile(filenames[i]);

			SetupGenetic();
			m_num_clauses = NUM_CLAUSES_FOR_TESTING;
			m_num_generations = 5000;
			m_try_improve_solution = false;
			m_population_size = 100;
			m_mutation_probability = probability[index];

			// Content of Csat::RunGA()
			for(int i = 0; i < m_population_size; i++)
				Generate(m_population[i]);

			EvaluatePopulation();

			for(int i = 0; i < m_num_generations; i++)
			{
				RenewPopulation();
				quality[i] += EvaluatePopulation();
			}
			// Content of Csat::RunGA()
		}

		for(int i = 0; i < (int)quality.size(); i += 50)
//			os << i << "\t" << quality[i] << endl;
			os << i << "\t" << (quality[i] / filenames.size()) << endl;

		os.close();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunMutation(const vector<string>& filenames)
{
	// V Csat::Csat() je nutny alokovat dostatek pameti!!!
	double probability[] = {0.005, 0.01, 0.02, 0.03, 0.05, 0.1, 0.2};

	for(int index = 0; index < 7; index++)
	{
		cout << probability[index] << " ----------------------------------------------" << endl;
		ofstream os(("../graphs/mutation_" + ToString(probability[index]) + ".dat").c_str());
		if(!os.is_open())
			throw runtime_error("Couldn't open output file.");

		SetupGenetic();
		m_num_generations = 5000;
		vector<unsigned long> quality(m_num_generations);

//		for(int i = 0; i < (int)filenames.size(); i++)
		int i = 0;
		{
			cout << filenames[i] << endl;
			LoadFromFile(filenames[i]);

			SetupGenetic();
			m_num_clauses = NUM_CLAUSES_FOR_TESTING;
			m_num_generations = 5000;
			m_try_improve_solution = false;
			m_population_size = 100;
			m_mutation_probability = probability[index];

			// Content of Csat::RunGA()
			for(int i = 0; i < m_population_size; i++)
				Generate(m_population[i]);

			EvaluatePopulation();

			for(int i = 0; i < m_num_generations; i++)
			{
				RenewPopulation();
				quality[i] += EvaluatePopulation();
			}
			// Content of Csat::RunGA()
		}

		for(int i = 0; i < (int)quality.size(); i += 50)
			os << i << "\t" << quality[i] << endl;
//			os << i << "\t" << (quality[i] / filenames.size()) << endl;

		os.close();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunCrossoverAVG(const vector<string>& filenames)
{
	// V Csat::Csat() je nutny alokovat dostatek pameti!!!
	double probability[] = {0.6, 0.8, 1.0};

	for(int index = 0; index < 3; index++)
	{
		cout << probability[index] << " ----------------------------------------------" << endl;
		ofstream os(("../graphs/crossover_avg_" + ToString(probability[index]) + ".dat").c_str());
		if(!os.is_open())
			throw runtime_error("Couldn't open output file.");

		SetupGenetic();
		m_num_generations = 5000;
		vector<unsigned long> quality(m_num_generations);

		for(int i = 0; i < (int)filenames.size(); i++)
		{
			cout << filenames[i] << endl;
			LoadFromFile(filenames[i]);

			SetupGenetic();
			m_num_clauses = NUM_CLAUSES_FOR_TESTING;
			m_num_generations = 5000;
			m_try_improve_solution = false;
			m_population_size = 100;
			m_cross_probability = probability[index];

			// Content of Csat::RunGA()
			for(int i = 0; i < m_population_size; i++)
				Generate(m_population[i]);

			EvaluatePopulation();

			for(int i = 0; i < m_num_generations; i++)
			{
				RenewPopulation();
				quality[i] += EvaluatePopulation();
			}
			// Content of Csat::RunGA()
		}

		for(int i = 0; i < (int)quality.size(); i += 50)
			os << i << "\t" << (quality[i] / filenames.size()) << endl;

		os.close();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunCrossover(const vector<string>& filenames)
{
	// V Csat::Csat() je nutny alokovat dostatek pameti!!!
	double probability[] = {0.6, 0.8, 1.0};

	for(int index = 0; index < 3; index++)
	{
		cout << probability[index] << " ----------------------------------------------" << endl;
		ofstream os(("../graphs/crossover_" + ToString(probability[index]) + ".dat").c_str());
		if(!os.is_open())
			throw runtime_error("Couldn't open output file.");

		SetupGenetic();
		m_num_generations = 5000;
		vector<unsigned long> quality(m_num_generations);

//		for(int i = 0; i < (int)filenames.size(); i++)
		int i = 0;
		{
			cout << filenames[i] << endl;
			LoadFromFile(filenames[i]);

			SetupGenetic();
			m_num_clauses = NUM_CLAUSES_FOR_TESTING;
			m_num_generations = 5000;
			m_try_improve_solution = false;
			m_population_size = 100;
			m_cross_probability = probability[index];

			// Content of Csat::RunGA()
			for(int i = 0; i < m_population_size; i++)
				Generate(m_population[i]);

			EvaluatePopulation();

			for(int i = 0; i < m_num_generations; i++)
			{
				RenewPopulation();
				quality[i] += EvaluatePopulation();
			}
			// Content of Csat::RunGA()
		}

		for(int i = 0; i < (int)quality.size(); i += 50)
			os << i << "\t" << quality[i] << endl;
//			os << i << "\t" << (quality[i] / filenames.size()) << endl;

		os.close();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunTournamentAVG(const vector<string>& filenames)
{
	// V Csat::Csat() je nutny alokovat dostatek pameti!!!
	int sizes[] = { 0, 1, 2, 3, 5, 10, 20, 40, 60 };

	for(int index = 0; index < 1; index++)
	{
		cout << sizes[index] << " ----------------------------------------------" << endl;
		ofstream os(("../graphs/tournament_avg_" + ToString(sizes[index]) + ".dat").c_str());
		if(!os.is_open())
			throw runtime_error("Couldn't open output file.");

		SetupGenetic();
		m_num_generations = 5000;
		vector<unsigned long> quality(m_num_generations);

		for(int i = 0; i < (int)filenames.size(); i++)
		{
			cout << filenames[i] << endl;
			LoadFromFile(filenames[i]);

			SetupGenetic();
			m_num_clauses = NUM_CLAUSES_FOR_TESTING;
			m_num_generations = 5000;
			m_try_improve_solution = false;
			m_population_size = 100;
			m_tournament_size = sizes[index];

			// Content of Csat::RunGA()
			for(int i = 0; i < m_population_size; i++)
				Generate(m_population[i]);

			EvaluatePopulation();

			for(int i = 0; i < m_num_generations; i++)
			{
				RenewPopulation();
				quality[i] += EvaluatePopulation();
			}
			// Content of Csat::RunGA()
		}

		for(int i = 0; i < (int)quality.size(); i += 50)
			os << i << "\t" << (quality[i] / filenames.size()) << endl;

		os.close();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void CsatTest::RunTournament(const vector<string>& filenames)
{
	// V Csat::Csat() je nutny alokovat dostatek pameti!!!
	int sizes[] = { 1, 5, 10, 20, 40, 60 };

	for(int index = 0; index < 6; index++)
	{
		cout << sizes[index] << " ----------------------------------------------" << endl;
		ofstream os(("../graphs/tournament_" + ToString(sizes[index]) + ".dat").c_str());
		if(!os.is_open())
			throw runtime_error("Couldn't open output file.");

		SetupGenetic();
		m_num_generations = 5000;
		vector<unsigned long> quality(m_num_generations);

//		for(int i = 0; i < (int)filenames.size(); i++)
		int i = 0;
		{
			cout << filenames[i] << endl;
			LoadFromFile(filenames[i]);

			SetupGenetic();
			m_num_clauses = NUM_CLAUSES_FOR_TESTING;
			m_num_generations = 5000;
			m_try_improve_solution = false;
			m_population_size = 100;
			m_tournament_size = sizes[index];

			// Content of Csat::RunGA()
			for(int i = 0; i < m_population_size; i++)
				Generate(m_population[i]);

			EvaluatePopulation();

			for(int i = 0; i < m_num_generations; i++)
			{
				RenewPopulation();
				quality[i] += EvaluatePopulation();
			}
			// Content of Csat::RunGA()
		}

		for(int i = 0; i < (int)quality.size(); i += 50)
			os << i << "\t" << quality[i] << endl;
//			os << i << "\t" << (quality[i] / filenames.size()) << endl;

		os.close();
	}
}
