/***************************************************************************
 *   SAT problem #6 - genetic algorihms                                    *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "csat.hpp"

#include <fstream>


/////////////////////////////////////////////////////////////////////////////
//// Constructor

Csat::Csat()
	:
	m_filename(""),
	m_num_vars(0),
	m_num_clauses(0),
	m_population(NULL),
	m_new_population(NULL)
{
	SetupGenetic();

	m_population = new CHROMOSOME[m_population_size];
	m_new_population = new CHROMOSOME[m_population_size];

	// Temporary for tests
//	m_population = new CHROMOSOME[512];
//	m_new_population = new CHROMOSOME[512];
}


void Csat::SetupGenetic(void)
{
	m_clause_bonus = 1000;
	m_formula_bonus = 20000;
	m_num_generations = 5000;
	m_population_size = 100;
	m_tournament_size = 5;
	m_cross_probability = 0.8;
	m_mutation_probability = 0.03;
	m_try_improve_solution = false;

	m_best_found = false;
	m_best.vars = 0;
	m_best.rating = 0;
}


/////////////////////////////////////////////////////////////////////////////
//// Destructor

Csat::~Csat()
{
	if(m_population != NULL)
		delete [] m_population;

	if(m_new_population != NULL)
		delete [] m_new_population;
}


/////////////////////////////////////////////////////////////////////////////
////

/*
An input file starts with comments (each line starts with c). The number of variables and the number of clauses is defined by the line p cnf variables clauses

Each of the next lines specifies a clause: a positive literal is denoted by the corresponding number, and a negative literal is denoted by the corresponding negative number. The last number in a line should be zero. For example,
c A sample .cnf file.
p cnf 3 2
1 -3 0
2 3 -1 0
*/


void Csat::LoadFromFile(const string& filename)
{
	ifstream is(filename.c_str());
	if(!is.is_open())
		throw runtime_error("Couldn't open input file: " + filename);

	m_filename = filename;

	string line;

	while(is.good())
	{
		getline(is, line);

		if(line[0] == 'c')
		{
			continue;
		}
		else if(line[0]=='p')
		{
			sscanf(line.c_str(), "p cnf %d %d", &m_num_vars, &m_num_clauses);
			assert(m_num_vars < MAX_VARIABLES);
			m_clauses.reserve(m_num_clauses);
			break;
		}
	}

	int number = 1;// Not zero
	vector<int> clause;

	for(int i = 0; i < m_num_clauses; i++)
	{
		clause.clear();

		while(true)
		{
			is >> number;

			if(number == 0)
				break;

			clause.push_back(number);
		}

		m_clauses.push_back(clause);
	}

	is.close();



	m_weights.reserve(m_num_vars+1);
	string filename_wgt = filename + ".wgt";

	is.open(filename_wgt.c_str());
	if(is.is_open())
	{
		for(int i = 0; i < m_num_vars; i++)
			is >> m_weights[i+1];

		is.close();
	}
	else
	{
		cerr << "Couldn't open input file: " << filename_wgt << endl;

		ofstream os(filename_wgt.c_str());
		if(!os.is_open())
			cerr << "Couldn't open output file: " << filename_wgt << endl;

		// Generate random weights
		for(int i = 0; i < m_num_vars; i++)
		{
			m_weights[i+1] = rand() % MAX_WEIGHT;
			os << m_weights[i+1] << " ";
		}

		os << endl;
		os.close();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void Csat::PrintConfiguration(void) const
{
	cout << "p cnf " << m_num_vars << " " << m_num_clauses << endl;

	for(int i = 0; i < m_num_clauses; i++)
	{
		for(int j = 0; j < (int)m_clauses[i].size(); j++)
			cout << m_clauses[i][j] << " ";

		cout << "0" << endl;
	}


	cout << "Weights: ";
	for(int i = 0; i < m_num_vars; i++)
		cout << m_weights[i+1] << " ";
	cout << endl;
}


/////////////////////////////////////////////////////////////////////////////
////

bool Csat::IsSatisfied(const CHROMOSOME& chrom) const
{
	for(int i = 0; i < m_num_clauses; i++)
	{
		bool clause_ok = false;

		for(int j = 0; j < (int)m_clauses[i].size(); j++)
		{
			int tmp = m_clauses[i][j];
			if(tmp < 0)
			{
				if(!chrom.vars[-tmp])
				{
					clause_ok = true;
					break;
				}
			}
			else
			{
				if(chrom.vars[tmp])
				{
					clause_ok = true;
					break;
				}
			}
		}

		if(!clause_ok)
			return false;
	}

	return true;
}


/////////////////////////////////////////////////////////////////////////////
////

int Csat::Fitness(CHROMOSOME& chrom)
{
	int sum = 0;
	int num_satisfied_clauses = 0;

	for(int i = 0; i < m_num_clauses; i++)
	{
		for(int j = 0; j < (int)m_clauses[i].size(); j++)
		{
			int tmp = m_clauses[i][j];
			if(tmp < 0)
			{
				if(!chrom.vars[-tmp])
				{
					num_satisfied_clauses++;
					break;
				}
			}
			else
			{
				if(chrom.vars[tmp])
				{
					num_satisfied_clauses++;
					break;
				}
			}
		}
	}

	sum += m_clause_bonus * num_satisfied_clauses;

	if(num_satisfied_clauses == m_num_clauses)
	{
		sum += m_formula_bonus;

//		cout << "S";// << endl;

		m_best_found = true;

		if(m_try_improve_solution)
			TryImproveSolution(chrom);

		int value = EvaluateSolution(chrom);
		if(m_best.rating < value)
		{
			m_best = chrom;
			m_best.rating = value;

			SaveSolution(m_best);
		}
	}


	for(int i = 0; i < m_num_vars; i++)
	{
		if(chrom.vars[i+1])
		 	sum += m_weights[i+1];
	}

	return sum;
}


/////////////////////////////////////////////////////////////////////////////
////

void Csat::RunGA(void)
{
	for(int i = 0; i < m_population_size; i++)
		Generate(m_population[i]);

	EvaluatePopulation();

	for(int i = 0; i < m_num_generations; i++)
	{
		RenewPopulation();
		EvaluatePopulation();
	}
}


/////////////////////////////////////////////////////////////////////////////
////

void Csat::Generate(CHROMOSOME& chrom)
{
	chrom.vars = 0;

	for(int i = 0; i < m_num_vars; i++)
		chrom.vars[i+1] = rand() % 2;
}


/////////////////////////////////////////////////////////////////////////////
////

int Csat::EvaluatePopulation(void)
{
	int sum = 0;
	for(int i = 0; i < m_population_size; i++)
	{
		m_population[i].rating = Fitness(m_population[i]);
		sum += m_population[i].rating;
	}

	return sum / m_population_size;
}


/////////////////////////////////////////////////////////////////////////////
////

void Csat::Mutate(CHROMOSOME& chrom)
{
	int pos = rand() % m_num_vars+1;
	chrom.vars[pos+1] = !chrom.vars[pos+1];
}


/////////////////////////////////////////////////////////////////////////////
////

void Csat::Crossover(CHROMOSOME& chrom1, CHROMOSOME& chrom2)
{
	CHROMOSOME tmp = chrom2;
	int pos = rand() % m_num_vars;

	for(int i = 0; i < pos; i++)
	{
		chrom2.vars[i+1] = chrom1.vars[i+1];
		chrom1.vars[i+1] = tmp.vars[i+1];
	}
}


/////////////////////////////////////////////////////////////////////////////
////

int Csat::Tournament(void) const
{
	int best = rand() % m_population_size;

	for(int i = 0; i < m_tournament_size; i++)
	{
		int candidate = rand() % m_population_size;

		if(m_population[best].rating < m_population[candidate].rating)
			best = candidate;
	}

	return best;
}


/////////////////////////////////////////////////////////////////////////////
////

void Csat::RenewPopulation(void)
{
	pair<int, int> best = BestChromosomes();
	m_new_population[0] = m_population[best.first];
	m_new_population[1] = m_population[best.second];

	for(int i = 2; i < m_population_size; i += 2)
	{
		// i+1 pretece, kdyz je velikost populace licha
		assert(m_population_size % 2 == 0);
		m_new_population[i] = m_population[Tournament()];
		m_new_population[i+1] = m_population[Tournament()+1];

		if(rand() / (double)RAND_MAX < m_cross_probability)
			Crossover(m_new_population[i], m_new_population[i+1]);

		if(rand() / (double)RAND_MAX < m_mutation_probability)
			Mutate(m_new_population[i]);

		if(rand() / (double)RAND_MAX < m_mutation_probability)
			Mutate(m_new_population[i+1]);
	}

	CHROMOSOME* tmp = m_population;
	m_population = m_new_population;
	m_new_population = tmp;
}


/////////////////////////////////////////////////////////////////////////////
////

pair<int, int> Csat::BestChromosomes(void) const
{
	int best = 0;
	int best2 = 1;

	for(int i = 2; i < m_population_size; i++)
	{
		if(m_population[best].rating < m_population[i].rating)
			best = i;
		else if(m_population[best2].rating < m_population[i].rating)
			best2 = i;
	}

	return pair<int, int>(best, best2);
}


/////////////////////////////////////////////////////////////////////////////
////

int Csat::EvaluateSolution(const CHROMOSOME& chrom) const
{
	// Chromosome should be always satisfied here
//	assert(IsSatisfied(chrom));

	int sum = 0;

	for(int i = 0; i < m_num_vars; i++)
	{
		if(chrom.vars[i+1])
		 	sum += m_weights[i+1];
	}

	return sum;
}


/////////////////////////////////////////////////////////////////////////////
////

void Csat::TryImproveSolution(CHROMOSOME& chrom)
{
	CHROMOSOME tmp = chrom;

	for(int i = 0; i < m_num_vars; i++)
	{
		if(tmp.vars[i+1] == false)
		{
			tmp.vars[i+1] = true;
			if(IsSatisfied(tmp))
			{
//				cout << "I " << EvaluateSolution(chrom) << "->" << EvaluateSolution(tmp) << endl;
//				usleep(500);
				chrom.vars[i+1] = true;
			}
			else
			{
				tmp.vars[i+1] = false;
			}
		}
	}

//	assert(IsSatisfied(chrom));
}


/////////////////////////////////////////////////////////////////////////////
////

void Csat::SaveSolution(const CHROMOSOME& chrom)
{
	string filename_sol = m_filename + ".sol";

	ofstream os(filename_sol.c_str(), ios::app);
	if(!os.is_open())
	{
		cerr << "Couldn't open output file: " << filename_sol << endl;
		return;
	}

	os << m_num_clauses << "\t" << chrom.rating << "\t";

	for(int i = 0; i < m_num_vars; i++)
		os << chrom.vars[i+1];

	os << endl;

	os.close();
}

