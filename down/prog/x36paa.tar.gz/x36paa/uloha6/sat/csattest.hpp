/***************************************************************************
 *   SAT problem #6 - genetic algorihms                                    *
 *   Copyright (C) 2007 by Michal Turek                                    *
 *   http://woq.nipax.cz/                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <list>
#include <fstream>

#include "csat.hpp"

#define NUM_CLAUSES_FOR_TESTING 70


/////////////////////////////////////////////////////////////////////////////
//// Testing framework

class CsatTest : public Csat
{
public:
	CsatTest();
	~CsatTest();

	vector<string> ListDirectory(string dirname) const;
	bool IsCnf(const string& filename) const;

	void Run(const string& dirname);
	void RunNumSatisfied(const vector<string>& filenames);
	void RunPopulationQualityInGeneration(const vector<string>& filenames);
	void RunDisableTryImproveSolution(const vector<string>& filenames);
	void RunPopulationSize(const vector<string>& filenames);
	void RunPopulationSize1(const vector<string>& filenames);
	void RunMutationAVG(const vector<string>& filenames);
	void RunMutation(const vector<string>& filenames);
	void RunCrossoverAVG(const vector<string>& filenames);
	void RunCrossover(const vector<string>& filenames);
	void RunTournamentAVG(const vector<string>& filenames);
	void RunTournament(const vector<string>& filenames);


protected:

};

