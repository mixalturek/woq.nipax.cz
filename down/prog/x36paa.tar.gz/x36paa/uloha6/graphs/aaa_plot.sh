#!/bin/bash

for filename in *.plot;
do
	echo "$filename"
	gnuplot "$filename"
done
