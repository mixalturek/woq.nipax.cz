<?php
include_once './inc/auth.php';
include_once './inc/func.php';
include_once './inc/connect.php';

define('NUM', '18');

if(isset($_POST['data']))
{
	$_POST['cena'] = str_replace(",", '.', $_POST['cena']);// Des. ��rka/te�ka
	$_POST['cena'] = Validate($_POST['cena']);
	$_POST['popis'] = Validate($_POST['popis']);

	$query = "INSERT INTO data (datum,cena,popis) VALUES (NOW(),{$_POST['cena']},'{$_POST['popis']}');";
	mysql_query($query);

	header("Location: http://{$_SERVER['HTTP_HOST']}{$_SERVER[PHP_SELF]}");
	exit();
}

$p_title = 'Teplochod';
include_once './inc/begin.php';
?>

<div>
<form action="<?php echo $_SERVER[PHP_SELF];?>" method="post">
<p>
<input type="text" name="cena" value="-" size="5" /> <input type="text" name="popis" size="20" /> <input type="submit" name="data" value="OK" />
</p>
</form>
</div>

<?php
echo '<div style="float: left;">';
$query = 'SELECT ROUND(SUM(cena), 2) AS ":-)" FROM data WHERE cena > 0 ORDER BY datum DESC LIMIT 50';
mysql_print_query($query);
echo '</div>';

echo '<div style="float: right;">';
$query = 'SELECT ROUND(SUM(cena), 2) AS ":-(" FROM data WHERE cena < 0 ORDER BY datum DESC LIMIT 50';
mysql_print_query($query);
echo '</div>';


$g_pos = isset($_GET['pos']) ? Validate($_GET['pos']) : 0;

$query = "SELECT id AS ID, datum AS Datum, ROUND(cena, 2) AS Cena, popis AS Popis FROM data ORDER BY datum DESC LIMIT $g_pos, ".NUM;
mysql_print_query($query);



$query = 'SELECT COUNT(*) FROM data';
$result = mysql_query($query);
$arr = mysql_fetch_array($result, MYSQL_NUM);
$count = $arr[0];

echo "<div class=\"prev_next\">\n";

if($g_pos > 0)
	echo "<a href=\"{$_SERVER[PHP_SELF]}?pos=".(($g_pos-NUM > 0) ? $g_pos-NUM : 0)."\">&lt;&lt;&lt;</a>\n";

if($g_pos+NUM < $count)
	echo "<a href=\"{$_SERVER[PHP_SELF]}?pos=".($g_pos+NUM)."\">&gt;&gt;&gt;</a>\n";

echo "</div>\n\n";


include_once './inc/end.php';
?>
