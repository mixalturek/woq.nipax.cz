<?php
//if($_SERVER['REMOTE_ADDR'] != '')// Omezeni na urcitou IP adresu
{
	echo 'K�ic';
	exit();
}

// Uzivatel heslo
if(!($_SERVER['PHP_AUTH_USER'] == '' && $_SERVER['PHP_AUTH_PW'] == ''))
{
	header('Content-Type: text/html; charset=iso-8859-2');
	header('WWW-Authenticate: Basic realm="Prihlaste se, prosim"');
	header('HTTP/1.0 401 Unauthorized');
	echo 'Neautorizov�no!';
	exit;
}
?>
