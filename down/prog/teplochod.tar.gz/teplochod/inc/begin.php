<?php
Header('Content-Type: text/html; charset=iso-8859-2');
include_once './inc/auth.php';
include_once './inc/func.php';
include_once './inc/connect.php';

echo '<?xml version="1.0" encoding="iso-8859-2"?>', "\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="CS">

<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-2" />
<meta http-equiv="content-language" content="cs" />

<title>Teplochod: <?php echo $p_title;?></title>

<meta name="keywords" content="teplochod" />
<meta name="description" content="teplochod" />
<meta name="webmaster" content="Michal Turek; http://woq.nipax.cz/" />
<meta name="copyright" content="Copyright (c) 2006 Michal Turek" />
<meta name="robots" content="all, follow" />
<meta name="resource-type" content="document" />

<style type="text/css" media="all">@import "style.css";</style>
<link href="img/website/ico.png" rel="shortcut icon" type="image/x-icon" />
</head>

<body>

<div id="sum">
<?php
$query = 'SELECT ROUND(SUM(cena), 2) AS Celkem FROM data';
mysql_print_query($query);
?>
</div>

<div id="main">

<h1><?php echo $p_title;?></h1>
