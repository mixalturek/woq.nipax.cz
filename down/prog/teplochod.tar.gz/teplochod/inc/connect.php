<?php
define('MYSQL_HOST', 'localhost');
define('MYSQL_USER', '');
define('MYSQL_PASSWD', '');
define('MYSQL_DB', 'teplochod');

$link = mysql_connect(MYSQL_HOST, MYSQL_USER, MYSQL_PASSWD) or die('Unable to connect MySQL');
mysql_select_db(MYSQL_DB) or die('Unable to select db');
?>