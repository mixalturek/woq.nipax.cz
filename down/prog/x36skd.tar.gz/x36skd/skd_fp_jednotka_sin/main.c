#include <stdio.h>
#include <signal.h>

/* Nejprve definujme novy datovy typ extended, ktery
   reprezenuje 80-ti bitove cislo v plovouci radove carce.
   Tento typ je pouzit pro definici struktury _fp_state, kde nebylo
   mozne pouzit ekvivalentni typ long double, protoze ten
   ma delku 12 byte z duvodu zarovnani na 32 bitu.
 */     
typedef unsigned char extended[10];

/* Struktura, ktera reprezentuje stav floating-point (FP) jednotky. Do teto struktury 
   uklada instrukce FSAVE and z ni nacita instrukce FRSTOR.
 */  
struct  __attribute__ ((packed)) _fp_state {
  unsigned int control_word;  // Ridici slovo
  unsigned int status_word;   // Stavove slovo
  unsigned int tag_word;      // Registr atributu platnosti obsahu registru zasobniku st(x)
  unsigned int fipo;          // FPU Instruction Pointer Offset
  unsigned int fips;          // FPU Instruction Pointer Selector
  unsigned int fopo;          // FPU Operand Pointer Offset
  unsigned int fops;          // FPU Operand Pointer Selector  
  extended st[8];
};
 
// Definujeme nejen strukturu, ale taky datovy typ fp_context
typedef struct _fp_state fp_state;

/* Tato funkce je nezbytna pro konverzi extended do 
   long double.
 */  
long double  e2d(extended ev) {
  // Deklarujme a vynulujme novou promennou long double
  long double v = 0.0;
  // Prekopirujme obsah ev do v
  asm("fldt %0" : : "m" (*ev));
  asm("fstpt %0" : : "m" (v));
  // Vratme novou honotu
  return v;
}

char* exceptions[] = {	"Neplatna operace", "Nenormalizovany operand",
			"Deleni nulou", "Preteceni", "Podteceni", "Presnost",
			"Chyba zasobniku", "Chyba" };

void fpdump_x(int point) {

  fp_state fps; // deklarujeme prostor pro stav FP jednotky
  
  int i;   // deklarujme index do zasobniku
  int st;  // deklarujme index do fyzickych registru zasobiku
  int top; // deklarujme ukazatel vrcholu zasobniku (index do fyzickych registru)
  int cw;
  int k;
  
  // Uloz stav FP jednotky
  asm("fsave %0" : : "m" (fps));
  
  // Zjisti, ktery z registru je vrcholem zasobniku
  top = (fps.status_word >> 11) & 0x7;
  
  cw = fps.status_word;
  
  // Tiskni hlavicku informacniho bloku
  printf("-- %.3d -----------------------\n", point);
  printf(" Control: %Xh\n", fps.control_word);
  printf(" Status : %Xh\n", cw);
  printf(" Error  : ");
  
  k = 0;
  for(i = 0; i < 8; i++) {
    if (cw & 0x1 != 0) {
      if (k != 0) printf(","); 
      printf("%s", exceptions[i]);
      k++;
    }  
    cw >>= 1;
  }
  if (k == 0) printf("no error");
  printf("\n");
    
  // Tiskni obsah zasobniku. Tiskni zasobnik odspodu, st(0) bude tedy dole.
  // Pozor ! FSAVE uklada registry v poradi pocinaje st(0), pak st(1), atd.
  // Staci tedy indexovat fps.st[i], pro i=0, 1, ..., 7. Index fyzickeho
  // registru potrebujeme pouze pro extrakci informace z Tag slova.  
  for(i = 0; i < 8; i++) {
    st = (top + i) & 0x7;
    printf(" ST(%d)  : ", i);
    switch ((fps.tag_word >> (2 * st)) & 0x03) {
      case 0x00: printf("valid : %LE", e2d(fps.st[i])); break;
      case 0x01: printf("zero  : %LE", e2d(fps.st[i])); break;
      case 0x02: printf("spec  : %LE", e2d(fps.st[i])); break;
      case 0x03: printf("empty : "); break;
    } 
    printf("\n"); 
  }
  printf("------------------------------\n");

  // Obnov stav FP jednotky ze struktury fps
  asm ("frstor %0": "=m" (fps));

}

/* Funkce, kterou muzeme zavolat z assembleru a ktera vytiskne
   hodnotu st(0).
 */   
void PRINTST0() {
  long double v = 0.0;
  asm("fst %st(0)");
  asm("fstpt %0" : "=m" (v));
  printf("\nst(0): %LE\n", v); 
}

/* Sada funkci, ktere muzeme volat z assembleru a ktere vytisknou
   kompletni fp zasobnik. Jednotlive funkce jsou odliseny cislem,
   ktere se tiskne v hlavicce. Timto cislem muzeme odlisit jednotlive
   body vypisu.
 */
   
void FPDUMP1() { fpdump_x(1); }	
void FPDUMP2() { fpdump_x(2); }	
void FPDUMP3() { fpdump_x(3); }	
void FPDUMP4() { fpdump_x(4); }	
void FPDUMP5() { fpdump_x(5); }	
void FPDUMP6() { fpdump_x(6); }	
void FPDUMP7() { fpdump_x(7); }	
void FPDUMP8() { fpdump_x(8); }	
void FPDUMP9() { fpdump_x(9); }	

/* Definujme externi funkci, kterou bude vytvaret student a 
   ktera bude prilinkovana k tomuto programu.
 */   
extern void student();
			 
void fp_exception(int v) {
  printf("\n*** FP vyjimka, program ukoncen ***\n\n");
  exit(1);
}    

/* Funkce main vola funkci student */
int main() {
  
  fp_state fps;
  
  signal(SIGFPE, fp_exception);
  
  // Uloz stav FP jednotky pred volanim 
  // funkce student 
  asm("fsave %0" : "=m" (fps));
  student();
  // Obnov stav FP jednotky po navratu ze funkce student
  asm("frstor %0" :  : "m" (fps));
  return 0;
}
