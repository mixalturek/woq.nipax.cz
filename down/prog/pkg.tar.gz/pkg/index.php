<?php
define('PAGE_TITLE', 'Package Manager');
Header('Content-Type: text/html; charset=iso-8859-2');

echo '<?xml version="1.0" encoding="iso-8859-2"?>', "\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="CS">

<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-2" />
<meta http-equiv="content-language" content="cs" />

<title><?php echo PAGE_TITLE;?></title>

<meta name="keywords" content="package, manager, x36tin, semestralni, prace" />
<meta name="description" content="Semestralni prace Package Manager do p�edm�tu X36TIN na FEL �VUT Praha" />
<meta name="webmaster" content="Michal Turek; WOQ (zavinac) seznam.cz" />
<meta name="copyright" content="Copyright (c) 2006 Michal Turek" />
<meta name="robots" content="all, follow" />
<meta name="resource-type" content="document" />

</head>

<body style="margin: 100px; padding: 0px;">

<pre>
<?php
require 'pkg.php';
?>
</pre>

</body>
</html>
