<?php
/***************************************************************************
 *   pkg - Simulace package manageru (semestr�ln� pr�ce z X36TIN)          *
 *   Copyright (C) 2006 by Michal Turek                                    *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


/////////////////////////////////////////////////////////////////////////////
//// GLOB�LN� PROM�NN�

// Seznam nainstalovan�ch bal��k�
// $g_installed['jm�no_bal��ku']
// 'e' - explicitn�, 'i' - implicitn� (instalov�n kv�li z�vislosti)

// Z�vislosti
// $g_dependencies['jm�no_bal��ku']['na �em z�vis�']


/////////////////////////////////////////////////////////////////////////////
//// Inicializuje z�vislosti dan�ho bal��ku

// Vstup: Pole slov
//	[0] "DEPEND"
//	[1] Jm�no bal��ku, pro kter� maj� b�t z�vislosti definov�ny
//	[2..n-1] Jm�na bal��k�, na kter�ch z�vis�

function Depend($words)
{
	global $g_dependencies;
	$num_words = count($words);

	for($i = 2; $i < $num_words; $i++)
		$g_dependencies[$words[1]][] = $words[$i];
}


/////////////////////////////////////////////////////////////////////////////
//// Je bal��ek nainstalov�n?

function IsInstalled($pkg_name)
{
	global $g_installed;
	return (isset($g_installed[$pkg_name])) ? true : false;
}


/////////////////////////////////////////////////////////////////////////////
//// Nainstaluje bal��ek

function Install($pkg_name, $explicit = true)
{
	global $g_dependencies;
	global $g_installed;

	if(IsInstalled($pkg_name))
	{
		if($explicit)
			echo "   $pkg_name is already installed\n";
		return;
	}

	if(isset($g_dependencies[$pkg_name]))
	{
		foreach($g_dependencies[$pkg_name] as $unused => $package)
			Install($package, false);
	}

	echo "   Installing $pkg_name\n";
	$g_installed[$pkg_name] = ($explicit) ? 'e' : 'i';
}


/////////////////////////////////////////////////////////////////////////////
//// M��e b�t bal��ek odstran�n?
//// Resp. existuj� n�jak� z�vislosti, kv�li kter�m nem��e b�t?

function CanBeRemoved($pkg_name)
{
	global $g_dependencies;
	global $g_installed;

	foreach($g_installed as $inst_pkg => $unused)
	{
		foreach($g_dependencies[$inst_pkg] as $unused => $dependency)
		{
			if($dependency == $pkg_name)
				return false;
		}
	}

	return true;
}


/////////////////////////////////////////////////////////////////////////////
//// Pokus� se odinstalovat bal��ek

function Remove($pkg_name, $explicit = true)
{
	global $g_dependencies;
	global $g_installed;

	// Pokud !$explicit, kontrolovalo by se to podruhy (viz rekurze)
	if($explicit && !IsInstalled($pkg_name))
	{
		echo "   $pkg_name is not installed\n";
		return;
	}

	if(CanBeRemoved($pkg_name))
	{
		unset($g_installed[$pkg_name]);
		echo "   Removing $pkg_name\n";

		foreach($g_dependencies[$pkg_name] as $unused => $dep)
		{
			// Pouze pokud nen� instalovan� explicitn�
			if(IsInstalled($dep) && $g_installed[$dep] == 'i')
				Remove($dep, false);
		}
	}
	else if($explicit)
		echo "   $pkg_name is still needed\n";
}


/////////////////////////////////////////////////////////////////////////////
//// Vyp��e seznam nainstalovan�ch bal��k�

function ListPackages()
{
	global $g_installed;

	foreach($g_installed as $pkg_name => $unused)
		echo "   $pkg_name\n";
}


/////////////////////////////////////////////////////////////////////////////
//// Parsovac� funkce vstupn�ho souboru

function ParseScript($filename)
{
	echo "Input file: $filename\n\n";

	$rows = file($filename);
	$num_rows = count($rows);

	for($i = 0; $i < $num_rows; $i++)
	{
		$rows[$i] = trim($rows[$i]);
		echo "<b>{$rows[$i]}</b>\n";
		$words = split('\ +', $rows[$i]);

		switch($words[0])
		{
			case 'DEPEND':	Depend($words);		break;
			case 'INSTALL':	Install($words[1]);	break;
			case 'REMOVE':	Remove($words[1]);	break;
			case 'LIST':	ListPackages();		break;
			case 'END':	return;			break;
			default: echo "   Unknown command\n";	break;
		}
	}
}


/////////////////////////////////////////////////////////////////////////////
//// Vstup do skriptu

ParseScript('data_net.txt');
?>
