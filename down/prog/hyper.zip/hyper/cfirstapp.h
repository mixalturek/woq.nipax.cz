/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __CFIRSTAPP_H__
#define __CFIRSTAPP_H__

#include "basecode.h"
#include "capplicationex.h"
#include "cgrid.h"
#include "cimage.h"
#include "ccamera.h"
#include "cspaceobject.h"

//#define DEBUG_FOR_TWO

#ifdef DEBUG_FOR_TWO
#define NUM_OBJECTS 2
#else
#define NUM_OBJECTS 50
#endif

using namespace std;

namespace basecode
{

class CFirstApp : public CApplicationEx
{
private:
	CFirstApp(const CFirstApp& obj) : CApplicationEx(0, NULL),
			m_cam(CVector(0.0f, 0.0f, 0.0f)) {}
	const CFirstApp& operator=(const CFirstApp& obj)
	{ return *this; }

public:
	CFirstApp(int argc, char *argv[]);
	virtual ~CFirstApp();
	virtual void Init(const string& win_title);

protected:
	virtual void InitGL();
	virtual void Draw();
	virtual void Update();
	virtual bool ProcessEvent(SDL_Event& event);

	void reinitAllObjects(void);

private:
	CCamera m_cam;
	vector<CSpaceObject> m_objects;

	bool m_gravitation_enabled;
	bool m_movement_enabled;
	bool m_vectors_enabled;
    float m_grav;
};

}

#endif
