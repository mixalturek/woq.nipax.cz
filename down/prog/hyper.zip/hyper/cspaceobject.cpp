/*
 *      cspaceobject.cpp
 *
 *      Copyright 2008 Michal Turek <http://woq.nipax.cz/>
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#include <cstdlib>
#include "cspaceobject.h"

using namespace std;

namespace basecode
{

GLUquadricObj* CSpaceObject::ms_quadratic = NULL;


float frand(void)
{
	return (float)rand() / RAND_MAX;
}

float frands(void)
{
	return ((float)rand() / RAND_MAX) - 0.5f;
}


CSpaceObject::CSpaceObject()
{

}

CSpaceObject::~CSpaceObject()
{
	if(ms_quadratic != NULL)
	{
		gluDeleteQuadric(ms_quadratic);
		ms_quadratic = NULL;
	}
}


void CSpaceObject::reinit(void)
{
	if(ms_quadratic == NULL)
	{
		ms_quadratic = gluNewQuadric();
		gluQuadricNormals(ms_quadratic, GLU_SMOOTH);
	}

	m_mass = 0.3f + frand() * 0.7f;

	m_pos = CVector(frands() * 15.0, frands() * 15.0, frands() * 15.0);
//	m_vel = CVector(frands() * 1.0, frands() * 1.0, 0.0f);
	m_vel = CVector(0.0f, 0.0f, 0.0f);
	m_acc = CVector(0.0f, 0.0f, 0.0f);

	m_color[0] = rand() % 255;
	m_color[1] = rand() % 255;
	m_color[2] = rand() % 255;
	m_color[rand() % 3] = (rand() % 100) + 155;
}


void CSpaceObject::update(float fps)
{
	m_vel += m_acc / fps;
	m_pos += m_vel / fps;
}


void CSpaceObject::goBack(float fps)
{
	m_pos -= (m_vel / fps);
}

void CSpaceObject::draw(bool vectors_enabled) const
{
	glColor3ubv(m_color);

	glPushMatrix();
		glTranslatef(m_pos.X, m_pos.Y, m_pos.Z);
		gluSphere(ms_quadratic, m_mass, 32, 32);
	glPopMatrix();

	if(vectors_enabled)
	{
		glLineWidth(2.0f);
		glBegin(GL_LINES);
			glVertex3fv(m_pos);
			glVertex3fv(m_pos + (m_vel * 5.0f));
		glEnd();
	}


/*	// Points
	glPointSize(m_mass * 10);
	glBegin(GL_POINTS);
		glVertex3fv(m_pos);
	glEnd();
*/

/*	// Hypercubes :-)
	glPushMatrix();
		float width = m_mass;
		float height = m_mass;
		float depth = m_mass;

		glTranslatef(m_pos.X, m_pos.Y, m_pos.Z);

		glBegin(GL_LINE_STRIP);// Front
			glVertex3f(-width, height, depth);
			glVertex3f(-width,-height, depth);
			glVertex3f( width,-height, depth);
			glVertex3f( width, height, depth);
			glVertex3f(-width, height, depth);
		glEnd();

		glBegin(GL_LINE_STRIP);// Back
			glVertex3f(-width, height,-depth);
			glVertex3f(-width,-height,-depth);
			glVertex3f( width,-height,-depth);
			glVertex3f( width, height,-depth);
			glVertex3f(-width, height,-depth);
		glEnd();

		glBegin(GL_LINES);
			glVertex3f(-width, height, depth);
			glVertex3f(-width, height,-depth);

			glVertex3f( width, height, depth);
			glVertex3f( width, height,-depth);

			glVertex3f( width,-height, depth);
			glVertex3f( width,-height,-depth);

			glVertex3f(-width,-height, depth);
			glVertex3f(-width,-height,-depth);
		glEnd();
	glPopMatrix();
*/
}

bool CSpaceObject::collisionWith(CSpaceObject& obj) const
{
	return m_pos.Distance(obj.getPos()) < m_mass + obj.getMass();
}

} // namespace
