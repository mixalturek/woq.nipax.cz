/*
 *      cspaceobject.h
 *
 *      Copyright 2008 Michal Turek <http://woq.nipax.cz/>
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#ifndef CSPACEOBJECT_H
#define CSPACEOBJECT_H

#include <SDL_opengl.h>
#include "basecode.h"
#include "cvector.h"


using namespace std;

typedef unsigned char byte;

namespace basecode
{

class CSpaceObject
{
public:
	CSpaceObject();
	~CSpaceObject();

	void reinit(void);
	void draw(bool vectors_enabled) const;
	void update(float fps);

	float getMass(void) const { return m_mass; }
	void setMass(float mass) { m_mass = mass; }
	CVector& getPos(void) { return m_pos; }
	CVector& getVel(void) { return m_vel; }
	CVector& getAcc(void) { return m_acc; }

	void resetAcc(void) { m_acc = CVector(0.0f, 0.0f, 0.0f); }
	void addAcc(const CVector& acc) { m_acc += acc; }

	// For collisions (hybnost)
	bool collisionWith(CSpaceObject& obj) const;
	void goBack(float fps);


private:
	float m_mass;
	CVector m_pos;
	CVector m_vel;
	CVector m_acc;
	byte m_color[3];

	static GLUquadricObj* ms_quadratic;
};

} // namespace

#endif /* CSPACEOBJECT_H */
