/***************************************************************************
 *   basecode - archive of useful C++ classes                              *
 *   Copyright (C) 2004 by Michal Turek - Woq                              *
 *   WOQ (at) seznam.cz, http://woq.nipax.cz/                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "cfirstapp.h"

namespace basecode
{

CFirstApp::CFirstApp(int argc, char *argv[]) :
		CApplicationEx(argc, argv),
		m_cam(CVector(0.0f, 0.0f, -20.0f)),
		m_objects(NUM_OBJECTS, CSpaceObject()),
		m_gravitation_enabled(false),
		m_movement_enabled(true),
		m_vectors_enabled(true),
		m_grav(3.0f) // 6.67e-11 ;-)
{
#ifdef DEBUG_FOR_TWO
	m_objects[0].getPos() = CVector(-5.0f, 0.0f, 0.0f);
	m_objects[0].getVel() = CVector(1.0f, 0.0f, 0.0f);
	m_objects[0].setMass(1.0f);

	m_objects[1].getPos() = CVector( 5.0f, 0.0f, 0.0f);
	m_objects[1].getVel() = CVector(-0.5f, 0.0f, 0.0f);
	m_objects[1].setMass(2.0f);
#else
	reinitAllObjects();
#endif
}


void CFirstApp::reinitAllObjects(void)
{
	vector<CSpaceObject>::iterator it;
	vector<CSpaceObject>::iterator done;

	for(it = m_objects.begin(); it != m_objects.end(); it++)
	{
		bool initialized = false;
		while(!initialized)
		{
			it->reinit();
			initialized = true;

			for(done = m_objects.begin(); done != it; done++)
			{
				if(it->collisionWith(*done))
					initialized = false;
			}
		}
	}
}


CFirstApp::~CFirstApp()
{

}

void CFirstApp::Init(const string& win_title)
{
	CApplicationEx::Init(win_title);
	SDL_ShowCursor(SDL_DISABLE);

	SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);
}

void CFirstApp::InitGL()
{
	CApplicationEx::InitGL();

	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClearDepth(1.0);
	glDepthFunc(GL_LEQUAL);
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glDisable(GL_LIGHTING);
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_BLEND);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_COLOR_MATERIAL);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void CFirstApp::Draw()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	m_cam.LookAt();

	// Axis
	glDisable(GL_LIGHTING);
	glLineWidth(3.0f);
	glBegin(GL_LINES);
		float size = 1000.0f;
		glColor3ub(255, 0, 0);
		glVertex3f(-size, 0.0f, 0.0f);
		glVertex3f( size, 0.0f, 0.0f);

		glColor3ub(0, 255, 0);
		glVertex3f(0.0f,-size, 0.0f);
		glVertex3f(0.0f, size, 0.0f);

		glColor3ub(0, 0, 255);
		glVertex3f(0.0f, 0.0f,-size);
		glVertex3f(0.0f, 0.0f, size);
	glEnd();
	glEnable(GL_LIGHTING);

	vector<CSpaceObject>::const_iterator it;
	for(it = m_objects.begin(); it != m_objects.end(); it++)
		it->draw(m_vectors_enabled);

	glColor3ub(255, 255, 255);
	GetFont().Begin();
	GetFont().SetAlign(ALIGN_RIGHT);
	GetFont().Draw((m_gravitation_enabled) ? "gravitation on" : "gravitation off", GetWinWidth()-10, GetWinHeight()-70, true);
	GetFont().Draw((m_movement_enabled) ? "movement on" : "movement off", GetWinWidth()-10, GetWinHeight()-50, true);
	GetFont().Draw((m_vectors_enabled) ? "vectors on" : "vectors off", GetWinWidth()-10, GetWinHeight()-30, true);
	stringstream ss;
	ss << "gravitation " << m_grav;
	GetFont().Draw(ss.str(), GetWinWidth()-10, GetWinHeight()-10, true);
	GetFont().SetAlign(ALIGN_LEFT);
	GetFont().End();

	GetFont().Begin();
	GetFont().SetAlign(ALIGN_CENTER);
	GetFont().Draw("Usage: g, m, v, home, end, pageup, pagedown, r", GetWinWidth()/2, GetWinHeight()-10, true);
	GetFont().SetAlign(ALIGN_LEFT);
	GetFont().End();

	CApplicationEx::Draw();
}

void CFirstApp::Update()
{
	SDL_PumpEvents();

	Uint8* keys;
	keys = SDL_GetKeyState(NULL);

	if(keys[SDLK_UP] == SDL_PRESSED || keys[SDLK_w] == SDL_PRESSED)
		m_cam.GoFront(GetFPS());
	if(keys[SDLK_DOWN] == SDL_PRESSED || keys[SDLK_s] == SDL_PRESSED)
		m_cam.GoBack(GetFPS());
	if(keys[SDLK_LEFT] == SDL_PRESSED || keys[SDLK_a] == SDL_PRESSED)
		m_cam.GoLeft(GetFPS());
	if(keys[SDLK_RIGHT] == SDL_PRESSED || keys[SDLK_d] == SDL_PRESSED)
		m_cam.GoRight(GetFPS());



	if(!m_movement_enabled)
		return;


	// Gravitation
	vector<CSpaceObject>::iterator it;
	vector<CSpaceObject>::iterator se;

	for(it = m_objects.begin(); it != m_objects.end(); it++)
		it->resetAcc();

	for(it = m_objects.begin(); it != m_objects.end(); it++)
	{
		if(m_gravitation_enabled)
		{
			for(se = it + 1; se != m_objects.end(); se++)
			{
				float dist = it->getPos().Distance(se->getPos());

				// if dist was small, force and acceleration would be too big
				if(dist < it->getMass() + se->getMass())
					dist = it->getMass() + se->getMass();

				CVector force = CVector(it->getPos(), se->getPos())
					* ((m_grav * it->getMass() * se->getMass()) / (dist*dist*dist));

				it->addAcc(force / it->getMass());
				se->addAcc(-force / se->getMass());
			}
		}
	}


	// Velocity, position
	for(it = m_objects.begin(); it != m_objects.end(); it++)
		it->update(GetFPS());
}

bool CFirstApp::ProcessEvent(SDL_Event& event)
{
	switch(event.type)
	{
	case SDL_MOUSEMOTION:
		// SDL_WarpMouse() generates SDL_MOUSEMOTION event :-(
		if(event.motion.x != GetWinWidth() >> 1
		|| event.motion.y != GetWinHeight() >> 1)
		{
			m_cam.Rotate(event.motion.xrel,
					event.motion.yrel, GetFPS());

			// Center mouse in window
			SDL_WarpMouse(GetWinWidth()>>1, GetWinHeight()>>1);
		}
		break;

	case SDL_KEYDOWN:
		switch(event.key.keysym.sym)
		{
		case SDLK_m:
			m_movement_enabled = !m_movement_enabled;
			break;

		case SDLK_g:
			m_gravitation_enabled = !m_gravitation_enabled;
			break;

		case SDLK_v:
			m_vectors_enabled = !m_vectors_enabled;
			break;

		case SDLK_r:
			reinitAllObjects();
			break;

		case SDLK_HOME:
			m_grav += 0.1;
			break;

		case SDLK_END:
			m_grav -= 0.1;
			break;

		case SDLK_PAGEUP:
			m_grav += 10.0;
			break;

		case SDLK_PAGEDOWN:
			m_grav -= 10.0;
			break;

		default:// Other key
			return CApplicationEx::ProcessEvent(event);
			break;
		}
		break;

	default:// Other events
		return CApplicationEx::ProcessEvent(event);
		break;
	}

	return true;
}

}
