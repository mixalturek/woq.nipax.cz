/*
 *      Copyright 2009 Michal Turek <http://woq.nipax.cz/>
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#include <QEvent>
#include <QApplication>
#include <QPainter>
#include <QLocale>
#include "window.h"


/////////////////////////////////////////////////////////////////////////////
////

Window::Window(QWidget* parent)
	: QWidget(parent)
{
}

Window::~Window()
{

}


/////////////////////////////////////////////////////////////////////////////
////

bool Window::event(QEvent* event)
{
	if(event->type() == QEvent::KeyboardLayoutChange)
		update();

	return QWidget::event(event);
}


/////////////////////////////////////////////////////////////////////////////
////

void Window::paintEvent(QPaintEvent* /* event */)
{
	QLocale locale = QApplication::keyboardInputLocale();

	QPainter painter;
	painter.begin(this);
	painter.fillRect(rect(), QColor(200, 200, 230));
	painter.setFont(QFont("Monospace", 8, 100));
	painter.drawText(rect(), Qt::AlignCenter, locale.name().section('_', 0, 0));
	painter.end();
}


/////////////////////////////////////////////////////////////////////////////
////

QSize Window::sizeHint() const
{
	return QSize(50, 50);
}
