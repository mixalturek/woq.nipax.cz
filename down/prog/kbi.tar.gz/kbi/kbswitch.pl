#!/usr/bin/perl -w
#
# Copyright (C) 2008 Michal Turek
# License: GNU GPL v2
#
# Switch keyboard layouts (us, cz...) with osd indication
#
# Available layouts are in
#	/usr/share/X11/xkb/rules/base.lst
#	/usr/share/X11/xkb/symbols.dir

use constant FILENAME_KB => "/home/woq/.kbswitch.txt";
use constant FILENAME_KBA => "/home/woq/.kbswitch_active.txt";

open(FILE_KBA, "< ".FILENAME_KBA) or die("Unable to open ".FILENAME_KBA);
@data = <FILE_KBA>;
$curpos = $data[0] + 1;
close(FILE_KBA);

open(FILE_KBA, "> ".FILENAME_KBA) or die("Unable to open ".FILENAME_KBA);
print(FILE_KBA $curpos);
close(FILE_KBA);

open(FILE_KB, "< ".FILENAME_KB) or die("Unable to open ".FILENAME_KB);
@data = <FILE_KB>;
$lng = @data[$curpos % @data];
close(FILE_KB);

print $lng;

# Change keyboard layout
`setxkbmap $lng`;

# Set special keys (ThinkPad R400)
`xmodmap -e 'keycode 234 = KP_Subtract'`;
`xmodmap -e 'keycode 233 = KP_Add'`;

# OSD display
# `echo '$lng' | osd_cat -p bottom -o -70 -A center -d 1 -O 1 -u white -f '-dejavu-dejavu sans-bold-r-normal--33-240-100-100-p-222-iso8859-1'`;
