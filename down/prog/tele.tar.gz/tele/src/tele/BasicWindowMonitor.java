package tele;

import java.awt.event.*;
import java.awt.Window;

/**
 * <p>Title: Tele</p>
 * <p>Description: Catologue of telephone number</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: FEL CVUT Praha</p>
 * @author Michal Turek - Woq <WOQ@seznam.cz>, http://woq.nipax.cz/
 * @version 1.0
 */

public class BasicWindowMonitor extends WindowAdapter
{
  public void windowClosing(WindowEvent e)
  {
    Window w = e.getWindow();
    w.setVisible(false);
    w.dispose();
    System.exit(0);
  }
}
