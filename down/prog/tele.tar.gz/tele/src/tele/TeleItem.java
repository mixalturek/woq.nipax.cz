package tele;

/**
 * <p>Title: Tele</p>
 * <p>Description: Catologue of telephone number</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: FEL CVUT Praha</p>
 * @author Michal Turek - Woq <WOQ@seznam.cz>, http://woq.nipax.cz/
 * @version 1.0
 */

public class TeleItem
{
  private String name = null;
  private String number = null;

  public TeleItem(String[] name_number)// Constructor
  {
    try
    {
      name = name_number[0];
      number = name_number[1];
    }
    catch(ArrayIndexOutOfBoundsException ex)
    {

    }
  }

  public TeleItem(String new_name, String new_number)// Constructor
  {
    name = new_name;
    number = new_number;
  }

  public void SetName(String new_name)
  {
    name = new_name;
  }

  public void SetNumber(String new_number)
  {
    number = new_number;
  }

  public String GetName()
  {
    return name;
  }

  public String GetNumber()
  {
    return number;
  }

  public String toString()
  {
    return name + " - " + number;
  }
}
