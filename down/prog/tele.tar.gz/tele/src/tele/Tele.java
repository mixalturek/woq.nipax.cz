package tele;

import java.util.*;
import java.io.*;

/**
 * <p>Title: Tele</p>
 * <p>Description: Catologue of telephone number</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: FEL CVUT Praha</p>
 * @author Michal Turek - Woq <WOQ@seznam.cz>, http://woq.nipax.cz/
 * @version 1.0
 */

public class Tele
{
  private ArrayList alist = new ArrayList();// Dynamic field
  private final String ITEM_SEPARATOR = "\t\t\t";// In file

  public Tele(String filename)// Constructor
  {
    LoadFromFile(filename);
  }

  public void AddItem(TeleItem new_item)
  {
    alist.add(new_item);
  }

  public void AddItem(int index, TeleItem new_item)
  {
    alist.add(index, new_item);
  }

  public void AddItem(String name, String number)
  {
    AddItem(new TeleItem(name, number));
  }

  public void AddItem(int index, String name, String number)
  {
    AddItem(index, new TeleItem(name, number));
  }

  public TeleItem GetItem(int index)
  {
    return (TeleItem)alist.get(index);
  }

  public TeleItem RemoveItem(int index)
  {
    return (TeleItem)alist.remove(index);
  }

  public int GetSize()
  {
    return alist.size();
  }

  public void LoadFromFile(String filename)
  {
    try
    {
      BufferedReader fr = new BufferedReader(new FileReader(filename));
      String line = null;// One loaded line from file

      while((line = fr.readLine()) != null)
      {
        alist.add(new TeleItem(line.split(ITEM_SEPARATOR)));
      }

      fr.close();
    }
    catch(FileNotFoundException ex)
    {

    }
    catch(IOException ex)
    {

    }
  }

  public void SaveToFile(String filename)
  {
    try
    {
      BufferedWriter fw = new BufferedWriter(new FileWriter(filename));

      for(int i = 0; i < alist.size(); i++)
      {
        TeleItem titem = (TeleItem)alist.get(i);

        fw.write(titem.GetName() + ITEM_SEPARATOR + titem.GetNumber());
        fw.newLine();
      }

      fw.close();
    }
    catch(IOException ex)
    {

    }
  }
}
