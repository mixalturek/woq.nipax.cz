package tele;

import java.awt.*;
import java.awt.event.*;

/**
 * <p>Title: Tele</p>
 * <p>Description: Catologue of telephone number</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: FEL CVUT Praha</p>
 * @author Michal Turek - Woq <WOQ@seznam.cz>, http://woq.nipax.cz/
 * @version 1.0
 */

public class TeleGUI extends Frame implements ActionListener
{
  private final String FILENAME = "./teledata.txt";

  private Tele tele = new Tele(FILENAME);
  private int displayed_item = 0;// Actual displayed item

  Button add_btn = new Button("Add");
  Button remove_btn = new Button("Remove");
  Button prew_btn = new Button("<");
  Button next_btn = new Button(">");
  Button save_btn = new Button("Save to file");

  TextField name_editbox = new TextField("", 18);
  TextField number_editbox = new TextField("", 18);

  Panel btn_panel = new Panel();
  Panel name_panel = new Panel();
  Panel number_panel = new Panel();

  public TeleGUI()// Constructor
  {
    super("Tele");// Window title
    setSize(270, 160);// Window size
    addWindowListener(new BasicWindowMonitor());// Window closing

    // Layout of editboxes, buttons, etc...
    name_panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 12));
    number_panel.setLayout(new FlowLayout(FlowLayout.CENTER));
    btn_panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 12));

    if(tele.GetSize() > 0)// File contains data
    {
      TeleItem ti = tele.GetItem(displayed_item);
      name_editbox.setText(ti.GetName());
      number_editbox.setText(ti.GetNumber());

      prew_btn.setEnabled(false);
    }
    else// No data in file
    {
      prew_btn.setEnabled(false);
      next_btn.setEnabled(false);
      remove_btn.setEnabled(false);
    }

    btn_panel.add(add_btn);// Add editboxes and buttons to panels
    btn_panel.add(remove_btn);
    btn_panel.add(save_btn);
    name_panel.add(prew_btn);
    name_panel.add(name_editbox);
    name_panel.add(next_btn);
    number_panel.add(number_editbox);

    add(name_panel, BorderLayout.NORTH);// Add panels to window
    add(number_panel, BorderLayout.CENTER);
    add(btn_panel, BorderLayout.SOUTH);

    // Click on button to scroll left
    prew_btn.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if(displayed_item > 0)
        {
          displayed_item--;

          TeleItem ti = tele.GetItem(displayed_item);
          name_editbox.setText(ti.GetName());
          number_editbox.setText(ti.GetNumber());

          next_btn.setEnabled(true);
        }

        if(displayed_item == 0)
        {
          prew_btn.setEnabled(false);
        }
      }
    });

    // Click on button to scroll right
    next_btn.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if(displayed_item < tele.GetSize()-1)
        {
          displayed_item++;

          TeleItem ti = tele.GetItem(displayed_item);
          name_editbox.setText(ti.GetName());
          number_editbox.setText(ti.GetNumber());

          prew_btn.setEnabled(true);
        }

        if(displayed_item == tele.GetSize()-1)
        {
          next_btn.setEnabled(false);
        }
      }
    });

    // Click on button to add item to field
    add_btn.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        String name = name_editbox.getText().trim();// Delete spaces at edges
        String number = number_editbox.getText().trim();

        if(tele.GetSize() > 0)
        {
          TeleItem ti = tele.GetItem(displayed_item);

          // Empty strings or equals to list item
          if((name.length() == 0 || number.length() == 0)
             || (name.equals(ti.GetName()) && number.equals(ti.GetNumber())))
          {
            return;
          }
        }
        else
        {
          // Empty strings or equals to list item
          if((name.length() == 0 || number.length() == 0))
          {
            return;
          }
        }

        tele.AddItem(displayed_item, name, number);
        remove_btn.setEnabled(true);

        if(displayed_item < tele.GetSize()-1)
        {
          next_btn.setEnabled(true);
        }
      }
    });

    // Click on button to remove item from field
    remove_btn.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        tele.RemoveItem(displayed_item);

        if(tele.GetSize() == 0)
        {
          name_editbox.setText("");
          number_editbox.setText("");
          remove_btn.setEnabled(false);
        }
        else if(tele.GetSize() == 1)
        {
          prew_btn.setEnabled(false);
          next_btn.setEnabled(false);
        }

        if(displayed_item < tele.GetSize())
        {
          TeleItem ti = tele.GetItem(displayed_item);
          name_editbox.setText(ti.GetName());
          number_editbox.setText(ti.GetNumber());
        }
        else if(displayed_item > 0)// Remove from the right border
        {
          displayed_item--;

          TeleItem ti = tele.GetItem(displayed_item);
          name_editbox.setText(ti.GetName());
          number_editbox.setText(ti.GetNumber());
        }
      }
    });

  // Click on button to save to the file
    save_btn.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        tele.SaveToFile(FILENAME);
      }
    });
  }

  public void actionPerformed(ActionEvent ae)// Because of abstract class
  {

  }

  public static void main(String[] args)// Enter to program
  {
    TeleGUI tgui = new TeleGUI();// Object of this class
    tgui.setVisible(true);// Display it
  }
}
