<?php
// convert -resize 1000x700 tmp.bmp tmp.jpg

$directory = Dir('./');

while($filename = $directory->Read())
{
	if(!ereg('.*\.bmp$', $filename))
		continue;

	$filename_orig = $filename;

	$filename = str_replace('.bmp', '', $filename);
	$filename = str_replace(' ', '_', $filename);
	$filename_orig = str_replace(' ', '\ ', $filename_orig);


	echo "convert -resize 1000x700 $filename_orig $filename.jpg\n";
	exec("convert -resize 1000x700 $filename_orig $filename.jpg");
}
?>