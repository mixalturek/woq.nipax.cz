<?php
echo '<?xml version="1.0" encoding="iso-8859-2"?>';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="CS">

<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-2" />
<meta http-equiv="content-language" content="cs" />

<title>Zad�n�</title>

<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="webmaster" content="Michal Turek; WOQ (zavinac) seznam.cz" />
<meta name="copyright" content="Copyright (c) 2006 Michal Turek" />
<meta name="robots" content="all, follow" />
<meta name="resource-type" content="document" />

<script language="javascript">
function Change(img)
{
	document.getElementById('image').innerHTML = '<img src="' + img + '" style="max-width: 80%; max-height: 80%; float: right;" />';
}
</script>

</head>

<body>

<div id="image">
<img src="str_100001.jpg" style="max-width: 80%; max-height: 80%; float: right;" />
</div>

<?php
$directory = Dir('./');

while($filename = $directory->Read())
{
	if(!ereg('.*\.jpg$', $filename))
		continue;

	echo "<div><a href=\"javascript: Change('$filename');\">$filename</a></div>\n";
}
?>

</body>
</html>