/***************************************************************************
 *   Copyright (C) 2005 by Michal Turek - Woq                              *
 *   WOQ (zavinac) seznam.cz                                               *
 *                                                                         *
 *   BBPP - BlackBox Plny Permoniku :)                                     *
 *   Navrhnete SSO se vstupy x,y,z a dvema vystupy. Na x,y vstupuji        *
 *   od nejnizsiho radu 2 BIN cisla, pokud z=1, chci vystup, ktery bude    *
 *   specifikovat, ktere cislo je vetsi.                                   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <stdio.h>
#include <SDL.h>
#include <SDL_image.h>


/*
 * Symbolicke konstanty
 */

#define SDL_SUBSYSTEMS SDL_INIT_VIDEO

#define WIN_FLAGS SDL_HWSURFACE|SDL_DOUBLEBUF
#define WIN_WIDTH 320
#define WIN_HEIGHT 240
#define WIN_BPP 0

#define WIN_TITLE "BlackBox Plny Permoniku :-)"


/*
 * Globalni promenne
 */

SDL_Surface *g_screen = NULL;	// Surface okna

SDL_Surface *gi_bbpp = NULL;	// Obrazky
SDL_Surface *gi_x = NULL;
SDL_Surface *gi_y = NULL;
SDL_Surface *gi_z = NULL;
SDL_Surface *gi_a = NULL;
SDL_Surface *gi_b = NULL;
SDL_Surface *gi_out0 = NULL;
SDL_Surface *gi_out1 = NULL;

bool m_x = false;
bool m_y = false;
bool m_z = false;
bool m_a = false;
bool m_b = false;
bool m_out0 = false;
bool m_out1 = false;


/*
 * Funkcni prototypy
 */


SDL_Surface *LoadImage(const char *filename, bool alpha = false);
bool Init();
void Destroy();
void Draw();
bool ProcessEvent();
int  main(int argc, char *argv[]);


/*
 * Funkce se pokusi nahrat obrazek ze souboru a zkonvertovat ho
 * na stejny pixel format, jako ma okno (framebuffer)
 */

SDL_Surface *LoadImage(const char *filename, bool alpha)
{
	SDL_Surface *tmp;// Pomocny
	SDL_Surface *ret;// Bude vracen

	if((tmp = IMG_Load(filename)) == NULL)// Prilinkovat SDL_image
	{
		fprintf(stderr, "%s\n", SDL_GetError());
		return NULL;
	}

	if((ret = (alpha) ? SDL_DisplayFormatAlpha(tmp)
			: SDL_DisplayFormat(tmp)) == NULL)
	{
		fprintf(stderr, "%s\n", SDL_GetError());
		SDL_FreeSurface(tmp);
		return NULL;
	}

	SDL_FreeSurface(tmp);// Uz neni potreba

	return ret;
}


/*
 * Inicializacni funkce
 */

bool Init()
{
	// Inicializace SDL
	if(SDL_Init(SDL_SUBSYSTEMS) == -1)
	{
		fprintf(stderr, "Unable to initialize SDL: %s\n",
				SDL_GetError());
		return false;
	}

	// Vytvori okno s definovanymi vlastnostmi
	g_screen = SDL_SetVideoMode(WIN_WIDTH, WIN_HEIGHT, WIN_BPP, WIN_FLAGS);

	if(g_screen == NULL)
	{
		fprintf(stderr, "Unable to set %dx%d video: %s\n",
				WIN_WIDTH, WIN_HEIGHT, SDL_GetError());
		return false;
	}

	SDL_WM_SetCaption(WIN_TITLE, NULL);

	// Loading obrazku
	if((gi_bbpp = LoadImage("data/bbpp.png", true)) == NULL
	|| (gi_x = LoadImage("data/x.png", false)) == NULL
	|| (gi_y = LoadImage("data/y.png", false)) == NULL
	|| (gi_z = LoadImage("data/z.png", false)) == NULL
	|| (gi_a = LoadImage("data/a.png", false)) == NULL
	|| (gi_b = LoadImage("data/b.png", false)) == NULL
	|| (gi_out0 = LoadImage("data/out0.png", false)) == NULL
	|| (gi_out1 = LoadImage("data/out1.png", false)) == NULL)
		return false;

	return true;
}


/*
 * Deinicializacni funkce
 */

void Destroy()
{
	if(gi_bbpp)
		SDL_FreeSurface(gi_bbpp);
	if(gi_x)
		SDL_FreeSurface(gi_x);
	if(gi_y)
		SDL_FreeSurface(gi_y);
	if(gi_z)
		SDL_FreeSurface(gi_z);
	if(gi_a)
		SDL_FreeSurface(gi_a);
	if(gi_b)
		SDL_FreeSurface(gi_b);
	if(gi_out0)
		SDL_FreeSurface(gi_out0);
	if(gi_out1)
		SDL_FreeSurface(gi_out1);

	SDL_Quit();
}


/*
 * Vykresleni sceny
 */

void Draw()
{
	SDL_Rect rect;

	// Pozadi okna
	SDL_FillRect(g_screen, NULL, SDL_MapRGB(g_screen->format, 255, 255, 255));

	// Pozadi, vsechny stavy nulovy
	rect.x = 0; rect.y = 0;
	SDL_BlitSurface(gi_bbpp, NULL, g_screen, &rect);

	if(m_x)
	{
		rect.x = 26; rect.y = 72;
		SDL_BlitSurface(gi_x, NULL, g_screen, &rect);
	}
	if(m_y)
	{
		rect.x = 26; rect.y = 106;
		SDL_BlitSurface(gi_y, NULL, g_screen, &rect);
	}
	if(m_z)
	{
		rect.x = 26; rect.y = 140;
		SDL_BlitSurface(gi_z, NULL, g_screen, &rect);
	}
	if(m_a)
	{
		rect.x = 115; rect.y = 206;
		SDL_BlitSurface(gi_a, NULL, g_screen, &rect);
	}
	if(m_b)
	{
		rect.x = 192; rect.y = 206;
		SDL_BlitSurface(gi_b, NULL, g_screen, &rect);
	}
	if(m_out0)
	{
		rect.x = 270; rect.y = 89;
		SDL_BlitSurface(gi_out0, NULL, g_screen, &rect);
	}
	if(m_out1)
	{
		rect.x = 270; rect.y = 129;
		SDL_BlitSurface(gi_out1, NULL, g_screen, &rect);
	}

	// Prohozeni bufferu
	SDL_Flip(g_screen);
}


/*
 * Osetruje udalosti
 */

bool ProcessEvent()
{
	SDL_Event event;

	while(SDL_WaitEvent(&event))
	{
		switch(event.type)
		{
		case SDL_MOUSEBUTTONDOWN:
			switch(event.button.button)
			{
			case SDL_BUTTON_LEFT:
				// x
				if(event.button.x > 26 && event.button.x < 51
				&& event.button.y > 72 && event.button.y < 97)
					m_x = !m_x;

				// y
				if(event.button.x > 26 && event.button.x < 51
				&& event.button.y > 106 && event.button.y < 131)
					m_y = !m_y;

				// z
				if(event.button.x > 26 && event.button.x < 51
				&& event.button.y > 140 && event.button.y < 165)
					m_z = !m_z;

				// clk
				if(event.button.x > 116 && event.button.x < 141
				&& event.button.y > 9 && event.button.y < 34)
				{
					m_a = m_z || (m_x && !m_y) || (m_a && !m_y)
						|| (m_a && m_x);

					m_b = m_z || (m_b && !m_x) || (!m_x && m_y)
						|| (m_b && m_y);
				}

				// clr
				if(event.button.x > 189 && event.button.x < 214
				&& event.button.y > 10 && event.button.y < 35)
				{
					m_a = false;
					m_b = false;
				}

				break;

			default:
				break;
			}

			m_out0 = m_a && m_z;
			m_out1 = m_b && m_z;

			break;

		// Klavesnice
		case SDL_KEYDOWN:
			switch(event.key.keysym.sym)
			{
				case SDLK_ESCAPE:
					return false;
					break;

				default:
					break;
			}
			break;

		// Pozadavek na ukonceni
		case SDL_QUIT:
			return false;
			break;

		default:
			break;
		}

		Draw();
	}

	return true;
}


/*
 * Vstup do programu
 */

int main(int argc, char *argv[])
{
	// Inicializace
	if(!Init())
	{
		Destroy();
		return 1;
	}

	ProcessEvent();

	// Deinicializace a konec
	Destroy();
	return 0;
}
