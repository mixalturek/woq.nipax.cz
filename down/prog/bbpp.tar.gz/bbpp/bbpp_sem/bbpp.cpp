/***************************************************************************
 *   Copyright (C) 2005 by Michal Turek - Woq                              *
 *   WOQ (zavinac) seznam.cz                                               *
 *                                                                         *
 *   BBPP - BlackBox Plny Permoniku :)                                     *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <stdio.h>
#include <string.h>
#include <SDL.h>
#include <SDL_image.h>


/*
 * Symbolicke konstanty
 */

#define SDL_SUBSYSTEMS SDL_INIT_VIDEO

#define WIN_FLAGS SDL_HWSURFACE|SDL_DOUBLEBUF
#define WIN_WIDTH 320
#define WIN_HEIGHT 240
#define WIN_BPP 0

#define WIN_TITLE "BlackBox Plny Permoniku :-)"


/*
 * Globalni promenne
 */

SDL_Surface *g_screen = NULL;	// Surface okna

SDL_Surface *gi_bbpp = NULL;	// Obrazky
SDL_Surface *gi_a = NULL;
SDL_Surface *gi_b = NULL;
SDL_Surface *gi_q0 = NULL;
SDL_Surface *gi_q1 = NULL;
SDL_Surface *gi_q2 = NULL;
SDL_Surface *gi_y = NULL;
SDL_Surface *gi_permonici = NULL;

bool a = false;
bool b = false;
bool q0 = false;
bool q1 = false;
bool q2 = false;
bool jq0 = false;
bool jq1 = false;
bool jq2 = false;
bool kq0 = false;
bool kq1 = false;
bool kq2 = false;
bool y = false;

// Cheaty
bool g_cheat_flag = false;		// Flag cheatu
char g_cheat_str[] = "permonici";	// Retezec cheatu
unsigned int g_cheat_pos = 0;		// Pozice v retezci


/*
 * Funkcni prototypy
 */


SDL_Surface *LoadImage(const char *filename, bool alpha = false);
bool Init();
void Destroy();
void Draw();
bool ProcessEvent();
int  main(int argc, char *argv[]);


/*
 * Funkce se pokusi nahrat obrazek ze souboru a zkonvertovat ho
 * na stejny pixel format, jako ma okno (framebuffer)
 */

SDL_Surface *LoadImage(const char *filename, bool alpha)
{
	SDL_Surface *tmp;// Pomocny
	SDL_Surface *ret;// Bude vracen

	if((tmp = IMG_Load(filename)) == NULL)// Prilinkovat SDL_image
	{
		fprintf(stderr, "%s\n", SDL_GetError());
		return NULL;
	}

	if((ret = (alpha) ? SDL_DisplayFormatAlpha(tmp)
			: SDL_DisplayFormat(tmp)) == NULL)
	{
		fprintf(stderr, "%s\n", SDL_GetError());
		SDL_FreeSurface(tmp);
		return NULL;
	}

	SDL_FreeSurface(tmp);// Uz neni potreba

	return ret;
}


/*
 * Inicializacni funkce
 */

bool Init()
{
	// Inicializace SDL
	if(SDL_Init(SDL_SUBSYSTEMS) == -1)
	{
		fprintf(stderr, "Unable to initialize SDL: %s\n",
				SDL_GetError());
		return false;
	}

	// Vytvori okno s definovanymi vlastnostmi
	g_screen = SDL_SetVideoMode(WIN_WIDTH, WIN_HEIGHT, WIN_BPP, WIN_FLAGS);

	if(g_screen == NULL)
	{
		fprintf(stderr, "Unable to set %dx%d video: %s\n",
				WIN_WIDTH, WIN_HEIGHT, SDL_GetError());
		return false;
	}

	SDL_WM_SetCaption(WIN_TITLE, NULL);

	// Loading obrazku
	if((gi_bbpp = LoadImage("data/bbpp.png", true)) == NULL
	|| (gi_q0 = LoadImage("data/q0.png", false)) == NULL
	|| (gi_q1 = LoadImage("data/q1.png", false)) == NULL
	|| (gi_q2 = LoadImage("data/q2.png", false)) == NULL
	|| (gi_a = LoadImage("data/a.png", false)) == NULL
	|| (gi_b = LoadImage("data/b.png", false)) == NULL
	|| (gi_y = LoadImage("data/y.png", false)) == NULL
	|| (gi_permonici = LoadImage("data/permonici.png", false)) == NULL)
		return false;

	return true;
}


/*
 * Deinicializacni funkce
 */

void Destroy()
{
	if(gi_bbpp)
		SDL_FreeSurface(gi_bbpp);
	if(gi_q0)
		SDL_FreeSurface(gi_q0);
	if(gi_q1)
		SDL_FreeSurface(gi_q1);
	if(gi_q2)
		SDL_FreeSurface(gi_q2);
	if(gi_a)
		SDL_FreeSurface(gi_a);
	if(gi_b)
		SDL_FreeSurface(gi_b);
	if(gi_y)
		SDL_FreeSurface(gi_y);
	if(gi_permonici)
		SDL_FreeSurface(gi_permonici);

	SDL_Quit();
}


/*
 * Vykresleni sceny
 */

void Draw()
{
	SDL_Rect rect;

	// Pozadi okna
	SDL_FillRect(g_screen, NULL, SDL_MapRGB(g_screen->format, 255, 255, 255));

	// Pozadi, vsechny stavy nulovy
	rect.x = 0; rect.y = 0;
	SDL_BlitSurface(gi_bbpp, NULL, g_screen, &rect);

	if(q2)
	{
		rect.x = 115; rect.y = 204;
		SDL_BlitSurface(gi_q2, NULL, g_screen, &rect);
	}
	if(q1)
	{
		rect.x = 156; rect.y = 204;
		SDL_BlitSurface(gi_q1, NULL, g_screen, &rect);
	}
	if(q0)
	{
		rect.x = 192; rect.y = 204;
		SDL_BlitSurface(gi_q0, NULL, g_screen, &rect);
	}
	if(a)
	{
		rect.x = 30; rect.y = 72;
		SDL_BlitSurface(gi_a, NULL, g_screen, &rect);
	}
	if(b)
	{
		rect.x = 30; rect.y = 118;
		SDL_BlitSurface(gi_b, NULL, g_screen, &rect);
	}
	if(y)
	{
		rect.x = 272; rect.y = 112;
		SDL_BlitSurface(gi_y, NULL, g_screen, &rect);
	}

	if(g_cheat_flag)
	{
		rect.x = 114; rect.y = 82;
		SDL_BlitSurface(gi_permonici, NULL, g_screen, &rect);
	}

	// Prohozeni bufferu
	SDL_Flip(g_screen);
}


/*
 * Osetruje udalosti
 */

bool ProcessEvent()
{
	SDL_Event event;

	while(SDL_WaitEvent(&event))
	{
		switch(event.type)
		{
		case SDL_MOUSEBUTTONDOWN:
			switch(event.button.button)
			{
			case SDL_BUTTON_LEFT:
				// a
				if(event.button.x > 30 && event.button.x < 55
				&& event.button.y > 72 && event.button.y < 97)
					a = !a;

				// b
				if(event.button.x > 30 && event.button.x < 55
				&& event.button.y > 118 && event.button.y < 143)
					b = !b;

				// q0
				if(event.button.x > 192 && event.button.x < 217
				&& event.button.y > 204 && event.button.y < 229)
					q0 = !q0;

				// q1
				if(event.button.x > 156 && event.button.x < 181
				&& event.button.y > 204 && event.button.y < 229)
					q1 = !q1;

				// q2
				if(event.button.x > 115 && event.button.x < 140
				&& event.button.y > 204 && event.button.y < 229)
					q2 = !q2;

				// clk
				if(event.button.x > 116 && event.button.x < 141
				&& event.button.y > 9 && event.button.y < 34)
				{
					jq0 = !(!(!a && !q1) && !q2);
					kq0 = !(!q1 && b);
					jq1 = !(!(b && q2) && !(a && q2) && !(a && q0)
						&& !(!a && !b && !q0 && !q1 && !q2));
					kq1 = !(!a && !b && q0);
					jq2 = !(!(a && q1) && !(!b && !q0 && q1));
					kq2 = true;

//					if(!jq0 && !kq0) ;// nic
					if(jq0 && !kq0) q0 = true;
					else if(!jq0 && kq0) q0 = false;
					else if(jq0 && kq0) q0 = !q0;
//					if(!jq1 && !kq1) ;// nic
					if(jq1 && !kq1) q1 = true;
					else if(!jq1 && kq1) q1 = false;
					else if(jq1 && kq1) q1 = !q1;
//					if(!jq2 && !kq2) ;// nic
					if(jq2 && !kq2) q2 = true;
					else if(!jq2 && kq2) q2 = false;
					else if(jq2 && kq2) q2 = !q0;
				}

				// clr
				if(event.button.x > 189 && event.button.x < 214
				&& event.button.y > 10 && event.button.y < 35)
				{
					q0 = false;
					q1 = false;
					q2 = false;
				}

				break;

			default:
				break;
			}

			y = !(!q2 && !(a && q0 && !q1) && !(!a && !b && q0 && q1)
				&& !(!a && !b && !q0 && !q1));

			break;

		// Klavesnice
		case SDL_KEYDOWN:
			// CHEATY
			// Spravna klavesa v posloupnosti
			if(g_cheat_str[g_cheat_pos] == event.key.keysym.sym)
			{
				// Cela posloupnost spravne
				if(++g_cheat_pos == strlen(g_cheat_str))
				{
					// Aplikace cheatu
					g_cheat_flag = !g_cheat_flag;
					g_cheat_pos = 0;// Pristi pruchod
				}
			}
			else// Spatny cheat
			{
				g_cheat_pos = 0;
			}

			switch(event.key.keysym.sym)
			{
				case SDLK_ESCAPE:
					return false;
					break;

				default:
					break;
			}
			break;

		// Pozadavek na ukonceni
		case SDL_QUIT:
			return false;
			break;

		default:
			break;
		}

		Draw();
	}

	return true;
}


/*
 * Vstup do programu
 */

int main(int argc, char *argv[])
{
	// Inicializace
	if(!Init())
	{
		Destroy();
		return 1;
	}

	ProcessEvent();

	// Deinicializace a konec
	Destroy();
	return 0;
}
